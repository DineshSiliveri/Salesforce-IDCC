<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>activity_history_case_msisdn</label>
    <protected>false</protected>
    <values>
        <field>Destination_Field__c</field>
        <value xsi:type="xsd:string">msisdn</value>
    </values>
    <values>
        <field>Fixed_Value_Type__c</field>
        <value xsi:type="xsd:string">Text</value>
    </values>
    <values>
        <field>Fixed_Value__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>Inactive__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>NullToZero__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>Object_Conversion_Map__c</field>
        <value xsi:type="xsd:string">Retrieve_Activity_History</value>
    </values>
    <values>
        <field>Same_Field_Name__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>Source_Field__c</field>
        <value xsi:type="xsd:string">Case.MSISDN__c</value>
    </values>
    <values>
        <field>Value_Conversion__c</field>
        <value xsi:type="xsd:string">STR.UPPER</value>
    </values>
</CustomMetadata>
