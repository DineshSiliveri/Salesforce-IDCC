<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Test Class Configuration_ClientSideError</label>
    <protected>false</protected>
    <values>
        <field>Content_Type__c</field>
        <value xsi:type="xsd:string">application/json</value>
    </values>
    <values>
        <field>Log_Level__c</field>
        <value xsi:type="xsd:string">NONE</value>
    </values>
    <values>
        <field>Main_URL__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Named_Credential__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Set_Timeout__c</field>
        <value xsi:type="xsd:double">5000.0</value>
    </values>
    <values>
        <field>test_exception__c</field>
        <value xsi:type="xsd:string">Client-Side HTTP Error - Salesforce</value>
    </values>
    <values>
        <field>test_mode__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
</CustomMetadata>
