({
    
    init : function(component, event, helper) {
        //Calling helper method on init action
        var accAction = component.get("c.getCaseInfo");
        var recordId12 = component.get("v.recordId");
        var params={"caseId":recordId12};
        accAction.setParams(params);
        var accountPromise = helper.executeAction(component, accAction);
        accountPromise.then(
            $A.getCallback(function(result){
                var obj = JSON.parse(result);
                component.set('v.caseSegType',obj.IDCC_Customer_Segment__c);
                component.set('v.CreatedDate',obj.CreatedDate);
                component.set('v.caseDataLocation',obj.IDCC_Siebel_Data_Location__c);
                var a = component.get('c.assetPostpaid');
                $A.enqueueAction(a);
            }),
            $A.getCallback(function(error){
                console.log('An error in init method of Health check : ' + error.message);
            })
        ) 
        var a = component.get('c.assetPostpaid');
        $A.enqueueAction(a);
        
    },
    assetPostpaid : function(component, event, helper) {
        component.set('v.errorMessageAssetPostpaid',''); 
        helper.showSpinner(component);
        var accAction = component.get("c.getAssetInfo");
        var recordId12 = component.get("v.recordId");
        var params={"caseId":recordId12};
        accAction.setParams(params);
        var accountPromise = helper.executeAction(component, accAction);
        accountPromise.then(
            $A.getCallback(function(result){
                console.log('**obj is Asset'+result);
                var obj = JSON.parse(result);
                if(obj.httpstatus == "200" && obj.Response.servicedata.sErrCode == "0"){
                    var cType = ''; //Need to change
                    var cStatus = '';
                    var blockStatus = '';
                    if(component.get("v.caseSegType") == 'Postpaid' && component.get("v.caseDataLocation") =='CATALIST'){
                        if(obj.Response.servicedata.ListOfIsatEaiAssetIdccInternalIo != undefined && obj.Response.servicedata.ListOfIsatEaiAssetIdccInternalIo.IsatEaiAssetIdcc[0] != undefined){
                            //cType = obj.Response.servicedata.ListOfIsatEaiAssetIdccInternalIo.IsatEaiAssetIdcc[0].CardType;  
                            cType = 'Not Applicable';
                            cStatus= obj.Response.servicedata.ListOfIsatEaiAssetIdccInternalIo.IsatEaiAssetIdcc[0].Status;  
                            blockStatus= obj.Response.servicedata.ListOfIsatEaiAssetIdccInternalIo.IsatEaiAssetIdcc[0].BlockStatus; 
                        }    
                    }
                    if((component.get('v.caseSegType') == 'Postpaid' || component.get('v.caseSegType') == 'Prepaid')&& component.get('v.caseDataLocation') =='ICARE'){
                        if(obj.Response.servicedata.ListOfIdsEaiAssetIdccInternalIo != undefined && obj.Response.servicedata.ListOfIdsEaiAssetIdccInternalIo.IdsEaiIdccParentAsset[0] != undefined){
                            var cardTypeData = obj.Response.servicedata.ListOfIdsEaiAssetIdccInternalIo.IdsEaiIdccParentAsset[0].CardType;  
                            var cType;
                            if(cardTypeData != null){
                                cType = cardTypeData; 
                                if(cardTypeData.indexOf('SIM')!= -1 || cardTypeData.indexOf('USIM')!= -1){
                                    component.set('v.containsSimOrUsim',true);    
                                }
                                else{
                                    component.set('v.containsSimOrUsim',false);    
                                }
                            }
                            else if(cardTypeData == null){
                                cType ='SIM' ;   
                            }
                            cStatus= obj.Response.servicedata.ListOfIdsEaiAssetIdccInternalIo.IdsEaiIdccParentAsset[0].Status;  
                            blockStatus= obj.Response.servicedata.ListOfIdsEaiAssetIdccInternalIo.IdsEaiIdccParentAsset[0].ListOfIdsEaiAssetIdccThinBc.IdsEaiAssetIdccThinBc[0].BlockStatus; 
                        }    
                    }
                    component.set('v.assetStatus',cStatus);
                    component.set('v.cardType',cType);
                    component.set('v.blockStatus',blockStatus);
                    component.set('v.displayFirstRow',true);    
                    component.set('v.displayrow1Error',false);
                }else{
                    component.set('v.displayFirstRow',true); 
                    component.set('v.displayrow1Error',true);
                    component.set('v.assetStatus','In Active');
                    component.set('v.blockStatus','');
                    component.set('v.errorMessageAssetPostpaid','System Failure,please refresh again');
                }     
                if(component.get("v.assetStatus") != 'Active'){
                    component.set('v.resultingIssue','Asset is not found.'); 
                    component.set('v.titleClass','title1');
                }
                if(component.get("v.assetStatus") == 'Inactive' || component.get("v.assetStatus") == '' ||component.get("v.assetStatus") == 'In active' ||
                   component.get("v.assetStatus") == null) {
                    component.set('v.resultingIssue',''); 
                    component.set('v.titleClass','');
                }
                helper.hideSpinner(component);   
            }),
            $A.getCallback(function(error){
                component.set('v.displayFirstRow',true);
                component.set('v.errorMessageAssetPostpaid','System Failure,please refresh again');
                console.log('An error in asset postpaid method of Health check : ' + error.message);
            })
        )
    },
    fetchCardType : function(component, event, helper) {
        component.set('v.errorMessageFetchCardType','');
        component.set('v.displayError',false);
        component.set('v.errorMsg',''); 
        helper.showSpinner(component);
        var actionStatus = component.get("c.getOffer");
        var caseIdRec = component.get("v.recordId"); 
        var customerSeg = component.get("v.caseSegType");
        var params1={"caseId":caseIdRec,
                     "customerSeg":customerSeg};
        actionStatus.setParams(params1);
        var accountPromise = helper.executeAction(component, actionStatus);
        accountPromise.then(
            $A.getCallback(function(result){
                var obj;
                var obj1;
                if(result!=null  && result[0]!=null){
                    console.log('**Result of General Inof API**'+result[0]);
                    var obj = JSON.parse(result[0]);    
                }
                if(result!=null  && result[1]!=null){
                    console.log('**Result of Query billing Unbillied Uages API**'+result[1]);    
                    var obj1= JSON.parse(result[1]);
                }
                if(result!=null  && result[0]!=null && obj.httpstatus == "200" && obj.Response.servicedata != undefined ) {
                    if(obj.Response.servicedata.GeneralGet!= undefined && obj.Response.servicedata.GeneralGet.AccountDetails.AccountInfo != undefined){
                        var caseCreatedDate = component.get('v.CreatedDate');
                        caseCreatedDate = caseCreatedDate.substring(0, 10);
                        caseCreatedDate = moment(caseCreatedDate).format('DD-MMM-YYYY');
                        console.log('caseCreatedDate---'+caseCreatedDate);
                        
                        var expiryDate = obj.Response.servicedata.GeneralGet.AccountDetails.AccountInfo.supervisionExpiryDate; 
                        expiryDate = expiryDate.substring(0, 8);
                        expiryDate = moment(expiryDate).format('DD-MMM-YYYY');
                        component.set('v.expiryDate',expiryDate);
                        console.log('expiryDate---'+expiryDate);
                        
                        var termDate = obj.Response.servicedata.GeneralGet.AccountDetails.AccountInfo.serviceFeeExpiryDate;  
                        termDate = termDate.substring(0, 8);
                        termDate = moment(termDate).format('DD-MMM-YYYY');
                        component.set('v.terminationDate',termDate);
                        console.log('termination Date---'+termDate);
                        
                        // var isExpired1 = moment(component.get('v.expiryDate')).isSameOrAfter(caseCreatedDate,'day');
                        var isExpired = moment(caseCreatedDate).isSameOrAfter(component.get('v.expiryDate'),'day');
                        console.log('isExpired---'+isExpired); 
                        component.set('v.isExpired',isExpired);
                        var isTerminated = moment(caseCreatedDate).isSameOrAfter(component.get('v.terminationDate'),'day');
                        console.log('isTerminated---'+isTerminated);
                        component.set('v.isTerminated',isTerminated);
                    }
                    if(component.get("v.caseSegType") == 'Prepaid'){
                        component.set('v.balanceLabel','Balance');
                        var balance ='';
                        balance = obj.Response.servicedata.GeneralGet.DedicatedAccount.maBalance;
                        if(balance==''){
                            component.set('v.mainBalance',false);
                            component.set('v.mainBalanceAmt',null);
                        }else{
                            component.set('v.mainBalance',true);
                            component.set('v.mainBalanceAmt',balance);
                        }
                    }
                    var offers;
                    if(obj.Response.servicedata.GeneralGet.DedicatedAccount != undefined){
                        offers = obj.Response.servicedata.GeneralGet.DedicatedAccount.Offer;
                    }
                    if(offers != undefined){
                        component.set("v.isValidOffer",true);
                        for (var i = 0; i < offers.length; i++) {
                            var offerId= offers[i].offerID.toString();
                            console.log('Offers----'+offerId);
                            if(offerId ==  "4443"){
                                component.set("v.isValidOffer",false);
                                break;
                            }
                        } 
                        component.set('v.displaySecondRow',true);
                        // Show Footer.
                        var row2 = component.get('v.displaySecondRow');
                        var row3 = component.get('v.displayThirdRow');
                        var row4 = component.get('v.displayFourthRow');
                        var row5 = component.get('v.displayFifthRow');
                        var row6 = component.get('v.displaySixtRow');
                        if(row2 && row3 && row4 && row5 && row6){
                            helper.showCoverage(component, event, helper);  
                        }
                    }else{
                        component.set("v.isValidOffer",true);
                        component.set('v.displaySecondRow',true);
                    }
                    
                }else if(obj.httpstatus == "200" && obj.Response.servicedata == undefined){
                    var errMsg = obj.Response.servicedata;
                    component.set("v.isValidOffer",true);
                    component.set('v.displaySecondRow',true);
                    console.log('error while calling....'+errMsg);
                    component.set('v.errorMessageFetchCardType','System Failure,please refresh again');
                }
                    else if(obj.httpstatus == "200" && obj.Response.servicedata == 'System failure, please try again on few minutes'){
                        var errMsg = obj.Response.servicedata;
                        component.set("v.isValidOffer",true);
                        component.set('v.displaySecondRow',true);
                        console.log('error while calling'+errMsg);
                        component.set('v.errorMessageFetchCardType','System Failure,please refresh again');
                    }else{  
                        console.log('error while calling');
                        component.set('v.errorMessageFetchCardType','System Failure,please refresh again');
                    }
                if(component.get("v.caseSegType") == 'Postpaid'){
                    component.set('v.balanceLabel','Total Unbilled Usage');
                    helper.checkForpostpaidbalance(component, event, helper,obj1);    
                }
                else{
                    helper.hideSpinner(component);    
                }
            }),
            $A.getCallback(function(error){
                // Something went wrong
                console.log('An error in generalInfo method of Health check : ' + error);
            })
        );
    },
    fetchNetwork : function(component, event, helper) {
        component.set('v.errorMessageFetchNetwork',''); 
        helper.showSpinner(component);
        var actionStatus = component.get("c.GetAPNLastKnownLocation1");
        var recordId12 = component.get("v.recordId");
        var params={"caseId":recordId12};
        actionStatus.setParams(params);
        var accountPromise = helper.executeAction(component, actionStatus);
        accountPromise.then(
            $A.getCallback(function(result){
                if(result == null){
                    component.set('v.errorMessageFetchNetwork','System Failure,please refresh again');
                    helper.hideSpinner(component);      
                }
                else{
                    console.log('*Result for  GetAPNLastKnownLocation'+JSON.stringify(result));
                    for(var key in result){
                        if(key == 'Error'){
                            component.set('v.errorMessageFetchNetwork',result[key]); 
                            helper.hideSpinner(component);       
                        }
                        if(key == 'Result'){
                            var obj = JSON.parse(result[key]);
                            if(obj!='' && obj != undefined && obj.data != undefined){
                                var cd =obj.data.sub_info.thumbnail_device_tags;
                                //  var deviceType = 'Nio=HANDSET ';
                                if(cd == undefined){
                                    component.set('v.deviceTypeErr',true); 
                                }
                                var deviceType='';
                                if(cd.indexOf('4G') != -1){
                                    deviceType += 'HANDSET 4G';
                                }
                                if(cd.indexOf('4G') == -1 && cd.indexOf('3G') != -1){
                                    deviceType +=  'HANDSET 3G';
                                }
                                if(cd.indexOf('4G') == -1 && cd.indexOf('3G') == -1 && cd.indexOf('2G') != -1){
                                    deviceType +=  'HANDSET 2G';
                                }
                                component.set('v.deviceType',deviceType);
                                var signNetwork ='';
                                var map1 = new Map([[1 , 'Poor'], [2 ,'Very Poor'] ,[3, 'Good'],[4,'Very Good'],[5,'Excellent']]);      
                                var val =  obj.data.signalling_gtpc[0].teid_info.rat_type;
                                var signExp = obj.data.usage_day_scope.kpi_rating;
                                console.log(signExp);
                                var apnRatings = obj.data.signalling_gtpc[0].teid_info.apn;    
                                if(signExp == '' || signExp == undefined ){
                                    signExp = 1; 
                                }
                                var signExpVal = map1.get(signExp);
                                //alert('signExpVal'+signExpVal);
                                if(val != undefined && val != ''){
                                    signNetwork =val;    
                                }
                                component.set('v.signalNetwork',signNetwork);
                                component.set('v.signalExperience',signExpVal);
                                component.set('v.displayThirdRow',true);
                                component.set('v.apnSettings',apnRatings);
                            }else{
                                component.set('v.errorMessageFetchNetwork','System Failure,please refresh again');
                                helper.hideSpinner(component);
                            }    
                        }
                    }
                    
                }
                // Show Footer.
                var row2 = component.get('v.displaySecondRow');
                var row3 = component.get('v.displayThirdRow');
                var row4 = component.get('v.displayFourthRow');
                var row5 = component.get('v.displayFifthRow');
                var row6 = component.get('v.displaySixtRow');
                if(row2 && row3 && row4 && row5 && row6){
                    helper.showCoverage(component, event, helper);  
                }
                component.set("v.spinner",false);   
            }),
            $A.getCallback(function(error){
                console.log('An error in GetAPNLastKnownLocation API method of Health check : ' + error.message);
                component.set('v.errorMessageFetchNetwork','System Failure,please refresh again');
            })
        )
    },
    fetchDummy : function(component, event, helper) {
        helper.showSpinner(component);
        component.set('v.displayFourthRow',true);   
        var row2 = component.get('v.displaySecondRow');
        var row3 = component.get('v.displayThirdRow');
        var row4 = component.get('v.displayFourthRow');
        var row5 = component.get('v.displayFifthRow');
        var row6 = component.get('v.displaySixtRow');
        if(row2 && row3 && row4 && row5 && row6){
            helper.showCoverage(component, event, helper);  
        }
        helper.hideSpinner(component);   
    },
    isSmsActive : function(component, event, helper) {
        component.set('v.errorMessageIsSmsActive','');
        helper.showSpinner(component);
        var accAction = component.get("c.getSMSType");
        var recordId12 = component.get("v.recordId");
        var params={"caseId":recordId12};
        accAction.setParams(params);
        accAction.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                console.log('**obj is SMS'+result);
                var obj = JSON.parse(result);
                if(obj != undefined && obj.Response!=undefined && obj.Response.servicedata != undefined
                   && obj.Response.servicedata.ServiceProfile[0] != undefined){
                    var smsMOType =  obj.Response.servicedata.ServiceProfile[0].SMSMO;
                    var smsMTType =  obj.Response.servicedata.ServiceProfile[0].SMSMT;
                    var callStats =  obj.Response.servicedata.ServiceProfile[0].Telephony; 
                    if(smsMOType == 'FALSE'){
                        smsMOType =false;    
                    }
                    component.set('v.smsMo',smsMOType);  
                    console.log('MO****'+smsMOType);
                    if(smsMTType == 'FALSE'){
                        smsMTType =false;    
                    }
                    component.set('v.smsMt',smsMTType);
                    console.log('Mt****'+smsMTType);
                    if(callStats == 'FALSE'){
                        callStats =false;    
                    }
                    component.set('v.callStatus',callStats);    
                    component.set('v.displayFifthRow',true);  
                    console.log('displayFifthRow****'+component.get('v.displayFifthRow'));
                }else{
                    component.set('v.smsMo',false);  
                    component.set('v.smsMt',false);
                    component.set('v.callStatus',false);    
                    component.set('v.displayFifthRow',true);
                    component.set('v.errorMessageIsSmsActive','System Failure,please refresh again');
                }
                helper.hideSpinner(component); 
            }
            else{
                component.set('v.errorMessageIsSmsActive','System Failure,please refresh again');
                console.log('An error in SMS  API of Health check : ' + error.message); 
                helper.hideSpinner(component); 
            }
        });
        $A.enqueueAction(accAction);
    },
    fetchQuotaStatus : function(component, event, helper) {
        component.set('v.errorMessageFetchQuotaStatus','');
        helper.showSpinner(component);
        var accAction1 = component.get("c.getQuota");
        var recordId12 = component.get("v.recordId");
        var params={"caseId":recordId12};
        accAction1.setParams(params);
        accAction1.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                console.log('**obj is Query Package Info'+result);
                var obj = JSON.parse(result);
                //if(obj != undefined && obj.Response.servicedata != undefined 
                //&& obj.Response.servicedata.packagelist[0] != undefined && obj.Response.servicedata.packagelist[0].Quotas != undefined ){
                if(obj != undefined && obj.Response != undefined  && obj.Response.servicedata != undefined ){
                    if(obj.Response.servicedata.packagelist!=undefined){
                        for(var x =0;x<obj.Response.servicedata.packagelist.length ;x++){
                            if(obj.Response.servicedata.packagelist[x].Quotas != undefined ){
                                for(var i =0;i<obj.Response.servicedata.packagelist[x].Quotas.length ;i++){
                                    if(obj.Response.servicedata.packagelist[x].Quotas[i].description =='Main Quota' || 
                                       obj.Response.servicedata.packagelist[x].Quotas[i].description == 'MAIN QUOTA'
                                      || obj.Response.servicedata.packagelist[x].Quotas[i].description == 'main quota'){
                            
                                        var quota =  obj.Response.servicedata.packagelist[x].Quotas[i].remainingQuota;
                                        component.set('v.remainQuota',quota);
                                        break;
                                    }    
                                }
                            }
                        }
                        var addOnsMap = [];
                        for(var x =0;x<obj.Response.servicedata.packagelist.length ;x++){
                            if(obj.Response.servicedata.packagelist[x].Quotas != undefined ){
                                for(var i =0;i<obj.Response.servicedata.packagelist[x].Quotas.length ;i++){
                                    if(obj.Response.servicedata.packagelist[x].Quotas[i].benefitType =='DATA'){
                                        var val = obj.Response.servicedata.packagelist[x].Quotas[i].description;
                                        var key = obj.Response.servicedata.packagelist[x].Quotas[i].remainingQuota;
                                    	addOnsMap.push({value:val, key:key}); 
                                       
                                    }    
                                }
                            }
                        }
                        console.log('addOnsMap********'+JSON.stringify(addOnsMap));
                        console.log('addOnsMap Size********'+addOnsMap.length);
                        if(addOnsMap!=null && addOnsMap.length>0){
                        	component.set("v.addOnsMap", addOnsMap);
                            component.set("v.isAddOnsMapEmplty", false);
                        }
                        else{
                        	component.set("v.addOnsMap", null); 
                             component.set("v.isAddOnsMapEmplty", true);
                        }
                        var remainQuotaVal = component.get('v.remainQuota');
                        if(remainQuotaVal!=null && remainQuotaVal!='0' && remainQuotaVal!=0 && remainQuotaVal!=''){
                            component.set('v.isRemainingQuota',true);    
                        }
                        else{
                            component.set('v.isRemainingQuota',false);    
                        }
                        component.set('v.displaySixtRow',true); 
                        component.set('v.displayFourthRow',true); //row for Cell condition
                        var row2 = component.get('v.displaySecondRow');
                        var row3 = component.get('v.displayThirdRow');
                        var row4 = component.get('v.displayFourthRow');
                        var row5 = component.get('v.displayFifthRow');
                        var row6 = component.get('v.displaySixtRow');
                        //temp commneted
                        if(row2 && row3 && row4 && row5 && row6){
                            helper.showCoverage(component, event, helper);  
                        }
                        helper.hideSpinner(component);
                    }
                    else{
                        component.set('v.remainQuota',null);  
                        component.set('v.errorMessageFetchQuotaStatus','System Failure,please refresh again');
                        helper.hideSpinner(component);     
                    }
                }
                else{
                    component.set('v.remainQuota',null);  
                    component.set('v.errorMessageFetchQuotaStatus','System Failure,please refresh again');
                    helper.hideSpinner(component); 
                }
                //Temp code
                //helper.showCoverage(component, event, helper);
                //helper.hideSpinner(component); 
            }
            else{
                component.set('v.errorMessageFetchQuotaStatus','System Failure,please refresh again');
                console.log('An error in quota:query Packaege Info API of Health check : ' + error.message);    
            }
        });
        $A.enqueueAction(accAction1);
    },
    closeModel : function(component, event, helper) {
      component.set("v.isOpen", false);
    },
    OpenModal: function(component, event, helper) {
      component.set("v.isOpen", true);
    }
    
    
})