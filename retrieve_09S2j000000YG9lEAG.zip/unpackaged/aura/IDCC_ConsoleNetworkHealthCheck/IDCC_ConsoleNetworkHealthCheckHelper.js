({
    executeAction: function(component, action, callback) {
        return new Promise(function(resolve, reject) {
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var retVal=response.getReturnValue();
                    resolve(retVal);
                }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            reject(Error("Error message: " + errors[0].message));
                        }
                    }
                    else {
                        reject(Error("Unknown error"));
                    }
                }
            });
            $A.enqueueAction(action);
        });
    },
    showSpinner: function (component, event, helper) {
        component.set("v.spinner",true);
    },
    
    hideSpinner: function (component, event, helper) {
        component.set("v.spinner",false);
    },
    showCoverage : function(component, event, helper) {
        //testdata
       /* component.set("v.caseSegType","Postpaid");
        component.set("v.assetStatus","Active");
        component.set("v.isValidOffer",true); 
        component.set("v.cardType","SIM");  
        component.set("v.deviceType","HANDSET 4G"); 
        component.set("v.signalNetwork","3G");
        component.set("v.signalExperience","");
        var cellCond = 'Good';
        component.set("v.apnSettings","indosatgprs"); 
        component.set("v.isRemainingQuota",false);
        component.set("v.callStatus",false);
        component.set("v.mainBalance",false);
        component.set("v.blockStatus",'');  
        component.set("v.smsMo",false); 
        component.set("v.smsMt",false);
        component.set("v.isExpired",false); 
        component.set("v.isTerminated",false);*/
        
        /*component.set("v.caseSegType","Postpaid");
        component.set("v.assetStatus","Active");
        component.set("v.isValidOffer",true); 
        component.set("v.cardType","USIM");  
        component.set("v.deviceType","HANDSET 4G"); 
        component.set("v.signalNetwork","3G");
        component.set("v.signalExperience","");
        var cellCond = 'Good';
        component.set("v.apnSettings","indosatgprs"); 
        component.set("v.isRemainingQuota",true);
        component.set("v.callStatus",false);
        component.set("v.mainBalance",false);
        component.set("v.blockStatus",'');  
        component.set("v.smsMo",false); 
        component.set("v.smsMt",false); 
         component.set("v.isExpired",false); 
        component.set("v.isTerminated",false);*/
        
        var actionStatus = component.get("c.fetchHealthCheckMetadataGetRec");
        var assetStatus = component.get("v.assetStatus");
        var validOffer = component.get("v.isValidOffer"); 
        var cardType = component.get("v.cardType");  
        var devType = component.get("v.deviceType"); 
        var calStats = component.get("v.callStatus");
        var signNetwork = component.get("v.signalNetwork"); 
        var signExp = component.get("v.signalExperience");
        var cellCond = 'Good';
        var apn = component.get("v.apnSettings");       
        var mnBal = component.get("v.mainBalance");
        var blkStatus = component.get("v.blockStatus");  
        var mo = component.get("v.smsMo"); 
        var mt = component.get("v.smsMt");
        var RemainingQuota = component.get("v.isRemainingQuota");
        var segType = component.get("v.caseSegType");
        
        //Test code
       /*component.set("v.signalNetwork",'3G');
        component.set("v.callStatus",false);
         component.set("v.blockStatus",'');
        component.set("v.isRemainingQuota",false);*/
        
        var paramter={"cardType1":component.get("v.cardType"),
                      "assetStatus":component.get("v.assetStatus"),
                      "valOffer":component.get("v.isValidOffer"),
                      "devType" :component.get("v.deviceType"),
                      "calStatus" :component.get("v.callStatus"),
                      "signNetw" :component.get("v.signalNetwork"),
                      "signExp":component.get("v.signalExperience"),
                      "cellCond":'Good',
                      "apnSet":component.get("v.apnSettings"),
                      "manBal" :component.get("v.mainBalance"),
                      "blockStatus" :component.get("v.blockStatus"),
                      "mo" :component.get("v.smsMo"),
                      "mt" :component.get("v.smsMt"),
                      "segType" :component.get("v.caseSegType"),
                      "remainingQuota" :component.get("v.isRemainingQuota"),
                      "isExpired" :component.get("v.isExpired"),
                      "isTerminated" : component.get("v.isTerminated")
                     };
        actionStatus.setParams(paramter);
        console.log('String param ====:'+JSON.stringify(paramter));
        var accountPromise = this.executeAction(component, actionStatus); 
        accountPromise.then(
            $A.getCallback(function(result){
                if(result!=null){
                    console.log('Final Result Of Metdata****'+result[0].DeveloperName);
                    if(component.get('v.assetStatus') != 'Active'){
                        component.set('v.resultingIssue','Asset is not found.');   
                    }
                    else if(result != null && result != '' && result != undefined){
                        var ccc= result[0].Resulting_Issue__c.split(';');
                        var displResultingIss='';
                        for(var i=0;i<ccc.length;i++){
                            displResultingIss += ccc[i]+'\n';
                        }
                        component.set('v.resultingIssue',displResultingIss);
                        if(result[0].Agent_Suggestion_Step_1__c!=null && result[0].Agent_Suggestion_Step_1__c!=''){
                        	component.set('v.agentFirstSuggestion',result[0].Agent_Suggestion_Step_1__c);    
                        }
                        if(result[0].Agent_Suggestion_Step_2__c!=null && result[0].Agent_Suggestion_Step_2__c!=''){
                        	component.set('v.agentSecondSuggestion',result[0].Agent_Suggestion_Step_2__c);     
                        }
                    }else{
                        console.log('in else of Final Resiult');
                        component.set('v.resultingIssue','No code found.');
                         component.set('v.agentFirstSuggestion','');
                        component.set('v.agentSecondSuggestion',''); 
                    }    
                    component.set('v.titleClass','title1');
                    component.set('v.newsClass','signal');
                }
                else{
                    console.log('in else of Final Resiult');
                    component.set('v.resultingIssue','No code found.');
                    component.set('v.titleClass','title1');
                    component.set('v.newsClass','signal');
                    component.set('v.agentFirstSuggestion','');
                     component.set('v.agentSecondSuggestion',''); 
                }
            }),
            $A.getCallback(function(error){
                console.log('An error occurred showCoverage method  : ' + error.message);
            })
        );
        
        return accountPromise;
    }, 
    checkForpostpaidbalance :function(component, event, helper,obj1) {
        component.set('v.errorMessageFetchCardType',''); 
        if(component.get("v.caseSegType") == 'Postpaid' && obj1.httpstatus == "200" && obj1.Response.servicedata != undefined && 
           obj1.Response.servicedata.TotalUnbilledUsage != undefined){
            var balance1='';
            balance1 = obj1.Response.servicedata.TotalUnbilledUsage;
            if(balance1!='' || balance1 !='0'){
                component.set('v.mainBalance',true);
                component.set('v.mainBalanceAmt',balance1); 
            }
            else if(balance1 =='0'){
                component.set('v.mainBalance',false);
                component.set('v.mainBalanceAmt','0');     
            }
            else{
                component.set('v.mainBalance',false);
                component.set('v.mainBalanceAmt',null);         
            }
        }
        else if(obj1.httpstatus == 200 && obj1.Response.servicedata == undefined){
            var errMsg = obj1.Response.servicedata;
            component.set("v.isValidOffer",true);
            component.set('v.displaySecondRow',true);
            console.log('error while calling....'+errMsg);
            component.set('v.errorMessageFetchCardType','System Failure,please refresh again..');
        }
            else if(obj1.httpstatus == "200" && obj1.Response.servicedata == 'System failure, please try again on few minutes'){
                var errMsg = obj1.Response.servicedata;
                console.log('error while calling'+errMsg);
                component.set('v.errorMessageFetchCardType','System Failure,please refresh again..');
            }
                else{  
                    console.log('error while calling');
                    component.set('v.errorMessageFetchCardType','System Failure,please refresh again..');
                }
        
        helper.hideSpinner(component);
    }
    
})