({
    getTimingDetails : function(component, event, helper) {
        var caseId = component.get("v.recordId"); 
        console.log('caseId****'+caseId);
        
        var i=0; 
        var action = component.get("c.getCaseHandler");
        action.setParams({ 
            "caseId": caseId
        });
        action.setCallback(component,function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var caseObj = response.getReturnValue();
                
                //Added by Payal
                component.set("v.caseSource",caseObj.Origin);
                if(caseObj.IDCC_Call_Time__c != null){
                component.set("v.caseCallTime",caseObj.IDCC_Call_Time__c);
                }
                else {
                    component.set("v.caseCallTime",'0:0:0');  
                }
                
                helper.checkforProfile(component,event,helper);
                
                //refresh window after each second
                window.setInterval(
                    $A.getCallback(function() {

                        //it will work for Cases which has no closed or cancel status
                        if((caseObj.Status!="Closed" && caseObj.Status!="Cancel") && component.get("v.isAgent")){                          
                            i++;
                            component.set("v.seconds",helper.checkTime(i%60));
                            component.set("v.minutes",helper.checkTime(Math.floor((i/60)%60)));
                            component.set("v.hours",helper.checkTime(Math.floor(i/(60*60))));
                        }
                        
                       
                    } ),1000);}
        })       
        $A.enqueueAction(action);                            
    },
    
    
    //Method to add 0 as prefix if time is in single digit
    checkTime :function(i) {
        if (i<10) {
            i = "0" + i;
        }
        return i;
    },
    
    //Method to set response duration and response type
    setResponseDuration : function(component, event, helper){
        var caseId = component.get("v.recordId"); 
        var action = component.get("c.saveResponseDetails");
        if(component.get("v.isAgent")){
        action.setParams({ 
            "caseId": caseId,
            "timeDuration" : component.get("v.hours")+ ':'+component.get("v.minutes")+':'+component.get("v.seconds")
        });
        action.setCallback(component,function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var resStatus = response.getReturnValue();
            }else{
                console.log('Error is in  Case Handling Component.');
            }
        });
        $A.enqueueAction(action); 
        }
    },
    
    //Added by Vaidehi for Agent Profile only
    checkforProfile :function(component, event, helper) {
        var action = component.get("c.checkForProfile");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS"){
                if(!$A.util.isEmpty(result)){
                    component.set('v.isAgent',response.getReturnValue());
                    //console.log(response.getReturnValue()+'response.getReturnValue()');
                                    }
            }
            else{
                console.log('Error in Case Handling : checforProfile');
            }
        });
        $A.enqueueAction(action); 	
    },
    
})