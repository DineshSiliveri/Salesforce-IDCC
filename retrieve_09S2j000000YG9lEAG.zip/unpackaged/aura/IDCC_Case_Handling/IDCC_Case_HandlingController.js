({
    //This method will be called on init action
    doInit : function(component, event, helper) { 
        //check for Navigation Timing API support
        /*if (window.performance) {
            console.log("window.performance works fine on this browser");
        }*/
        //Checking if page is not refreshed by user
        if (performance.navigation.type == 1) {                
            // component.set("v.refreshAttribute",true);
        } else {            
            // component.set("v.refreshAttribute",false);
            //console.log( "This page is not reloaded");
        }
        //helper.checkforProfile(component, event, helper); 
            helper.getTimingDetails(component, event, helper);
    },    
    
    //This will be called on closing the tab n console
    onTabClosed : function(component, event, helper) {
        var tabId = event.getParam('tabId');
        helper.setResponseDuration(component, event, helper);
        // console.log("Tab closed: " +tabId);
    }, 
    /*
    doInit : function(cmp, event, helper) {        
        var recordId = cmp.get("v.recordId"); 
        var action = cmp.get("c.getCaseHandler");
        //alert('recordId'+recordId);
        action.setParams({ caseId: recordId});
        action.setCallback(this,function(response1){            
            var state = response1.getState();    
            //  alert('state'+state);
            if (state == "SUCCESS")  
            {   var caseObj = response1.getReturnValue();
             var finalTime;                
             if(caseObj.Status=="Closed"){                    
                 finalTime =  ( new Date(caseObj.ClosedDate).getTime() )- ( new Date(caseObj.IDCC_Process_Status_Timestamp__c).getTime());
                 //    alert('finalTime ==>'+finalTime);
                 callTimerClosed(finalTime);                    
             }if(caseObj.Status=="Cancel"){
                 //     alert('entered cancel');
                 finalTime =  ( new Date(caseObj.IDCC_Cancel_Status_Timestamp__c).getTime() )- ( new Date(caseObj.IDCC_Process_Status_Timestamp__c).getTime());
                 //    alert('finalTime ==>'+finalTime);
                 callTimerClosed(finalTime);
             }else if(caseObj.Status=="Process" || caseObj.Status=="In Progress"){                    
                 // finalTime =  ( new Date().getTime() )- ( new Date(caseObj.IDCC_Process_Status_Timestamp__c).getTime());
                 finalTime =   caseObj.IDCC_Process_Status_Timestamp__c; 
                 //        	 alert('finalTime ==>'+cmp);                    
             }else{
                 cmp.set('v.days',0);
                 cmp.set('v.minutes',0);
                 cmp.set('v.hours',0);      
                 cmp.set('v.seconds',0);
             }                
             window.setInterval(
                 $A.getCallback(function() {
                     if(caseObj.Status!="Closed" && caseObj.Status!="Cancel"){
                         callTimerProcess(finalTime);
                     }else if(caseObj.Status=="Closed" || caseObj.Status=="Cancel"){
                         callTimerClosed(finalTime);
                     }
                 } ),1000);                                   
            }                               
        });
        function callTimerClosed(finalTime){             
            if( (finalTime)==true){                
                cmp.set('v.days',0);
                cmp.set('v.minutes',0);
                cmp.set('v.hours',0);      
                cmp.set('v.seconds',0);                
            }else{
                //    alert('days'+Math.floor(finalTime / (1000 * 60 * 60 * 24)));
                //	alert('hours'+Math.floor((finalTime / (1000 * 60 * 60))));
                //	alert('minutes'+Math.floor((finalTime % (1000 * 60 * 60)) / (1000 * 60)));
                //	alert('seconds'+Math.floor((finalTime % (1000 * 60)) / 1000));
                
                cmp.set('v.days',Math.floor(finalTime / (1000 * 60 * 60 * 24)));
                //		cmp.set('v.minutes',Math.floor((finalTime % (1000 * 60 * 60)) / (1000 * 60)));
                cmp.set('v.minutes',Math.floor((finalTime) / (1000 * 60)));
                cmp.set('v.hours',Math.floor((finalTime / (1000 * 60 * 60))));      
                cmp.set('v.seconds',Math.floor((finalTime % (1000 * 60)) / 1000));
            }
        }
        
        function callTimerProcess(processTime){  
            var finalTime =  ( new Date().getTime() )- ( new Date(processTime).getTime());
            if(isNaN(finalTime)==true){
                cmp.set('v.days',0);
                cmp.set('v.minutes',0);
                cmp.set('v.hours',0);      
                cmp.set('v.seconds',0);
            }else if(Math.floor(finalTime / (1000 * 60 * 60 * 24))<0){
                cmp.set('v.days',0);
                cmp.set('v.minutes',0);
                cmp.set('v.hours',0);      
                cmp.set('v.seconds',0);                
            }else{
                cmp.set('v.days',Math.floor(finalTime / (1000 * 60 * 60 * 24)));
                //	cmp.set('v.minutes',Math.floor((finalTime % (1000 * 60 * 60)) / (1000 * 60)));
                cmp.set('v.minutes',Math.floor((finalTime) / (1000 * 60)));
                cmp.set('v.hours',Math.floor((finalTime / (1000 * 60 * 60))));      
                cmp.set('v.seconds',Math.floor((finalTime % (1000 * 60)) / 1000));
            }
        }
        $A.enqueueAction(action);
    }*/
})