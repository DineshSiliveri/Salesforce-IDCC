({
    init : function(component, event, helper) {        
        component.set("v.displayFeaturedArticle",true);
        helper.init(component,event,helper);
        helper.getArticleLikeCountJS(component,event,helper);  
    },
    handleDeviceSimulator : function(component, event, helper) {
        component.set("v.openHomePage",false);
        component.set("v.openDeviceSimulator",true);
        component.set("v.displayFeaturedArticle",false);
    },
    handleBackButton : function(component, event, helper) {
        component.set("v.openHomePage",true);
        component.set("v.openDeviceSimulator",false);
        component.set("v.displayFeaturedArticle",true);
        component.set("v.openDiscussion",false);
        component.set("v.openPage",false);  
    },
    
    openUrlN : function(component, event, helper) {
        helper.openUrlN(component,event,helper);
    },
    openUrlB : function(component, event, helper) {
        helper.openUrlB(component,event,helper);
    },
    openUrlC : function(component, event, helper) {
        helper.openUrlC(component,event,helper);
    },
    handleDiscussion : function(component, event, helper) {
        component.set("v.openHomePage",false);
        component.set("v.openDeviceSimulator",false);
        component.set("v.displayFeaturedArticle",false);
        component.set("v.openDiscussion",true);
        component.set("v.openPage",false);  
    },
    
    backLinkHandler : function(component, event, helper) {
        var level1ToHomePageEvent = component.getEvent("Level1ToHomePageEvent");
        level1ToHomePageEvent.fire();
    },
    postQuestions : function(component, event, helper) {
        component.set("v.openHomePage",false);
        component.set("v.openDeviceSimulator",false);
        component.set("v.displayFeaturedArticle",false);  
        component.set("v.openPage",false);   
        component.set("v.openDiscussion",false);
       
        var navigateURL = window.location.href;
        window.open(navigateURL+'login/', '_self');
        
    },
    handleLoginPage :function(component, event, helper) {
        component.set("v.openHomePage",false);
        component.set("v.openDeviceSimulator",false);
        component.set("v.displayFeaturedArticle",false);
        component.set("v.openDiscussion",false);
        var navigateURL = window.location.href;
        window.open(navigateURL+'login/', '_self');
    },
    
    likeArticle :function(component, event, helper) {
		        
        //component.set("v.likeButton",true);
        console.log('Record id'+ component.get("v.recordId"));
        
        component.set("v.likeCount", component.get("v.likeCount")+1);
        if(component.get("v.likeCount") === 1){
            component.set("v.isLiked",true);
        }
        
        console.log('count****'+component.get("v.likeCount"));
        
        var action = component.get("c.setArticlesLikeCount");
        action.setParams({
            "likeCountOfArticles":component.get("v.likeCount"),
            "articleId":component.get("v.recordId")
        }); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(component.isValid() && state == "SUCCESS"){   
                console.log("SUCCESS");
            }
            else {
                console.log("Unknown error"+errors[0].message);
            }
        });       
        $A.enqueueAction(action);
    },
   
    handleClick : function (component, event, helper) {
        var buttonstate = component.get('v.buttonstate');
        component.set('v.buttonstate', buttonstate);
        //component.set("v.likeCount",1);
        helper.handleLikeCount(component, event, helper);
        
    },
    handleToggle : function (component, event) {
        var enableWifi = component.get("v.enableWifi");
        component.set("v.enableWifi", !enableWifi);
    },
    loginPage : function (component, event) {
       window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/login/', '_self');
    }
})