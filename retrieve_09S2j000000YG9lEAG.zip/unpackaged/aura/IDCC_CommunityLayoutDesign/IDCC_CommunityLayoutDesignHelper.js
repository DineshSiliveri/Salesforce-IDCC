({
    init : function(component,event) {
        component.set("v.displayHeader",true);
        var action1 = component.get("c.getNetworkFeaturedArticles");
        action1.setParams({"article1":"Network"}); 
        action1.setCallback(this, function(response) {
            var state = response.getState();
            if(component.isValid() && state == "SUCCESS"){             
                var records = response.getReturnValue();
                var know = [];
                for(var key in records){    
                    know.push({value:records[key], key:key});  
                }
                component.set("v.knowledgeN", know);
                //console.log('know***'+component.get("v.knowledge"));
            }
            else {
                console.log("Unknown error"+errors[0].message);
            }
        });  
        
        var action2 = component.get("c.getBillingFeaturedArticles");
        action2.setParams({"article2":"Billing"}); 
        action2.setCallback(this, function(response) {
            var state = response.getState();
            if(component.isValid() && state == "SUCCESS"){             
                var records = response.getReturnValue();
                var know = [];
                for(var key in records){    
                    know.push({value:records[key], key:key});  
                }
                component.set("v.knowledgeB", know);
                console.log('know***'+component.get("v.knowledgeB"));
            }
            else {
                console.log("Unknown error"+errors[0].message);
            }
        });       
        
        var action3 = component.get("c.getComplaintFeaturedArticles");
        action3.setParams({"article3":"Complaint"}); 
        action3.setCallback(this, function(response) {
            var state = response.getState();
            if(component.isValid() && state == "SUCCESS"){             
                var records = response.getReturnValue();
                var know = [];
                for(var key in records){    
                    know.push({value:records[key], key:key});  
                }
                component.set("v.knowledgeC", know);
                //console.log('know***'+component.get("v.knowledge"));
            }
            else {
                console.log("Unknown error"+errors[0].message);
            }
        });       
        $A.enqueueAction(action1);
        $A.enqueueAction(action2);
        $A.enqueueAction(action3);
        
    },
    
    openUrlN : function(component, event, helper) {
        //alert('main cmp ');
        var index = event.target.dataset.index;
        console.log('index**'+index);
        var selectedRowID = event.currentTarget.name;
        console.log('selectedRowID&&&'+selectedRowID);
        var knowLst = component.get("v.knowledgeN");
        console.log('length**'+knowLst.length);
        // for(var i in knowLst){
        for(var i=0;i<knowLst.length ; i++){
            if(i == index){
                component.set("v.recordId",knowLst[i].value.Id);  
                component.set("v.recordStr",knowLst[i].value.Title); 
                component.set("v.recordStr1",knowLst[i].value.Internal_Answer__c); 
                component.set("v.recordStr2",knowLst[i].value.IDCC_Article_Part_2__c);  
                component.set("v.recordStr3",knowLst[i].value.IDCC_Article_Part_3__c);
                component.set("v.firstPublishDate",knowLst[i].value.LastPublishedDate); 
                console.log('string&&'+ component.get("v.recordId"));
                break;
            }
        } 
        
        component.set("v.openHomePage",false);
        component.set("v.openDeviceSimulator",false);
        component.set("v.displayFeaturedArticle",false);  
        component.set("v.openPage",true);   
        component.set("v.openDiscussion",false);
        console.log('openPage&&&'+component.get("v.openPage"));
        
    },
    openUrlB : function(component, event, helper) {
        var index = event.target.dataset.index;
        console.log('index**'+index);
        //console.log('index**'+index);
        var selectedRowID = event.currentTarget.name;
        console.log('selectedRowID&&&'+selectedRowID);
        var knowLst = component.get("v.knowledgeB");
        console.log('length**'+knowLst.length);
        // for(var i in knowLst){
        for(var i=0;i<knowLst.length ; i++){
            if(i == index){
                component.set("v.recordId",knowLst[i].value.Id);  
                component.set("v.recordStr",knowLst[i].value.Title); 
                component.set("v.recordStr1",knowLst[i].value.Internal_Answer__c); 
                component.set("v.recordStr2",knowLst[i].value.IDCC_Article_Part_2__c);  
                component.set("v.recordStr3",knowLst[i].value.IDCC_Article_Part_3__c);
                component.set("v.firstPublishDate",knowLst[i].value.LastPublishedDate); 
                
                console.log('string&&'+ component.get("v.recordId"));
                break;
            }
        } 
        
        component.set("v.openHomePage",false);
        
        component.set("v.openDeviceSimulator",false);
        component.set("v.displayFeaturedArticle",false);  
        component.set("v.openPage",true);   
        component.set("v.openDiscussion",false);
        console.log('openPage&&&'+component.get("v.openPage"));
        
    },
    openUrlC : function(component, event, helper) {
        var rowIndex = event.currentTarget.parentElement.parentElement.id ;
        //var index =  event.getSource().get("v.name");
        console.log('rowIndex&&&'+rowIndex);
        var index = event.target.dataset.index;
        console.log('index**'+index);
        //console.log('index**'+index);
        var selectedRowID = event.currentTarget.name;
        console.log('selectedRowID&&&'+selectedRowID);
        var knowLst = component.get("v.knowledgeC");
        console.log('length**'+knowLst.length);
        // for(var i in knowLst){
        for(var i=0;i<knowLst.length ; i++){
            if(i == index){
                component.set("v.recordId",knowLst[i].value.Id);  
                component.set("v.recordStr",knowLst[i].value.Title); 
                component.set("v.recordStr1",knowLst[i].value.Internal_Answer__c); 
                component.set("v.recordStr2",knowLst[i].value.IDCC_Article_Part_2__c);  
                component.set("v.recordStr3",knowLst[i].value.IDCC_Article_Part_3__c);
                component.set("v.firstPublishDate",knowLst[i].value.LastPublishedDate); 
                this.getArticleLikeCountJS(component, knowLst[i].value.Id);
                console.log('string&&'+ component.get("v.recordId"));
                break;
            }
        } 
        
        component.set("v.openHomePage",false);
        
        component.set("v.openDeviceSimulator",false);
        component.set("v.displayFeaturedArticle",false);  
        component.set("v.openPage",true);   
        component.set("v.openDiscussion",false);
        console.log('openPage&&&'+component.get("v.openPage"));
        
    },
    
    handleLikeCount : function (component, event, helper) {
        //component.set("v.likeCount",1);
        var articleId =component.get("v.recordId") ;
        console.log('Id***'+articleId);
        //if(component.get("v.likeCount")<=1)
        component.set("v.likeCount", component.get("v.likeCount")+1);
        console.log('count1****'+component.get("v.likeCount"));
        var action = component.get("c.getArticlesLikeCount");
        action.setParams({"article":"articleId"}); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(component.isValid() && state == "SUCCESS"){   
                component.set("v.likeCount", component.get("v.likeCount")+1);
                
                /*var records = response.getReturnValue();
                var know = [];
                for(var key in records){    
                    know.push({value:records[key], key:key});  
                }
                component.set("v.knowledgeC", know);
                console.log('know***'+component.get("v.knowledge"));*/
            }
            else {
                //console.log("Unknown error"+errors[0].message);
                console.log("error");
            }
        });       
        $A.enqueueAction(action);
    },
    
    getArticleLikeCountJS : function (component, knowledgeId) {
        console.log('--recordId---',knowledgeId);
        var action = component.get("c.getArticlesLikeCount");
        action.setParams({
            "articleId":knowledgeId
        }); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            console.log('state ',state,'result',JSON.stringify(response.getReturnValue()));
            if(component.isValid() && state == "SUCCESS"){   
                if(result > 0) {
                    component.set("v.isLiked",true);
                    component.set("v.likeCount",1);
                } else {
                    console.log('result '+result);
                }
            }
            else {
                //console.log("Unknown error"+errors[0].message);
            }
        });       
        $A.enqueueAction(action);  
    }
})