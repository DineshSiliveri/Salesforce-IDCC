({
    getArticleDetails : function(component, event, page) {
        //Assigning Label to service console tab
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.setTabLabel({
                tabId: focusedTabId,
                label: "Unanswered Article Report" //set label you want to set
            });
            //Assigning icon to tab       
            workspaceAPI.setTabIcon({
                tabId: focusedTabId,
                icon: "standard:report", //set icon you want to set
                iconAlt: "report" //set label tooltip you want to set
            });
        });
        
        //returning list of feed items having 
        //var pageSize = component.get("v.pageSize");
        console.log('Page***'+component.get("v.page"));
        var action = component.get("c.getPostDetails");
        // set the parameters to method 
        action.setParams({
            "pageNumber": page,
            //"recordToDisply": recordToDisply
        });
        // set a call back 
        action.setCallback(component,function(response) {
            var state = action.getState();
            if (state == "SUCCESS") { 
                var responseValue = response.getReturnValue(); 
                if(responseValue!=null || responseValue!=undefined || responseValue != ''){
                    component.set("v.reportList" ,responseValue.fItemList);
                   console.log('responseValue.total**'+JSON.stringify(responseValue.fItemList));
                    //var recordToDisply = component.find("recordSize").get("v.value");
                    //component.set("v.totalSize", responseValue.length);
                    component.set("v.page", responseValue.page);
                    component.set("v.total", responseValue.total);
                    if(responseValue.total == 0 ){
                    component.set("v.pages", 1);
                    }
                    else if(responseValue.total != 0){
                    component.set("v.pages", Math.ceil(responseValue.total/100 ));
                    }
                }
            } 
            else {
                    console.log("Unknown error"+errors[0].message);
                }
        });
        $A.enqueueAction(action);
    },
    
    navigateToRecord : function(component, event) {       
        var idx = event.target.getAttribute('data-index');   
        console.log('idx**'+idx);
        var searchRes = component.get("v.reportList");
        console.log('searchRe**'+searchRes);
        // var feedId = component.get("v.reportList")[idx];
        //alert(feedId.Id);        
        var navEvent = $A.get("e.force:navigateToSObject");
        if(navEvent){
            console.log('outside');
            component.set("v.navigateCheck",true);
            navEvent.setParams({
                recordId: idx,
                slideDevName: "detail"
            });
            navEvent.fire(); 
        }
        else{
            console.log('inside');
            window.location.href = '/one/one.app#/sObject/'+idx+'/view'
        }
        var navService = component.find("navService");
        // Uses the pageReference definition in the init handler
        
       /* var pageReference = component.get("v.pageReference");
        console.log('pageReference**'+pageReference);
        event.preventDefault();
        navService.navigate(pageReference);*/
    },
    
    getSearchDetails : function(component, event,SelbyUsr, userEnt,page, recordToDisply) {  
        var action = component.get("c.getSearchDetails");
        // set the parameters to method 
        action.setParams({
            "selectedbyUser": SelbyUsr,
            "selectedText": userEnt,
             "pageNumber": page,
            //"recordToDisply": recordToDisply
           
        });
        // set a call back 
        action.setCallback(component,function(response) {
            var state = action.getState();
            /*var recordToDisply = component.find("recordSize").get("v.value");
            console.log('recordToDisply***'+recordToDisply);*/
           var labelValue = $A.get("$Label.c.IDCC_CreatedBy");
            if (state == "SUCCESS") { 
                var responseValue = response.getReturnValue();                
                if(responseValue!=null || responseValue!=undefined){
                    if(SelbyUsr == labelValue){
                    component.set("v.reportList" ,responseValue.fItemList); 
                        console.log('report***'+component.get("v.reportList"));
                        component.set("v.page", responseValue.page);
                        component.set("v.total", responseValue.total);
                        console.log('Total**'+component.get("v.total"));
                        if(responseValue.total == 0 ){
                            component.set("v.pages", 1);
                        }
                        else if(responseValue.total != 0){
                            component.set("v.pages", Math.ceil(responseValue.total/100 ));
                        }
                    }
                   /*else{
                        console.log('inside**');
                        component.set("v.reportList" ,responseValue.feedTitleList); 
                        console.log('report***'+component.get("v.reportList"));
                        component.set("v.page", responseValue.page);
                        component.set("v.total", responseValue.total);
                       console.log('Total**'+component.get("v.total"));
                        component.set("v.pages", Math.ceil(responseValue.total / recordToDisply));
                    }*/
                    //component.set("v.totalSize", responseValue.length);
                   
                }
            } 
            else {
                console.log("Unknown error"+errors[0].message);
            }
        });
        $A.enqueueAction(action);
    }
 
})