({
    getArticleDetails : function(component, event, helper) {
     
        // this function call on the component load first time     
        // get the page Number if it's not define, take 1 as default
        var page = component.get("v.page") || 1;
        // get the select option (drop-down) values.   
       // var recordToDisply = component.find("recordSize").get("v.value");
        // call the helper function 
        //helper.getArticleDetails(component, event, page, recordToDisply);
        helper.getArticleDetails(component, event, page);
        console.log('check**'+component.get("v.navigateCheck"));
        if(component.get("v.navigateCheck") == true){
            console.log('check**');
        }
    },
    
    navigateToRecord : function(component, event, helper) {
        helper.navigateToRecord(component, event);
    },
    
    navigate: function(component, event, helper) {
        // this function call on click on the previous page button  
        var page = component.get("v.page") || 1;
        // get the previous button label  
        var direction = event.getSource().get("v.label");
        // get the select option (drop-down) values.  
       // var recordToDisply = component.find("recordSize").get("v.value");
        // set the current page,(using ternary operator.)  
        page = direction === "Previous Page" ? (page - 1) : (page + 1);
        console.log('abc**');
        // call the helper function
        //helper.getArticleDetails(component, event, page); 
    },
    
    onSelectChange: function(component, event, helper) {
        // this function call on the select opetion change,	 
        var page = 1
       // var recordToDisply = component.find("recordSize").get("v.value");
        var SelbyUsr = component.find("userSel").get("v.value");
        var userEnt = component.find("userEnt").get("v.value");
        var onSearch = component.find("onSearch").get("v.value");
        console.log(event.getSource().get("v.value"));
        console.log('userEnt**!!!'+userEnt);
        console.log('onSelect**!!!'+SelbyUsr);
        console.log('boolean***'+ component.get("v.filterSearch"));
        if(SelbyUsr != undefined && userEnt != undefined){
        component.set("v.filterSearch",true);
        }
        if((userEnt == null && onSearch == null) || (userEnt == undefined && onSearch == undefined ) || (onSearch == '' && userEnt == '')
           || (userEnt == undefined ) || (onSearch == undefined ) ){
            if(component.get("v.filterSearch") == false){
            helper.getArticleDetails(component, event, page, recordToDisply);
          }
        }
        if(userEnt != undefined && SelbyUsr != undefined ){ 
            console.log('userEnt**!!!Yes'+userEnt);
            if(component.get("v.filterSearch") == true){
            helper.getSearchDetails(component, event,SelbyUsr, userEnt,page);
            }
        }
    },
    onSelect : function(component, event, helper) {
        component.find("userEnt").set("v.value","");
    },
    onSearch : function(component, event, helper) {
       
        var SelbyUsr = component.find("userSel").get("v.value");
        /*if(SelbyUsr == 'Article Name'){
            console.log('SelbyUsr***'+SelbyUsr);
        component.set("v.displayRes",true);
            console.log('value***'+component.get("v.displayRes"));
        }*/
        if(SelbyUsr == 'Created By'){
            console.log('SelbyUsr***'+SelbyUsr);
        component.set("v.displayRes",false);
            console.log('value***'+component.get("v.displayRes"));
        }
        var userEnt = component.find("userEnt").get("v.value");
        var page = component.get("v.page") || 1;
        /*var recordToDisply = component.find("recordSize").get("v.value");
        console.log('recordToDisply***'+recordToDisply);*/
        if(userEnt == undefined){
            helper.getArticleDetails(component, event, page);
        }
        if(SelbyUsr != undefined && userEnt != undefined){
        component.set("v.filterSearch",true);
       
        helper.getSearchDetails(component, event,SelbyUsr,userEnt,page);
        }
    }
})