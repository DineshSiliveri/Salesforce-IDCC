({
    doInit : function(component, event, helper) {  
       component.set('v.selectedOverview',true);
        var action2 = component.get("c.getUserId");
        action2.setCallback(this, function(response) {
            var state = response.getState();
            //alert('state '+state);
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                //alert('res '+res);
                console.log('res ',res);
                component.set('v.userContactId', res);
               
               	var userId = component.get("v.userContactId");
              
                component.set('v.accountName', userId.Contact.Account.Name);         
                console.log('account name ',userId.Contact.Account.Name);
                //helper.showAccountDetails(component, event, helper);
                helper.showCaseCount(component, event, helper);
                helper.showCaseNewCount(component, event, helper);
                helper.showCaseProgressCount(component, event, helper);
                helper.showCaseCloseCount(component, event, helper);
                var action = component.get("c.fetchUserDetail");
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        var res = response.getReturnValue();
                        component.set('v.oUser', res);
                    }
                    else if (state === "INCOMPLETE") {
                        // do something
                    }
                        else if (state === "ERROR") {
                            var errors = response.getError();
                            if (errors) {
                                if (errors[0] && errors[0].message) {
                                    console.log("Error message: " + 
                                                errors[0].message);
                                }
                            } else {
                                console.log("Unknown error");
                            }
                        }
                    
                });
                $A.enqueueAction(action);	
            }                             
        });
        $A.enqueueAction(action2);	
    },
    
    handleClick : function(component, event, helper) {
        component.set("v.modalYes", true);
    },
    
    cancelModal : function(component, event, helper) {
        component.set("v.modalYes", false);
    },    
    tabSelected: function(component,event,helper) {
        var currentTab = component.get("v.selTabId");
        if(currentTab == 'one'){
            component.set('v.selectedTab',true);
        }
        else {
            component.set('v.selectedTab',false);
        }
    },
    createCase : function(component, event, helper) {
        console.log('in create case controller');
        var action = component.get("c.saveCase");
        var userId = component.get("v.userContactId");        
        console.log('act id in showCase in progressCount ',userId.Contact.AccountId);
        //action.setParams({"accountId": userId.Contact.AccountId}); 
        action.setParams({
            "accountId" : userId.Contact.AccountId,
            "objeCase" : component.get("v.newCase")
        });
        action.setCallback(this, function(res){
            console.log('response',res.getReturnValue());
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Success!",
                "type": "success",
                "message": "My Custom Record Saved Successfully"
            });
            toastEvent.fire();
        })
        component.set("v.modalYes", false);
        window.location.reload();
        $A.enqueueAction(action);      
    }
})