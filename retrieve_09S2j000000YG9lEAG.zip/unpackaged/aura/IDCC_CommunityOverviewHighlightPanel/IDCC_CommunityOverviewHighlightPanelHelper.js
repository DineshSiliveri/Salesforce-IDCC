({
    showAccountDetails: function(component, event, helper) {
        alert('in showAccountDetails');
        var userId=component.get("v.userContactId");
        console.log('in showAccountDetails '+userId.Contact.AccountId);
        var action = component.get("c.getAccount");//get data from controller  
        //var objCase = component.get("v.objCase");        
        action.setParams({"accountId": userId.AccountId}); 
        action.setCallback(this, function(a) {
            alert(a.getReturnValue());
            component.set("v.account", a.getReturnValue());//set data in the page variable  
            
            component.set("v.contactId", a.getReturnValue());
            console.log('contactId ',contactId);
            alert('contactId ',contactId);
        });
        $A.enqueueAction(action);
    },
    showCaseCount: function(component, event, helper) {
        //alert('in showCaseCount');
        var action = component.get("c.getCaseCount");//get data from controller       
        var userId = component.get("v.userContactId");        
        console.log('act id ',userId.Contact.AccountId);
        action.setParams({"accountId": userId.Contact.AccountId}); 
        
        action.setCallback(this, function(a) {
            var state = a.getState();
            //alert('state '+state);
           
            if (state === "SUCCESS") {
            console.log('state ',state ,' getReturnValue ',a.getReturnValue());
            component.set("v.caseCount", a.getReturnValue());//set data in the page variable  
            //console.log('case count ',JSON.stringify(component.get("v.caseCount")));
            }
            else
                console.log('error in show count');
        });
        $A.enqueueAction(action);
    },
    showCaseNewCount: function(component, event, helper) {
        console.log('new cases**');
        var action = component.get("c.getNewOpenCaseStatusCount");//get data from controller       
        var userId = component.get("v.userContactId");        
        console.log('act id in showCaseNewCount',userId.Contact.AccountId);
        action.setParams({"accountId": userId.Contact.AccountId}); 
        action.setCallback(this, function(a) {
            
            component.set("v.caseNew", a.getReturnValue());  
            
        });
        $A.enqueueAction(action);
    },
    showCaseProgressCount: function(component, event, helper) {
        var action = component.get("c.getInProgressCaseStatusCount");//get data from controller 
        var userId = component.get("v.userContactId");        
        console.log('act id in showCase in progressCount ',userId.Contact.AccountId);
        action.setParams({"accountId": userId.Contact.AccountId}); 
        action.setCallback(this, function(a) {  
            component.set("v.caseProgress", a.getReturnValue());//set data in the page variable  
            
        });
        $A.enqueueAction(action);
    },
    showCaseCloseCount: function(component, event, helper) {
        var action = component.get("c.getclosedCaseStatusCount");//get data from controller  
       var userId = component.get("v.userContactId");        
        console.log('act id in showCaseNewCount',userId.Contact.AccountId);
        action.setParams({"accountId": userId.Contact.AccountId});         action.setCallback(this, function(a) {
            component.set("v.caseClose", a.getReturnValue());//set data in the page variable  
            
        });
        $A.enqueueAction(action);
    } 
})