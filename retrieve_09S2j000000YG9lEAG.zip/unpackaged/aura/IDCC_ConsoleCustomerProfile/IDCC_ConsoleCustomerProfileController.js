({
	showCustDetails : function(component, event, helper) {
		//helper.showCustDetails(component, event);
		var recordId = component.get("v.recordId");
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleForm");	
        var tmp;
        var action1 = component.get("c.setViewStat");    
        var csId = component.get("v.recordId"); 
        action1.setParams({
            "caseId":csId
        });
        // Set up the callback
        action1.setCallback(this, function(response) {
            var result =response.getReturnValue();
            component.set('v.caseDetails', response.getReturnValue());    
            var caseDataLocation = component.get('v.caseDetails.IDCC_Siebel_Data_Location__c');
        		 tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_CustomerProfileConsoleForm?recordId='+recordId+'&pagetype=customerprofile&location='+caseDataLocation;
           		 component.set("v.URL",tmp);

            /*
            //alert('caseDataLocation 123: '+caseDataLocation);
            console.log('caseDataLocation***'+caseDataLocation);
            //tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_CustomerProfileConsoleForm?recordId='+recordId+'&pagetype=customerprofile&location='+caseDataLocation;
            console.log('URL***'+tmp); 
        	if(caseDataLocation == 'CATALIST'){
                //alert('case siebel value is catalist==<');
                 tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_CustomerProfileConsoleForm?recordId='+recordId+'&pagetype=customerprofile&location='+caseDataLocation;
                // tmp =staticLabel+'apiName=Query_Customer_Profile&resObjName=Query_Customer_Profile_catalist_Res&recordId='+recordId+'&pagetype=customerprofile&location='+caseDataLocation;
           		 component.set("v.URL",tmp);
            }else if(caseDataLocation == 'ICARE'){
                //alert('case siebel value is ICARE==>');
                 tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_CustomerProfileConsoleForm?recordId='+recordId+'&pagetype=customerprofile&location='+caseDataLocation;
               // tmp =staticLabel+'apiName=Query_Customer_Profile&resObjName=Query_Customer_Profile_iCare_Res&recordId='+recordId+'&pagetype=customerprofile&location='+caseDataLocation;
           		 component.set("v.URL",tmp);
            }*/
        });
        $A.enqueueAction(action1);
        //alert(staticLabel);
        //var tmp =staticLabel+'apiName=Query_Customer_Profile&resObjName=Query_Customer_Profile_Res&recordId='+recordId;
        //'https://indosat--indosatdev--c.cs75.visual.force.com/apex/IDCC_ConsoleForm?apiName=Query_Customer_Profile&resObjName=Query_Customer_Profile_Res&recordId=5000w000001UmaFAAS';
        //alert(tmp);
        //component.set("v.URL",tmp);
       console.log('URL'+tmp);
        helper.scrolltoTop();
      
	},
    
    familyNFriends : function(cmp, event, helper) {
    	var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleForm");
		var recordId = cmp.get("v.recordId");         
        var tmp = staticLabel+'resObjName=Query_Family_and_Friends_Res&apiName=Query_Family_and_Friends&recordId='+recordId;
        cmp.set("v.URL",tmp);          
	},
    threeFreequently : function(cmp, event, helper) {
    	var staticLabel = $A.get("$Label.c.IDCC_ThreeFrequentlyMSISDN");
		var recordId = cmp.get("v.recordId");         
        var tmp = staticLabel+'apiName=Query_Three_Frequently&resObjName=Query_Three_Frequently_Res&recordId='+recordId;
        cmp.set("v.URL",tmp);          
	},
    showSpinner : function (component, event, helper) { 
        var spinner = component.find('spinner');
        var evt = spinner.get("e.toggle");
        evt.setParams({ isVisible : true });
        evt.fire();    
    },     
    orderHistory : function(cmp, event, helper) {
    	var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
		var recordId = cmp.get("v.recordId");         
        var tmp = staticLabel+'resObjName=Query_Order_History_Res&apiName=Query_Order_History&recordId='+recordId;
        cmp.set("v.URL",tmp);          
	},
   
    queryCommunities : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Communities&resObjName=Query_Communities_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},
    hideSpinner: function (component, event, helper) { 
        var spinner = component.find('spinner');
         $A.getCallback(function() {
        cmp.set("v.visible", true);
    	}), 5000

        $A.util.removeClass(spinner, 'loadSpinner');
        $A.util.addClass(spinner, 'newLoadSpinner');        
        $A.util.addClass(spinner, "slds-hide");
    }
})