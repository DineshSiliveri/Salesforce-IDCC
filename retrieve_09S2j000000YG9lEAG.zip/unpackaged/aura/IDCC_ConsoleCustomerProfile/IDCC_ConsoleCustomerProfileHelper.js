({
    /*showCustDetails : function(component, event) {
        var action1 = component.get("c.showCust");    
        var csId = component.get("v.recordId"); 
        action1.setParams({
            "caseId":csId
        });
        
        // Set up the callback
       action1.setCallback(this, function(response) {
            component.set('v.caseDetails', response.getReturnValue());             
        });
        
        // Queue this action to send to the server
        $A.enqueueAction(action1);	
    },*/
    
    scrolltoTop : function() {
		 $('body, html').animate({
            scrollTop: $('[id^="topDiv"]').offset().top - 27
        }, 10);
	} 
})