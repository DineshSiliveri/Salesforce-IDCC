({
	getCases : function(component, event, helper) {
        console.log('in get cases controller', component.get("v.recordId"));
        helper.getCases(component);//get data from the helper        
    }
})