({
    
    getCases: function(component, event, helper) {
        console.log('in getcasess helper**')
        component.set('v.mycolumns', [
            
            {label: 'Case Number', fieldName: 'linkName', type: 'url', 
             typeAttributes: {label: { fieldName: 'CaseNumber' }, target: '_blank'}},
            {label: 'Case status', fieldName: 'Status', type: 'text'},
            {label: 'Case Type', fieldName: 'Type', type: 'Text'},
            {label: 'subject', fieldName: 'Subject', type: 'Text'},
            {label: 'Description', fieldName: 'Description', type: 'Text'}
        ]);
        var action = component.get("c.getCaseDetails");
        var objCase = component.get("v.recordId"); 
        console.log('===AccountId show cases====',objCase);
        console.log('===Account.Name show cases====',objCase.Name);
        action.setParams({"accountId": objCase});
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                //alert('success');
                var records =response.getReturnValue();
                console.log('succes ',records);                 
                records.forEach(function(record){
                    //record.linkName = '/'+record.Id;
                    record.linkName ='https://indosatdev-indosatooredoo.cs75.force.com/SelfHelpPortal/s/displaycaserecord?id='+record.Id;
                   //record.linkName = 'https://indosat--indosatdev.lightning.force.com/c/demoApp.app?id='+record.Id;
                   // record.linkName ='/'+record.Id;
                   
                    /*var evt = $A.get("e.force:navigateToComponent");
                    evt.setParams({
                        componentDef : "c:IDCC_ArticleSearch",
                        componentAttributes :{
                           recordId : "ka00w0000004OTKAA2"
                        }
                    });
                    evt.fire();*/
                    
                    
                });
                console.log('succes ',records);
                component.set("v.Cases", records);
            }
        });
        $A.enqueueAction(action);
    }
})