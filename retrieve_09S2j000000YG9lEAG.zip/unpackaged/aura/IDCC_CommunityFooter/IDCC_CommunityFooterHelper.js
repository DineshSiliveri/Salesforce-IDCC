({
    //Redirecting to Facebook link
    FacebookLink : function(component, event) {        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": $A.get("$Label.c.IDCC_Community_FacebookLink")
        });
        urlEvent.fire();
    },
    
    //Redirecting to Youtube link
    YoutubeLink : function(component, event) {      
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": $A.get("$Label.c.IDCC_Community_YoutubeLink")
        });
        urlEvent.fire();
    },
    
    //Redirecting to Instagram link   
    InstagramLink : function(component, event) {        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": $A.get("$Label.c.IDCC_Community_InstagramLink")
        });
        urlEvent.fire();
    },
    
    //Redirecting to Twitter link
    TwitterLink : function(component, event) {        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": $A.get("$Label.c.IDCC_Community_TwitterLink")
        });
        urlEvent.fire();
    },
})