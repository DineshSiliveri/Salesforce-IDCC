({
	FacebookLink : function(component, event, helper) {        
		helper.FacebookLink(component, event);
	},
    
    YoutubeLink : function(component, event, helper) {        
		helper.YoutubeLink(component, event);
	},
    
    InstagramLink : function(component, event, helper) {        
		helper.InstagramLink(component, event);
	},
    
    TwitterLink : function(component, event, helper) {        
		helper.TwitterLink(component, event);
	}
})