({
    doInit : function(component, event, helper){
        
        var action = component.get("c.fetchUserDetail");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                component.set('v.oUser', result);
            } else {
                console.log("Unknown error");
            }
        });
        $A.enqueueAction(action);	
    },
    
    getaccountDetailsforProfile : function(component, event, helper)
    {
        //alert('in getaccountDetailsforProfile');
        var action = component.get("c.getUserId");
        action.setCallback(this, function(response) {
            var state = response.getState();
            //alert('state '+state);
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                console.log('res ',res);
                component.set('v.userId', res);                
            }
        });
        $A.enqueueAction(action);	
    }
})