({
	doInit : function(component, event, helper) {
		helper.doInit(component, event, helper);
        helper.getaccountDetailsforProfile(component, event, helper);
	}
})