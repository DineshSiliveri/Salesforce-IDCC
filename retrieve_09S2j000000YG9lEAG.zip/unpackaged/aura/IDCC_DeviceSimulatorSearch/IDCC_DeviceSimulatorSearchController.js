({
    doInit : function(component, event, helper) {
        var action = component.get("c.getDeviceData");
        action.setParams({"recordId": component.get("v.recordId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                component.set("v.deviceRecord", result);
                var level = component.get("v.deviceRecord").Level__c;
                if(level == 1){
                     component.set("v.isOpen2Level", true);
                }
                if(level == 2){
                     helper.getDataForLevel3(component, event, helper);
                }
                if(level == 3){
                     helper.getDataForLevel4(component, event, helper);
                }
            }
            else{
                console.log('Error in IDCC_DeviceSimulatorsearch : handleClickHere');
            }
        });
        $A.enqueueAction(action);
    },
    handleSearchEvent :function(component, event, helper) {
         var recordId = event.getParam("recordId");
         component.set("v.recordId",recordId);
         helper.getDataForLevel3(component, event, helper);
    }
    
})