({
	getDataForLevel3 : function(component, event, helper) {
        var action = component.get("c.getDeviceDataForLevel3");
        action.setParams({"recordId": component.get("v.recordId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                component.set("v.level3Data", result);
                component.set("v.isOpen3Level", true);
            }
            else{
                console.log('Error in IDCC_DeviceSimulatorSearch : getDataForLevel3');
            }
        });
        $A.enqueueAction(action); 
	},
    getDataForLevel4DropDown : function(component, event, helper) {
    	var action = component.get("c.getLevel2NameLst");
        action.setParams({selectedLevel2DeviceId : component.get("v.level2DeviceId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                var imageURLLevel2NameLst = [];
                var imageURLLevel2 =[];
                for(var key in result){
                    imageURLLevel2NameLst.push({value:result[key].Name, key:result[key].Id});
                }
                component.set("v.level2Lst", imageURLLevel2NameLst);
                // helper.getDataForLevel3(component, event, helper);
                component.set("v.isOpen4Level", true);
              
            }
            else{
                console.log('Error in IDCC_DeviceSimulatorSearch : getDataForLevel4DropDown');
            }
        });
        $A.enqueueAction(action);
	},
    getDataForLevel4 : function(component, event, helper) {
        var action = component.get("c.getDeviceDataForLevel4");
        action.setParams({"recordId": component.get("v.recordId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                component.set("v.level4Data", result);
                component.set("v.level2DeviceId", result[2]);
                helper.getDataForLevel4DropDown(component, event, helper);
            }
            else{
                console.log('Error in IDCC_DeviceSimulatorSearch : getDataForLevel4');
            }
        });
        $A.enqueueAction(action); 
	}
})