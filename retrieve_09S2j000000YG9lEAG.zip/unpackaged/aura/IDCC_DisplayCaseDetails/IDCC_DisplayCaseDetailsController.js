({
    doInit : function(component, event, helper) {
        var page = component.get("v.page") || 1;
        helper.getCaseDetails(component, event, page);
        helper.getFileData(component, event, helper);
        helper.getCaseComments(component, event, helper);
        /* window.setTimeout(
            $A.getCallback(function() {
                var pid = helper.getJsonFromUrl();
                component.set("v.recordId", pid.id);
                helper.getCaseDetails(component, event, helper);
                helper.getFileData(component, event, helper);
                helper.getCaseComments(component, event, helper);
            }), 500
        );*/
    },
    caseInfoTab :function(component, event, helper) {
        var tab1 = component.find('caseInfoId');
        var TabOnedata = component.find('CaseInfoDataId');
        $A.util.addClass(tab1, 'slds-active');
        $A.util.addClass(TabOnedata, 'slds-show');
        $A.util.removeClass(TabOnedata, 'slds-hide');
    },
    attachmentTab :function(component, event, helper) {
        var tab1 = component.find('AttachmentId');
        var TabOnedata = component.find('AttachmentDataId');
        $A.util.addClass(tab1, 'slds-active');
        $A.util.addClass(TabOnedata, 'slds-show');
        $A.util.removeClass(TabOnedata, 'slds-hide');
    },
    caseCommentTab :function(component, event, helper) {
        var tab1 = component.find('CaseCommentId');
        var TabOnedata = component.find('CaseCommentDataId');
        $A.util.addClass(tab1, 'slds-active');
        $A.util.addClass(TabOnedata, 'slds-show');
        $A.util.removeClass(TabOnedata, 'slds-hide');
    },
    handleUploadFinished: function(component, event, helper) {
        var uploadedFiles = event.getParam("files");
        var fileIds=[];
        uploadedFiles.forEach(function(file){
            fileIds.push(file.documentId);
        });
        component.set('v.fileIds', fileIds);
        component.set("v.UploadedFiles",uploadedFiles);
        $A.get('e.force:refreshView').fire();
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "type" : "success",
            "message": uploadedFiles.length+" files has been uploaded successfully!"
        });
        toastEvent.fire();
    },
    handleBack : function(component, event, helper) {
        window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/selfhelploginpage', '_self');
    },
    handleAttachFileScroll : function(component, event, helper) {
        var elmnt = document.getElementById('AllAttachments');
        elmnt.scrollIntoView();   
    },
    handleAddCommentScroll : function(component, event, helper) {
        var elmnt = document.getElementById('CaseComments');
        elmnt.scrollIntoView();  
        component.set("v.openCommentInputBox",true); 
    },
    handleAddComment :function(component, event, helper) {
        component.set("v.openCommentInputBox",true); 
    },
    cancelCaseComment : function(component, event, helper) {
        component.set("v.openCommentInputBox",false); 
    },
    handleDeleteFile : function(component, event, helper) {
        var fileId = event.currentTarget.id;
        component.set("v.fileId",fileId); 
        component.set("v.openFileDeleteConfrim",true); 
    },
    handleDeleteDoc : function(component, event, helper) {
        helper.handledelete(component, event, helper,component.get("v.fileId"));
    },
    createNewComments : function(component, event, helper){
        helper.createCaseCommentsHandler(component, event, helper); 
    },
    closeModel : function(component, event, helper) {
        component.set("v.openFileDeleteConfrim", false);
    },
    closeFileViewModal : function(component, event, helper) {
        component.set("v.isOpenFileViewModal", false);
    },
    getSelectedFile : function(component, event, helper) {
        component.set("v.isOpenFileViewModal" , true);
        component.set("v.selectedDocumentId" , event.currentTarget.getAttribute("data-Id")); 
    }
    
})