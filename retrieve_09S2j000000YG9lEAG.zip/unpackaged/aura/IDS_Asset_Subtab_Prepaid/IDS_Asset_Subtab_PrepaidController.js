({
    doInit : function(component, event, helper) {
        
        //Get the parameter being passed from the main case page
        var pageReference = component.get('v.pageReference');
        component.set("v.recordId", pageReference.state.c__recordid);
        component.set("v.PrepaidScreen", pageReference.state.c__PrepaidScreen);
        component.set("v.MainPageController", pageReference.state.c__MainPageController);
        component.set("v.cmpTitle", pageReference.state.c__title);
        component.set("v.cmpLtIcon", pageReference.state.c__icon);
        
        helper.CreateWrapper(component,event, helper);
    }
})