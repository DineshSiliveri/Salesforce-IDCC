({    
    //This function is for spinner purposes
    showSpinner : function (component, event) {
        var spinner = component.find("spinner");
        $A.util.removeClass(spinner, "slds-hide");
        $A.util.addClass(spinner, "slds-show");
    },
    
    //This function is for spinner purposes
    hideSpinner : function (component, event) {
        var spinner = component.find("spinner");
        $A.util.removeClass(spinner, "slds-show");
        $A.util.addClass(spinner, "slds-hide");
    },
    
    //This function will call the apex controller and return a wrapper with information needed
    CreateWrapper: function(component, event, helper){
        this.showSpinner(component, event);
        var RecordID = component.get("v.recordId");
        var MainPageController = component.get("v.MainPageController");
        if (MainPageController === undefined || RecordID === undefined) {
            console.log('DBG a parameter is undefined');
            return;
        }        
        var action = component.get("c.doContsructWrapper");
        if (!action) {
            return;
        }
        action.setParams({
            RecordID: RecordID,
            MainPageController: MainPageController
        });

        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log('DBG asset prepaid state: ', state);
            if (state == "SUCCESS") {
                console.log('DBG asset prepaid allValues: ', JSON.stringify(response.getReturnValue()));
                var allValues = response.getReturnValue();
                component.set('v.ResponseWrapper', allValues);
                helper.GetIFrameInfo(component,event, helper);
            }
            else{
                console.log('State is a Failure');
                component.set('v.Error', true);
            }
        });
        $A.enqueueAction(action);
    },
    
    //This function will call the apex controller and return the iframe link
    GetIFrameInfo: function(component, event, helper){
        var AssetRecord = component.get("v.ResponseWrapper.RelatedAssetRecord");
        var PrepaidScreen = component.get("v.PrepaidScreen");
        
        if(PrepaidScreen == 'None'){
            console.log('Error');
        }
        else{
            var action = component.get("c.iframecontroller");
            action.setParams({
                AssetRecord: AssetRecord,
                PrepaidScreen: PrepaidScreen
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state == "SUCCESS") {
                    var allValues = response.getReturnValue();
                    component.set('v.Link', allValues);
                }
                else{
                    console.log('State is failure');
                }
                this.hideSpinner(component, event);
            });
            $A.enqueueAction(action);
        }
    }
})