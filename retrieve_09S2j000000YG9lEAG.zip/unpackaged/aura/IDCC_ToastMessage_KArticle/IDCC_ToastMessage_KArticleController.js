({
	showToast : function(component, event, helper) {
		helper.showToast(component, event);
	}
})