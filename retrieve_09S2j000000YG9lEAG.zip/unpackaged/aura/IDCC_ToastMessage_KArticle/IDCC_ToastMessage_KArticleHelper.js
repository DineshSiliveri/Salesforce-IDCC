({
    showToast : function(component, event) {
        var action = component.get("c.getFeedDetails");    
        var recordId = component.get("v.recordId");       
        var count;
        action.setParams({
            "recordId": recordId
        });         
        // Set up the callback
        action.setCallback(this, function(response) {           
            component.set('v.message', response.getReturnValue());
            var count = response.getReturnValue();
            if(count > 0 ){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    // "mode": "sticky",
                    "title": "",
                    "message": "You have "+ count +" unanswered questions.",
                    "type": "success",
                    
                });
                toastEvent.fire();
            }   
        });
        
        // Queue this action to send to the server
        $A.enqueueAction(action);
    },
})