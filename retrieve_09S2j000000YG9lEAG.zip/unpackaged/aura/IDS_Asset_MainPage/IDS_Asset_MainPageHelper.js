({
    //This function is for checking the condition to run the entire callout and calculation
    //This will prevent the components from being continuously reload due to the session
    InitialChecking: function(component, event, helper){
        var CurrentCaseID = component.get("v.CaseId");
        var RecordID = component.get("v.recordId");
        
        //Check if Case ID from Event and Current record ID is the same, if they are different don't do anything and do not refresh the component
        //If CaseID == undefined && RecordID exists -> It is first time Loading

        if (CurrentCaseID == RecordID) {
            component.set('v.Error', false);
            helper.CreateWrapper(component,event, helper);
        }
    },

    initialLoad: function(component, event, helper) {
        helper.CreateWrapper(component, event, helper);
    },
    
    //This function is for spinner purposes
    showSpinner : function (component, event) {
        var spinner = component.find("spinner");
        $A.util.removeClass(spinner, "slds-hide");
        $A.util.addClass(spinner, "slds-show");
        component.set('v.NoSpinner', true);
    },
    
    //This function is for spinner purposes
    hideSpinner : function (component, event) {
        var spinner = component.find("spinner");
        $A.util.removeClass(spinner, "slds-show");
        $A.util.addClass(spinner, "slds-hide");
        component.set('v.NoSpinner', false);
    },
    
    
    //This function will call the apex controller and return a wrapper with information needed
    CreateWrapper: function(component, event, helper){
        component.set('v.NoSpinner', true);
        this.showSpinner(component, event);
        var RecordID = component.get("v.recordId");
        var MainPageController = component.get("v.MainPageController");
        
        if (MainPageController === undefined || RecordID === undefined) {
            console.log('DBG a parameter is undefined');
            return;
        }
        var action = component.get("c.doContsructWrapper");
        if (!action) {
            return;
        }
        action.setParams({
            RecordID: RecordID,
            MainPageController: MainPageController
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state == "SUCCESS") {
                var allValues = response.getReturnValue();
                component.set('v.ResponseWrapper', allValues);
                helper.ProcessHeader(component,event, helper);
            }
            else{
                console.log('APEX Callout Failed');
                component.set('v.Error', true);
            }
            component.set('v.NoSpinner', false);
            this.hideSpinner(component, event);
        });
        $A.enqueueAction(action);
    },
    
    ProcessHeader: function(component, event, helper){
        var temp = [];
        var temporarystorage = component.get("v.ResponseWrapper.FieldsToDisplay");
        var finaltemp = [];
        var displayorder = {};
        var displayfinalorder = [];
        var temporary = [];
        var finaltemporary = [];
        try{
            for (var i = 0; i < temporarystorage.length; i++) {
                if(temporarystorage[i].Show__c == true){
                    temp.push(temporarystorage[i])
                }
            }
            
            for(var x=0; x < temp.length; x++){
                    temporary.push(temp[x].LTC_Field_Name__c);
                    displayorder[temp[x].LTC_Field_Name__c] = temp[x].Display_Order__c;
                    displayfinalorder.push(temp[x].Display_Order__c);
                }
            
            displayfinalorder = displayfinalorder.sort(function(a,b) {return a-b;});
            
            //Sort the tableheader into display order
                for (var i=0; i<temporary.length;i++) {
                    var currentorder = displayfinalorder[i];
                    for (var key in displayorder) {
                        var value = displayorder[key];
                        if (value == currentorder) {
                            finaltemporary.push(key)
                        }
                    }
                }
          
            //Push sorted labels into final array
            for (var i=0; i<displayfinalorder.length;i++) {
                for (var x=0; x<temp.length;x++) {
                    if (temp[x].Display_Order__c == displayfinalorder[i]) {
                    	finaltemp.push(temp[x]);
                    }
                }
            }
            
            component.set('v.FormHeader', finaltemp);
            helper.ProcessData(component,event, helper);
        }
        catch(err){
            component.set('v.Error', true);
        }   
    },
    
    //This function will process the raw data for the header
    ProcessData: function(component, event, helper){
        //Assuming that form will only show 1 record at any point of time
        var responsestorage = component.get("v.ResponseWrapper");
        var temporarystorage = responsestorage.ProcessedAssetRecord;
        var Formheader = component.get("v.FormHeader");
        var temporarytypes = component.get("v.ResponseWrapper.FieldsToDisplay");
        var temptypes = {};
        
        for (var i=0;i<temporarytypes.length;i++) {
            var typename = temporarytypes[i].LTC_Field_Name__c;
            var datatype = temporarytypes[i].LTC_Field_Type__c;
            temptypes[typename] = datatype;
        }
        
        //If there is no asset, return an error
        if(temporarystorage.Id == null || temporarystorage.Id == undefined){
            component.set('v.Error', true);
        }
        else{
            try{
                //Taking just the API Name and put them into a temporary storage
                var temporary = [];
                for(var x=0; x < Formheader.length; x++){
                    temporary.push(Formheader[x].LTC_Field_Name__c);
                }
                var temporarylabel = [];
                for(var x=0; x < Formheader.length; x++){
                    temporarylabel.push(Formheader[x].LTC_Field_Label__c);
                }
                
                //Taking the values of each records related to the API Name and store into a storage
                //The form consists of 2 column, thus split accordingly
                var NewBody = "";
                var storage = [];
                var tracker = 0;
                var NoIteration = Math.floor((temporary.length)/2);
                
                for(var x=0; x<NoIteration; x++){
                    var opt = [];
                    opt.push({
                        header: temporary[tracker],
                        label: temporarylabel[tracker],
                        value: temporarystorage[temporary[tracker]],
                        type: temptypes[temporary[tracker]]
                    });
                    opt.push({
                        header: temporary[tracker+1],
                        label: temporarylabel[tracker+1],
                        value: temporarystorage[temporary[tracker+1]],
                        type: temptypes[temporary[tracker+1]]
                    });
                    storage.push({
                        recordposition: x,
                        inside: opt
                    });
                    tracker = tracker + 2;
                }
                
                if(NoIteration != ((temporary.length)/2)){
                    var opt = [];
                    opt.push({
                        header: temporary[temporary.length-1],
                        header: temporarylabel[temporarylabel.length-1],
                        value: temporarystorage[temporary[temporary.length-1]],
                        type: temptypes[temporary[temporary.length-1]]
                    })
                    storage.push({
                        recordposition: -1,
                        inside: opt
                    });
                }
                component.set('v.FormRecords', storage);
            }
            catch(err){
                component.set('v.Error', true);
            }
        }
        
    },

    //Navigate to a subtab and pass the necessary parameters
    ShowAllRecords: function(component, event, helper){
        var workspaceAPI = component.find("workspace");
        var navService = component.find("navService");
        console.log('DBG cmpTitle: ', component.get("v.cmpTitle"));
        // set the pageReference object used to navigate to the component. Include any parameters in the state key.
        var pageReference = {
            "type": "standard__component",
            "attributes": {
                "componentName": "c__IDS_Asset_Subtab_Details" //This is the name of the component
            },
            "state": {	//This is what you are passing as parameters
                "c__params": component.get("v.apiEndPoint"),
                "c__TestChildAPI": component.get("v.TestChildAPI"),
                "c__title": component.get("v.cmpTitle"),
                "c__icon": component.get("v.cmpLtIcon"),
                "c__contentbody": component.get("v.contentbody"),
                "c__contentsubbody": component.get("v.contentsubbody"),
                "c__contentsecondsubbody": component.get("v.contentsecondsubbody"),
                "c__recordId": component.get("v.recordId")
            }
        };
        var parentSubTabId;
        var childSubTabId;
        // handles checking for console and standard navigation and then navigating to the component appropriately
        workspaceAPI
        .isConsoleNavigation()
        .then(function(isConsole) {
            if (isConsole) {
                //in a console app - generate a URL and then open a subtab of the currently focused parent tab
                navService.generateUrl(pageReference).then(function(cmpURL) {
                    workspaceAPI
                    .getEnclosingTabId()
                    .then(function(enclosingTabId) {
                        parentSubTabId = enclosingTabId;
                        return workspaceAPI.openSubtab({
                            parentTabId: enclosingTabId,
                            url: cmpURL,
                            focus: true
                        });
                    })
                    .then(function(subTabId) {
                        // the subtab has been created, use the Id to set the label
                        childSubTabId = subTabId;
                        workspaceAPI.setTabLabel({
                            tabId: subTabId,
                            label: "Quotas"
                        });
                        workspaceAPI.setTabIcon({
                            tabId: subTabId,
                            icon: "action:description",
                            iconAlt: "SubTab Label Name"
                        });
                        // to fix the stuck "Loading..." title on browser tab name
                        workspaceAPI.focusTab({tabId : parentSubTabId});
                        workspaceAPI.focusTab({tabId : childSubTabId});
                    });
                });
            } else {
                // this is standard navigation, use the navigate method to open the component
                navService.navigate(pageReference, false);
            }
        })
        .catch(function(error) {
            console.log('DBG outer error: ', error);
        });
    },
    
    //Navigate to a subtab (Salesforce Standard Object)
    NavigateToAsset: function(component, event, helper){
        var responsestorage = component.get("v.ResponseWrapper");
        if (responsestorage) {
            if (responsestorage.RelatedAssetRecord) {
                if (responsestorage.RelatedAssetRecord.Id != null && responsestorage.RelatedAssetRecord.Id != undefined) {
                    var AssetID = responsestorage.RelatedAssetRecord.Id;
                    var navEvt = $A.get("e.force:navigateToSObject");
                    
                    navEvt.setParams({
                        "recordId": AssetID
                    });
                    navEvt.fire();
                }
            }
        }
    },

    //Navigate to a subtab and pass the necessary parameters
    GetIFrameInfo: function(component, event, helper){
        var workspaceAPI = component.find("workspace");
        var navService = component.find("navService");
        
        // set the pageReference object used to navigate to the component. Include any parameters in the state key.
        var pageReference = {
            "type": "standard__component",
            "attributes": {
                "componentName": "c__IDS_Asset_Subtab_Prepaid" //This is the name of the component
            },
            "state": { //This is what you are passing as parameters
                "c__recordid": component.get("v.recordId"),
                "c__PrepaidScreen": component.get("v.PrepaidScreen"),
                "c__MainPageController": component.get("v.MainPageController"),
                "c__title": component.get("v.cmpTitle"),
                "c__icon": component.get("v.cmpLtIcon")
            }
        };
        var parentSubTabId;
        var childSubTabId;
        // handles checking for console and standard navigation and then navigating to the component appropriately
        workspaceAPI
        .isConsoleNavigation()
        .then(function(isConsole) {
            if (isConsole) {
                //in a console app - generate a URL and then open a subtab of the currently focused parent tab
                navService.generateUrl(pageReference).then(function(cmpURL) {
                    workspaceAPI
                    .getEnclosingTabId()
                    .then(function(tabId) {
                        parentSubTabId = tabId;
                        return workspaceAPI.openSubtab({
                            parentTabId: tabId,
                            url: cmpURL,
                            focus: true
                        });
                    })
                    .then(function(subTabId) {
                        // the subtab has been created, use the Id to set the label
                        childSubTabId = subTabId;
                        workspaceAPI.setTabLabel({
                            tabId: subTabId,
                            label: "Prepaid Details"
                        });
                        // to fix the stuck "Loading..." title on browser tab name
                        workspaceAPI.focusTab({tabId : parentSubTabId});
                        workspaceAPI.focusTab({tabId : childSubTabId});
                    });
                });
            } else {
                // this is standard navigation, use the navigate method to open the component
                navService.navigate(pageReference, false);
            }
        })
        .catch(function(error) {
            console.log(error);
        });
    },
    
    //This function is to listen to changes and act accordingly
    subscribeEventChange : function(component, event, helper){
        const empApi = component.find('empApi');
        const channel = component.get('v.channel');
        const replayId = -1;
        
        //If there are changes related to the case record, redo the logic
        const callback = function (message) {
            component.set('v.MSISDN', message.data.payload.MSISDN__c);
            component.set('v.CaseId', message.data.payload.CaseId__c);
            helper.InitialChecking(component,event, helper);
        };
        empApi.subscribe(channel, replayId, $A.getCallback(callback)).then($A.getCallback(function (newSubscription) {
            console.log('Subscribed to channel ' + channel);
        }));

    }
})