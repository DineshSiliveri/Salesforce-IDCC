({
    doInit: function (component, event, helper) {
        helper.subscribeEventChange(component,event, helper);
        helper.initialLoad(component, event, helper);
    },
        
    // Will not use, will relegate use to the DoInit for refreshing
    // recalculate:function (component, event, helper) {
    //     helper.CreateWrapper(component,event, helper);
    // },
    
    GoToRecord: function (component, event, helper) {
        helper.NavigateToAsset(component,event, helper);
    },
    
    ThrowError: function (component, event, helper) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : 'Error',
            message: 'Asset Record Not Found',
            duration:' 5000',
            type: 'warning',
            mode: 'sticky'
        });
        toastEvent.fire();
    },
    
    ShowAll: function (component, event, helper) {
        helper.ShowAllRecords(component,event, helper);
    },
    
    openExternalIframe : function(component, event, helper){
        helper.GetIFrameInfo(component,event, helper);
    },
    
    RefreshComponent: function (component, event, helper) {
        var a = component.get('c.doInit');
        $A.enqueueAction(a);
    }
})