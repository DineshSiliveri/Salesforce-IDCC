({
    //Init method
    doInit : function(component, event, helper){
        var action = component.get("c.getLevel1DeviceSimulator");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                component.set('v.level1DeviceToAttchMap',response.getReturnValue());
                var imageURLLevel1 = [];
                for(var key in result){
                    imageURLLevel1.push({value:result[key], key:key});
                }
                component.set("v.imageURLLevel1Lst", imageURLLevel1);
            }
            else{
                console.log('Error in IDCC_DeviceSimulatorComponentController : doInit');
            }
        });
        $A.enqueueAction(action);
    },
    // On click handler of Images of Level1
    clickHandler : function(component, event, helper) {
        var deviceId =  event.currentTarget.dataset.id;
        console.log('*****Level1 Device Id '+ deviceId);
        component.set("v.selectedLevel1DeviceId",deviceId);
        component.set("v.openLevel1", false);
        component.set("v.openLevel2", true);
    },
    //Method for event handling of IDCC_Level2ToLevel1Event
    handleBackButton :function(component, event, helper) {
         var recordId = event.getParam("recordId");
		 component.set("v.openLevel1", true);
         component.set("v.openLevel2", false);
    }
})