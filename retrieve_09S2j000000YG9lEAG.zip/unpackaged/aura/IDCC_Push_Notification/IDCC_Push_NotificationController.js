({
        doInit : function(component, event, helper) {
            var userId = $A.get("$SObjectType.CurrentUser.Id");
            //alert('userId'+userId);
         var recId = component.get("v.recordId"); 
            helper.checkStatus(component);
                
if(recId!==null){      
    window.setInterval(
                     
           $A.getCallback(function() {
           
         var recId = component.get("v.recordId"); 
               if(recId!==undefined && recId!==null){   
               helper.checkStatus(component);
               }
           } )  ,10000);
}
        
                      
        },
    })