({
    
	 checkStatus : function(component) {
        
            var recId = component.get("v.recordId"); 
         if(recId!==undefined && recId!==null){     
               var action = component.get("c.getOwnerChange");
             
                action.setParams({"a":recId});
         }
            if(action!==undefined && action!==null && recId!==undefined && recId!==null){
            action.setCallback(this, function(response) {
                
                var state = response.getState();
                console.log(response.getReturnValue());
                if (state == "SUCCESS") {
                   // component.set("v.cnts", response.getReturnValue());
                   //alert(response.getReturnValue());
                   //
                   var caseObj = response.getReturnValue();
                    var caseList = caseObj.toString().split("/");
              //      alert('number '+caseList[1]);
                    if(caseList[1]  == "true"){
                  //      alert('entered wewewe');
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "mode": "sticky",
                        "title": "The Case # "+caseList[0]+" !!!",
                        "message": "has been assigned to another agent",
                        "type": "error",
                        
                    });
                    toastEvent.fire();
                    
                   
                    }
                    
                }
                else {
                    console.log("Failed with state: " + state);
                }
            });
            }
             
         $A.enqueueAction(action);
     }

})