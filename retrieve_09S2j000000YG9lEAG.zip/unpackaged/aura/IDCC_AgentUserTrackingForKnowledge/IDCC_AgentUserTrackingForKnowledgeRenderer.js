({
    afterRender : function( component, helper ) {
        this.superAfterRender();
        var didScrolled = false;
        var x = 0;
        document.onscroll = function() {
            console.log('page&&'+window.pageYOffset);
            console.log('Top****'+document.documentElement.scrollTop);
            // console.log('Top&&&'+document.body.scrollTop);
            console.log('Height****'+document.documentElement.scrollHeight );
            console.log('Height&&**'+document.body.height );
            console.log('Offset Height**'+document.body.offsetHeight);
                         /*if(div.scrollTop === (div.scrollHeight - div.offsetHeight)){
                            helper.getNextPage(component);
                        }*/
            if(document.documentElement.scrollTop >= document.documentElement.scrollHeight - 790){
                //alert("bottom!");
                console.log('bottom****');
                didScrolled = true;
                if(didScrolled){
                    component.set('v.scrollNo',true);
                    //helper.trackLog(component);
                }
            }            
        };
        console.log('didScrolled****'+didScrolled);
        
    },
    unrender: function( component) {
        this.superUnrender();
        var intervalId = component.get( 'v.intervalId' );
        if ( !$A.util.isUndefinedOrNull( intervalId ) ) {
            window.clearInterval( intervalId );
        }
    }
    
})