({
    doInit : function(component, event, helper) {
        helper.trackLog(component, event, helper);
    }
})