({
    trackLog : function(component, event, helper) {
        console.log('Init scrolling********'+component.get("v.scrollNo"));
        var action = component.get("c.trackAuditLog");
        action.setParams({
            articleId:component.get("v.recordId"),
            bounced :  component.get("v.scrollNo")
        }); 
        console.log("params: " + JSON.stringify(action.getParams()));
        
        action.setCallback(this, function(a) {
            var state = a.getState();
            //alert('state '+state);
            //alert('return '+a.getReturnValue());
            if(component.isValid() && state == "SUCCESS"){ 
                component.set("v.auditObj", a.getReturnValue());
            }
            else {
                alert('failure');
            }
        });
        $A.enqueueAction(action);
    }   
})