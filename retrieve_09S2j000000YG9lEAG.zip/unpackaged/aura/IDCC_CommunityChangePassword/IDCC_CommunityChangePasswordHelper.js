({
    showSuccessMessage : function(component, event) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type" : "success",
            "message": "Password has been changed Successfully."
        });
        toastEvent.fire(); 
        component.set("v.showError", false);
        component.set("v.password" , "");
        component.set("v.newPassword" , "");
    },
})