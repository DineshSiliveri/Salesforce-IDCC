({   //Method called on Submit Action 
    submitPassword: function (component, event, helper) {
        var newpasswordref = component.find("NewPassword").get("v.value");
        //var newpasswordconfirmref = component.find("NewPassword2").get("v.value");
        var oldpasswordref = component.find("OldPassword").get("v.value");
        //alert(newpasswordref+'    '+oldpasswordref);
        var action = component.get("c.changePassword");
        // var message = component.get("c.changePasswordmessage");
        action.setParams({newPassword:newpasswordref,
                          verifyNewPassword:newpasswordref,
                          oldPassword:oldpasswordref})
        action.setCallback(this, function(a) {
            var rtnValue = a.getReturnValue();
            if (rtnValue != 'SUCCESS') {
                component.set("v.showError", true);
                component.set("v.errorMessage", rtnValue);
            }if (rtnValue == 'SUCCESS') {
                helper.showSuccessMessage(component, event);
            }
        });
        $A.enqueueAction(action);
    },
    //Method used to handle Cancel Action
    handleCancel : function(component, event, helper) {
        event.preventDefault();
        component.set("v.showError", false);
        component.set("v.password" , "");
        component.set("v.newPassword" , "");
       // $A.get('e.force:refreshView').fire();
    },
    //Method used to toggle Old Password
    togglePassword : function(component, event, helper) {
        if(component.get("v.showpassword",true)){
            component.set("v.showpassword",false);
        }else{
            component.set("v.showpassword",true);
        }
    },
    //Method used to toggle New Password
    toggleNewPassword : function(component, event, helper) {
        if(component.get("v.showNewPassword",true)){
            component.set("v.showNewPassword",false);
        }else{
            component.set("v.showNewPassword",true);
        }
    },
    
   
    
})