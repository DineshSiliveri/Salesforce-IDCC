({
    openUrlN : function(component, event) {       
        var action1 = component.get("c.getFeaturedArticles");
        action1.setParams({"articleId":component.get("v.recordId")}); 
        action1.setCallback(this, function(response) {
            var state = response.getState();
            if(component.isValid() && state == "SUCCESS"){             
                var records = response.getReturnValue();
                var know = [];
                for(var key in records){  
                    if(component.get("v.recordId") == records[key].Id ){                       
                        component.set("v.recordStr",records[key].Title); 
                        component.set("v.recordStr1",records[key].Internal_Answer__c); 
                        component.set("v.recordStr2",records[key].IDCC_Article_Part_2__c);  
                        component.set("v.recordStr3",records[key].IDCC_Article_Part_3__c);
                        component.set("v.firstPublishDate",records[key].LastPublishedDate); 
                        break;
                    }
                }                
            }
            else {
                console.log("Unknown error"+errors[0].message);
            }
        });  
        $A.enqueueAction(action1);         
    }
    
})