({
    openUrlN : function(component, event, helper) {
        helper.openUrlN(component, event);
    }
})