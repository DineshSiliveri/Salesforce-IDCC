({
    doInit: function(component, event, helper) {
        
        var userId = $A.get("$SObjectType.CurrentUser.Id");
        var checkUser="false";
        var actionUser = component.get('c.fetchUser');
        actionUser.setParams({ userId: userId});
        if(actionUser!=undefined)
        {
            actionUser.setCallback(this, function(response) {
                var state = response.getState();    
                
                if (state == "SUCCESS")  
                {                                                      
                    checkUser =  response.getReturnValue();            										   
                }
                
                //if(checkUser==true){ 
                
                helper.getBroadcastList(component);  
                
                window.setInterval(
                    $A.getCallback(function() {
                        helper.getBroadcastList(component);
                    }),50000);         
                
                jQuery(document).ready(function(){
                    function tick(){
                        $('#ticker_01 li:first').fadeOut( function () { $(this).appendTo($('#ticker_01')).fadeIn(); });            
                    }
                    setInterval(function(){ tick () }, 5000);
                    
                });                            
                // }
            });   
            $A.enqueueAction(actionUser);   
        }
    }
    
})