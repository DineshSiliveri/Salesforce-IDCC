({
    getBroadcastList: function(component) {
        var action = component.get('c.getBroadcasts');
        if(action!=undefined)
        {
            action.setCallback(this, function(actionResult) {
                
                var state = actionResult.getState();    
                console.log(state);
                if (state == "SUCCESS")  
                {
                    
                    var broadcast = actionResult.getReturnValue();
                    console.log('broadcast');
                    component.set('v.broadcast', broadcast);
                }
                
                
            });
        }
        
        $A.enqueueAction(action);
    }
    
})