({
    doInit : function(component, event, helper) {
        
    },
    
    containEvent: function(component, event, helper) {
        event.stopPropagation();
    }
    
})