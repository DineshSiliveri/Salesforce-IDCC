({
    getAppointment : function(cmp, event, helper) {
        var recordId = cmp.get("v.recordId");
    	var staticLabel = $A.get("$Label.c.IDCC_AppointmentStep");
        var tmp;
        tmp=$A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleAppointmentStep1?recordId='+recordId;
        cmp.set("v.URL",tmp);          
	},
    maadjustment : function(cmp, event, helper) {
        var recordId = cmp.get("v.recordId");
    	var staticLabel = $A.get("$Label.c.IDCC_AppointmentStep");
        var tmp;
        tmp=$A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleMAAdjustment?Caseid='+recordId+'&mabalance=1000';
        cmp.set("v.URL",tmp);          
	},
     activateRoaming : function(cmp, event, helper) {
    	var recordId = cmp.get("v.recordId"); 
        var action = cmp.get("c.getAssetDetails");
        var PostPre;
        var iCareCat,tmp;
        action.setParams({ caseId: recordId});
        action.setCallback(this,
                           function(response)
                           {
                               var state = response.getState(); 
                               var resValue = response.getReturnValue();
                               if (state == "SUCCESS" && (resValue != null && resValue.length > 0) ) 
                               {
                                   var statusCheck = response.getReturnValue();
                                   console.log(statusCheck);
                                  
                                   PostPre = statusCheck[0].IDCC_CustSegment__c;
                                   iCareCat = statusCheck[0].IDCC_siebelDataLocation__c;
                                   if(iCareCat=='ICARE'){
                                       tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleActivateRoaming?apiName=Execution_iCare_Intl_Roaming_Active&recordId='+recordId;
                                   }else if(iCareCat=='CATALIST'){
                                       tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleActivateRoaming?apiName=Execution_Catal_Intl_Roaming_Active&recordId='+recordId;
                                   }
        							cmp.set("v.URL",tmp);
        							
                               }
                               
                           });
        
       $A.enqueueAction(action);           
	},
 
})