({
    
    // this function called for survey link modification
    modifySurveyLink: function (component,event) {
        var redURL;
        var redirectURL;            
        var urlString = window.location.href ;
        if(urlString.includes("fbclid") ){                
            //This will replace the text in URL with required characters
            redirectURL = urlString.replace(/%26/g,"&").replace(/%3D/g,"=").replace(/%2F/g,"/").replace(/%3F/g,"?").replace("/s/login/?language=in&startURL=/SelfHelpPortal", "");
            redURL =redirectURL.substring(0, redirectURL.indexOf("fbclid") - 1);
        }
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            // "url": "https://indosatdev-indosatooredoo.cs75.force.com/SelfHelpPortal/survey/runtimeApp.app?invitationId=0Ki0w0000000B2R&surveyName=indosat_email_case_survey&UUID=3c7364c0-b6d5-4e48-8043-bc7cd537c3e7"
            "url": redURL 
        });
        urlEvent.fire();  
    },
    
    handleLogin: function (username,password) {
        console.log("called helper");
        var username = username;
        console.log("username " +username);
        var password = password;
        var action = component.get("c.login");
        var startUrl = component.get("v.startUrl");
        
        console.log("password " +password);
        console.log("startUrl " +startUrl);
        
        startUrl =decodeURIComponent(startUrl);
        
        action.setParams({
            username: username,
            password: password,
            startUrl: startUrl
        });
        action.setCallback(this,function (a) {
            var rtnValue = a.getReturnValue();
            if (rtnValue !==null) {
                component.set("v.errorMessage",rtnValue);
                component.set("v.showError",true);
            }
        });
        $A.enqueueAction(action);
    },
    
    homeLink : function(component, event) {        
        //var index = event.target.getAttribute('data-index');
        /* component.find("navService").navigate(    {
            type: "comm__namedPage",
            attributes: {
                pageName: "DeviceSimulatorPage"
            }
        }    , true);*/
        window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/DeviceSimulatorPage?language=en_US', '_self'); 
    },  
    createAndSendOTP : function (component,event, helper) {  
        var action = component.get("c.createAndSendOTPApex");
        action.setParams({
            user: component.get("v.User")
        });
        action.setCallback(this,function (response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS"){
                if(result){
                    console.log('In success IDCC_CommunityLoginPAge: createAndSendOTP');
                    helper.sendSMS(component,event, helper);
                }
                else{
                    console.log('Error while inserting record in USER_OTP Object');        
                }
            }
            else{
                console.log('Error in IDCC_CommunityLoginPAge : createAndSendOTP');
            }
        });
        $A.enqueueAction(action);    
    },
    sendSMS : function (component,event, helper) { 
        var action = component.get("c.sendSMSAPICall");
        //alert('User***'+component.get("v.User"));
        action.setParams({
            user: component.get("v.User")
        });
        action.setCallback(this,function (response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state == "SUCCESS"){
                if(!$A.util.isEmpty(result)){
                    for(var key in result) {
                        if(key =='Success'){
                            component.set('v.openLoginScreen',false);   
                            component.set('v.openSendOTPScreen',true);    
                        }
                        else{
                            component.set("v.mylabel","Failed to send OTP. Please try again.");       
                        }
                    }
                }
                else{
                    console.log('Error in sendSMS : result'+result);   
                    component.set("v.mylabel","Failed to send OTP. Please try again.");    
                }
                
            }
            else{
                console.log('Error in IDCC_CommunityLoginPAge : sendSMS');
            }
        });
        $A.enqueueAction(action);    
    },
    checkLogin : function (component,event, helper) { 
        var action = component.get("c.checkLoginApex");
        action.setParams({
            user: component.get("v.User"),
            password: component.get("v.Password")
        });
        action.setCallback(this,function (response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (result != null) {
                result = result.replace('username', 'Email Id');
                component.set("v.mylabel",result);	  
            }
            else{
                helper.createAndSendOTP(component,event, helper);             
            }
        });   
        $A.enqueueAction(action);
    },
    
    //calling User Registration component on clck of link
    userRegistration : function (cmp,event){
        cmp.set("v.mylabel1", ""); 
        cmp.set('v.openLoginScreen',false);
        cmp.set("v.openRegPage",true);        
    },  
    
    
})