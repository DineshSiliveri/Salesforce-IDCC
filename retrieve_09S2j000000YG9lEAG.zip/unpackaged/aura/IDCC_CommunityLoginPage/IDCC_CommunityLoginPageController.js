({
    checkForRelatedUserPresentORNot :function (component,event, helper) {  
        var validForm = component.find('FormVal').reduce(function (validSoFar,inputCmp) {
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;}, true);
           if (validForm) {            
            var username = component.get("v.Username");
            var action = component.get("c.checkRelatedUserPresentOrNot");
            action.setParams({
                username: username
            });
            action.setCallback(this,function (response) {
                var state = response.getState();
                var result = response.getReturnValue();
                if (state === "SUCCESS"){
                    if(!$A.util.isEmpty(result)){
                        component.set("v.mylabel","");  
                        if(result[0]!=null){
                        	component.set('v.User',result[0]); 
                            if(result[0].MSISDN__c ==null || result[0].MSISDN__c == ''){
                            	component.set("v.mylabel","We do not have any MSISDN linked with this user.");         
                            }
                            else{
                                helper.checkLogin(component,event, helper);
                            }
                        }
                    }
                    else{
                        component.set("v.mylabel","User not present with mentioned email Id , please verify Email ID .");        
                    }
                }
                else{
                    console.log('Error in IDCC_CommunityLoginPAge : checkForRelatedUserPresentORNot');
                }
            });
            $A.enqueueAction(action);
        }
    },
    getInput: function (component,event, helper) {        
        component.set("v.mylabel1","");        
        var validForm = component.find('FormVal').reduce(function (validSoFar,inputCmp) {
            // Displays error messages for invalid fields
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;}, true);
        // If we pass error checking, do some real work
        if (validForm) {            
            // Get the Username from Component
            var user = component.get("v.Username");
            var Pass = component.get("v.Password"); 
            var action = component.get("c.checkPortal");
            action.setParams({
                username: user,
                password: Pass
            });
            // Add callback behavior for when response is received
            action.setCallback(this,function (response) {
                var state = response.getState();
                var rtnValue = response.getReturnValue();
                if (rtnValue !== null) {
                    component.set("v.mylabel",rtnValue);
                    //component.set("v.showError",true);
                }else{
                    //  helper.homeLink(component, event);
                    helper.modifySurveyLink(component, event);                   
                }
            });            
            // Send action off to be executed
            $A.enqueueAction(action);
        }
    },
    resetPass: function (cmp) {
        cmp.set("v.mylabel1", "");        
        cmp.set("v.isVisible",false);
    },
    
    userRegistration :function (component, event, helper) {
       helper.userRegistration(component, event); 
    },
    
    CancelReset: function (cmp) {
        cmp.set("v.mylabel", "");        
        cmp.set("v.isVisible", true);
    },
    
    submitresetPass: function (
        component, event, helper) {
        component.set("v.mylabel","");        
        var validResetForm1 =component.find("FormReset").get("v.validity");
        // If we pass error checking, do some real work
        if (validResetForm1.valid) {
            var Reuser1 = component.get("v.ResetUsername");
            var action = component.get("c.forgotPassowrd");
            action.setParams({
                username: Reuser1
            });
            action.setCallback(this,function (a) {
                var rtnValue = a.getReturnValue();
                console.log('<<my return value>>>>>' +rtnValue);
                // component.set("v.mylabel1",'We’ve sent you an email with a link to finish resetting your password.');
                
                if (rtnValue !==null) {
                    component.set("v.mylabel1",rtnValue);
                    // component.set("v.showError",true);
                }
            });
            $A.enqueueAction(action);
        }
    },
    handleLogin: function (component,event, helper) {
        var username = component.find("Username").get("v.Username");
        var password = component.find("password").get("v.value");
        helper.handleLogin(
            username, password);
    },
    setStartUrl: function (component,event, helper) {
        var startUrl = event.getParam('startURL');
        if (startUrl) {
            component.set("v.startUrl",startUrl);
        }
    },
    
    // this function automatic call by aura:waiting event
    showSpinner: function (component,event, helper) {
        console.log('in spinner....');
        // make Spinner attribute true for display loading spinner
        component.set("v.Spinner",true);
    },
    
    // this function automatic call by aura:doneWaiting event
    hideSpinner: function (component,event, helper) {
        console.log('in spinner out....');
        // make Spinner attribute to false for hide loading spinner
        component.set("v.Spinner",false);
    },
    
    
})