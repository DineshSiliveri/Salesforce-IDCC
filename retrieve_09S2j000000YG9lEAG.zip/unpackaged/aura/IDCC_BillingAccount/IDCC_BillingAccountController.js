({
	showCustDetails : function(component, event, helper) {
		//helper.showCustDetails(component, event);
		var recordId = component.get("v.recordId");
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleForm");	
        var tmp;
        //alert(staticLabel);
        //var tmp =staticLabel+'apiName=Query_Billing_Account_Info_iCare&resObjName=Query_Billing_Account_Info_iCare_Res&recordId='+recordId;
        //var tmp =staticLabel+'apiName=Query_Billing_Account_Info_iCare&resObjName=Query_Billing_Account_Info_CATALIST_Res&recordId='+recordId;
        //'https://indosat--indosatdev--c.cs75.visual.force.com/apex/IDCC_ConsoleForm?apiName=Query_Customer_Profile&resObjName=Query_Customer_Profile_Res&recordId=5000w000001UmaFAAS';
        //alert(tmp);
        
       	var action1 = component.get("c.setViewStat");    
        var csId = component.get("v.recordId"); 
        action1.setParams({
            "caseId":csId
        });
        
        // Set up the callback
        action1.setCallback(this, function(response) {
            var result =response.getReturnValue();
            component.set('v.caseDetails', response.getReturnValue());    
            var caseDataLocation = component.get('v.caseDetails.IDCC_Siebel_Data_Location__c');
            console.log('caseDataLocation : '+caseDataLocation);
            //tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_BillingaccountConsoleForm?recordId='+recordId+'&pagetype=billingacount&location='+caseDataLocation;
                
        	if(caseDataLocation == 'CATALIST'){
                //alert('case siebel value is catalist==');
                tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_BillingaccountConsoleForm?recordId='+recordId+'&pagetype=billingacount&location='+caseDataLocation;
                 //tmp =staticLabel+'apiName=Query_Billing_Account_Info_iCare&resObjName=Query_Billing_Account_Info_CATALIST_Res&recordId='+recordId;
           		 component.set("v.URL",tmp);
            }else if(caseDataLocation == 'ICARE'){
                //alert('case siebel value is ICARE==');
                tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_BillingaccountConsoleForm?recordId='+recordId+'&pagetype=billingacount&location='+caseDataLocation;
                //tmp =staticLabel+'apiName=Query_Billing_Account_Info_iCare&resObjName=Query_Billing_Account_Info_iCare_Res&recordId='+recordId;
           		 component.set("v.URL",tmp);
            }
        });
        $A.enqueueAction(action1);	
               
        console.log('URL**'+tmp);
        // component.set("v.URL",tmp);
        helper.scrolltoTop();	
      
	},
    	showBillingInvoiceDetails : function(component, event, helper) {
		var recordId = component.get("v.recordId");
       // var staticLabel = 'https://indosat--indosatdev--c.cs75.visual.force.com/apex/IDCC_ConsoleFormPrem?';
         var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var tmp = staticLabel+'apiName=Query_BA_Invoice_Product_Charge&resObjName=Query_BA_Invoice_Product_Charge_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();	
      
	},BAledger : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
		var recordId = component.get("v.recordId");
        var tmp = staticLabel+'resObjName=Query_BA_Ledger_Res&apiName=Query_BA_Ledger&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},invoiceHistory : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
		var recordId = component.get("v.recordId");
        var tmp = staticLabel+'resObjName=Query_Invoice_History_Res&apiName=Query_Invoice_History&recordId='+recordId;
        component.set("v.URL",tmp);
        var divId  = document.getElementsByClassName("tabset") ;
        console.log( ' divId ==> ' + divId);
        helper.scrolltoTop();
	},paymentHistory : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
		var recordId = component.get("v.recordId");         
        var tmp = staticLabel+'resObjName=Query_Payment_History_Res&apiName=Query_Payment_History&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
         
	},
    billRevenue : function(component, event, helper) {
       // var staticLabel = 'https://indosat--indosatdev--c.cs75.visual.force.com/apex/IDCC_ConsoleTablePrem?';
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Billing_Account_Invoice_Revenue&resObjName=Query_Billing_Account_Invoice_RevenueRes&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},
    unbilledUsage : function(component, event, helper) {
       // var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleForm");
        var recordId = component.get("v.recordId");
       // var tmp = staticLabel+'apiName=Query_Billing_Unbilled_Usage&resObjName=Query_Billing_Unbilled_Usage_Res&recordId='+recordId;
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleUnbilledUsage?resObjName=Query_Billing_Unbilled_Usage_Res&apiName=Query_Billing_Unbilled_Usage&Form&recordId='+recordId;

        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	}
/*    showBillingUsageDetails : function(component, event, helper) {
		//helper.showCustDetails(component, event);
		var recordId = component.get("v.recordId");
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleForm");	
        //alert(staticLabel);   
        var staticLabel = 'https://indosat--indosatdev--c.cs75.visual.force.com/apex/IDCC_ConsoleFormPrem?';
        var tmp = staticLabel+'apiName=Query_Billing_Acct_Unbilled_Usg&resObjName=Query_Billing_Acct_Unbilled_UsgRes&recordId='+recordId;
        
        //'https://indosat--indosatdev--c.cs75.visual.force.com/apex/IDCC_ConsoleForm?apiName=Query_Customer_Profile&resObjName=Query_Customer_Profile_Res&recordId=5000w000001UmaFAAS';
        //alert(tmp);
        console.log('URL'+tmp);
        component.set("v.URL",tmp);
        helper.scrolltoTop();	
      
	} */
})