({
    init : function(component, event, helper) {     
        //alert('init');
        console.log('--recordId***-'+component.get("v.recordId"));
        helper.getArticleLikeCountJS(component, component.get("v.recordId"));
    },
    
    likeArticle :function(component, event, helper) { 
        //component.set("v.likeButton",true);
        console.log('Record id'+ component.get("v.recordId"));
        component.set("v.likeCount", component.get("v.likeCount")+1);
        if(component.get("v.likeCount") === 1){
            component.set("v.isLiked",true);
        }
        
        console.log('count****'+component.get("v.likeCount"));
        var action = component.get("c.setArticlesLikeCount");
        action.setParams({
            "likeCountOfArticles":component.get("v.likeCount"),
            "articleId":component.get("v.recordId")
        }); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(component.isValid() && state == "SUCCESS"){   
                console.log("SUCCESS");
            }
            else {
                var errors = response.getError();
                console.log("Unknown error"+errors[0].message);
            }
        });       
        $A.enqueueAction(action);
    }
})