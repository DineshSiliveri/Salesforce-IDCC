({
	 getArticleLikeCountJS : function (component, knowledgeId) {
        console.log('--recordId&--',component.get("v.recordId"));
        var action = component.get("c.getArticlesLikeCount");
        action.setParams({
            "articleId":knowledgeId
        }); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            console.log('state '+JSON.stringify(response.getReturnValue()));
            if(component.isValid() && state == "SUCCESS"){   
                if(result > 0) {
                    component.set("v.isLiked",true);
                    component.set("v.likeCount",1);
                } else {
                    component.set("v.likeCount",0);
                }
            }
            else {
                var errors = response.getError();
                console.log("Unknown error"+errors[0].message);
            }
        });       
        $A.enqueueAction(action);  
    }
})