({
    getLevel1Data : function(component, event, helper) {
        var level1Id = component.get("v.level1DeviceId");
        component.set("v.level1Id",level1Id);
        var action = component.get("c.getLevel1DeviceSimulator");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                //component.set('v.level1DeviceToAttchMap',response.getReturnValue());
                var imageURLLevel1 = [];
                for(var key in result){
                    if(result[key].Id == level1Id){
                    	//component.set("v.mainIdLevel1",result[key].Id);    
                    }
                    imageURLLevel1.push({value:result[key].Name, key:result[key].Id});
                }
                component.set("v.level1Lst", imageURLLevel1);
                helper.getLevel2Data(component, event, helper);
            }
            else{
                console.log('Error in IDCC_DeviceSimulatorLevel2 : getLevel1Data');
            }
        });
        $A.enqueueAction(action);
    },
    getLevel2Data : function(component, event, helper) {
        var action = component.get("c.getLevel2DeviceSimulator");
        action.setParams({selectedLevel1DeviceId : component.get("v.level1DeviceId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS"){
                if($A.util.isEmpty(result)){
                	component.set("v.imageURLLevel2Lst", null);    
                }
                else{
                    component.set('v.level2DeviceToAttchMap',response.getReturnValue());
                    var imageURLLevel2 = [];
                    for(var key in result){
                        //alert(result[key].brand__r.Id);
                        imageURLLevel2.push({value:result[key], key:key});
                    }
                    component.set("v.imageURLLevel2Lst", imageURLLevel2);
                    console.log('imageURLLevel2Lst---------------'+imageURLLevel2);    
                }
                
            }
            else{
                console.log('Error in IDCC_DeviceSimulatorlEVEL2 : getLevel2Data');
            }
        });
        $A.enqueueAction(action);
    }
})