({
	paymentHistory : function(component, event, helper) {
          
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
		var recordId = component.get("v.recordId");         
        var tmp = staticLabel+'resObjName=Query_Payment_History_Res&apiName=Query_Payment_History&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
        //setInterval(function(){ document.getElementById("paymentSpin").style.display = "none";},2000);
             
	},
   /*  hideSpinner: function (component, event, helper) {         
        var spinner = component.find('spinner');
         var evt = spinner.get("e.toggle");
        evt.setParams({ isVisible : false });
        evt.fire();    
        //$A.util.removeClass(spinner, 'loadSpinner');
        //$A.util.addClass(spinner, 'newLoadSpinner');
    }, */
    /*BAledger : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
		var recordId = component.get("v.recordId");
        var tmp = staticLabel+'resObjName=Query_BA_Ledger_Res&apiName=Query_BA_Ledger&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
         
	},*/
    Summary : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleForm");
		var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Summary&resObjName=Query_Summary_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
         
	},
    Usage : function(component, event, helper) {
        /*var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleForm");
		var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Usage&resObjName=Query_Usage_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();*/
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
		var recordId = component.get("v.recordId");
        var tmp = staticLabel+'resObjName=Query_Usage_Res&apiName=Query_Usage&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
         
	},
    invoiceHistory : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.IDCC_SandboxURL");
		var recordId = component.get("v.recordId");
        var tmp = staticLabel+'/apex/IDCC_ConsoleInvoicePDFMain?resObjName=Query_Invoice_History_Res&apiName=Query_Invoice_History&recordId='+recordId;
        component.set("v.URL",tmp);
        var divId  = document.getElementsByClassName("tabset") ;
        helper.scrolltoTop();
        
        
         // setInterval(function(){ 
          //   document.getElementById("spinnerId3").style.display = "none";},2000);
    
	},
    /*
    invoicePDF : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleInvoicePDF");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'resObjName=Query_Invoice_PDF_res&apiName=Query_Invoice_PDF&recordId='+recordId;
        component.set("v.URL",tmp);
        var divId  = document.getElementsByClassName("tabset") ;
        helper.scrolltoTop();
	},
    */
   	pDiscount : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Progressive_Discount&resObjName=Query_Progressive_Discount_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},   
    billRevenue : function(component, event, helper) {
       // var staticLabel = 'https://indosat--indosatdev--c.cs75.visual.force.com/apex/IDCC_ConsoleTablePrem?';
         var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Billing_Account_Invoice_Revenue&resObjName=Query_Billing_Account_Invoice_RevenueRes&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},
     fetchQueryAsset : function(component, event, helper) {
        var staticLabel = 'https://indosat--indosatdev--c.cs75.visual.force.com/apex/IDCC_ConsoleAssetForm?';
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Asset_Info_Catalyst&resObjName=Query_Asset_Catalyst_Res&recordId='+recordId;
   //  var tmp =  'https://indosat--indosatdev--c.cs75.visual.force.com/apex/IDCC_ConsoleAssetForm?apiName=Query_Asset_Info_iCare&resObjName=Query_Asset_iCare_Post_Res&recordId='+recordId; 
       var tmp = staticLabel+'apiName=Query_Asset_Info_Catalyst&resObjName=Query_Asset_Catalyst_Res&recordId='+recordId;
         component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},
    
    RefreshComponent: function (component, event, helper) {
        //var a = component.get('c.doInit');
        //$A.enqueueAction(a);
    },
    
     // this function automatic call by aura:waiting event  
   /* showSpinner: function(component, event, helper) {
       // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
        setTimeout(function(){ component.set("v.Spinner", false); }, 1000);
   },
    
 // this function automatic call by aura:doneWaiting event 
    hideSpinner : function(component,event,helper){
     // make Spinner attribute to false for hide loading spinner 
       //var spinner = component.find('spinner');  
        var spin = component.find('spinnerId');
        var spin1 = component.find('paymentSpin');
        
         setInterval(function(){ 
             $A.util.removeClass(spin, 'slds-spinner_container')
             $A.util.removeClass(spin1, 'slds-spinner slds-spinner--large slds-is-relative');},2000);
    },*/
    adjustmentHistory : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleAdjustmentHistory?resObjName=Query_Adjustment_History_Res&apiName=Query_Adjustment_History&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();      
	},
    hideSpinner: function (component, event, helper) {         
        var spinner = component.find('spinner');
        $A.util.removeClass(spinner, 'loadSpinner');
        $A.util.addClass(spinner, 'newLoadSpinner');
    },
    
})