({
    doInit : function(cmp, event, helper) {

        	var recordId = cmp.get("v.recordId"); 
            var action = cmp.get("c.getSocialPersona");
            
        //alert('social recordId'+recordId);
            action.setParams({ caseId: recordId});
            action.setCallback(this,
                               function(response1)
                                              {
                                                   cmp.set('v.mycolumns', [
            												{label: 'Social Network', fieldName: 'Provider',  type: 'text'},
                											{label: 'Social Handle', fieldName: 'Name', type: 'text'},
                											{label: 'Real Name', fieldName: 'RealName',  type: 'text'},
                											{label: 'Followers', fieldName: 'Followers',  type: 'number'},
                                                            {label: 'Following', fieldName: 'Following',  type: 'number'}]);
                                                  var state = response1.getState();                                                    
                                                  if (state == "SUCCESS")  
                                                  {
                                                      
                                                      var socialPersona = response1.getReturnValue();
                                                      cmp.set('v.socialPersona',socialPersona);                                                   
                                                  }
                                                  
                                              }
                                             );
        
            $A.enqueueAction(action);       
        
    }
})