({
    /* navigateToRecord : function(component, event, helper) {
        window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/displaycaserecord?id='+event.currentTarget.id, '_self');
    },*/
    navigateToRecord : function(component, event, helper) {        
        var idx= event.currentTarget.id;
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": idx,
            "slideDevName": "detail"            
        });
        navEvt.fire();         
    },
       
    scrollHor : function(component, event, helper){
     helper.scrollHor(component,event);
}
})