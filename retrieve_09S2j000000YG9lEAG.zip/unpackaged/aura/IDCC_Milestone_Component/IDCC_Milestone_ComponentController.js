({
    init : function(cmp, event, helper) {
        console.log("Init--");
        var recordId = cmp.get("v.recordId"); 
        var action = cmp.get("c.getMilestone");
        var MilestoneType ='';
        var IsCompleted=false;
        var IsViolated=false;
        var TimeRemainingInMins=0;
        var TimeSinceTargetInMins=0;
        var TargetResponseInMins=0;
        action.setParams({ caseId: recordId});
        action.setCallback(this,
                           function(response)
                           { 
                               var state = response.getState();                                                                  
                               if (state == "SUCCESS" && response.getReturnValue()!=null)  
                               {
								   try{
                                   var milestone = response.getReturnValue();
                                   var countVal = 0;
                                   var colorCheck =null;
                                   var timeInMins =0;
                                   var whiteColor=0;
                                   TargetResponseInMins = milestone.TargetResponseInMins;
                                   MilestoneType = milestone.MilestoneType.Name;
                                   IsCompleted= milestone.IsCompleted;
                                   IsViolated= milestone.IsViolated;  
                                   TimeSinceTargetInMins=milestone.TimeSinceTargetInMins;
                                   TimeRemainingInMins=milestone.TimeRemainingInMins;                                   
                                   console.log('IsViolated: ' + milestone.IsViolated);
                                   console.log ('IsCompleted: '+milestone.IsCompleted);
                                   if(milestone.IsViolated==false && milestone.IsCompleted==false){
                                       var timeInMins1 = milestone.TimeRemainingInMins;
                                       var timeInMins2 = timeInMins1.split(":");
                                       timeInMins = parseInt(timeInMins2[0]*60) + parseInt(timeInMins2[1]);
                                       colorCheck = "#006644";
                                       whiteColor = ((TargetResponseInMins*60)-timeInMins); //new Date(processTime).getTime()                                                    	
                                       callChart(timeInMins,colorCheck,whiteColor);
                                       
                                   }else if(IsViolated==false && IsCompleted==true){                                                		
                                       var timeInMins = milestone.ElapsedTimeInMins*60;
                                       colorCheck = "#006644";
                                       whiteColor = 0; 
                                       callChart(timeInMins,colorCheck,whiteColor);
                                       
                                   }else if(IsViolated==true && IsCompleted==false){  	
                                       var timeInMins1 = milestone.TimeSinceTargetInMins; 
                                       var timeInMins2 = timeInMins1.split(":");
                                       timeInMins = parseInt(timeInMins2[0]*60) + parseInt(timeInMins2[1]);
                                       whiteColor=0;
                                       colorCheck = "#C50000";
                                       callChart(timeInMins,colorCheck,whiteColor);
                                       
                                   }else if(IsViolated==true && IsCompleted==true){  
                                       
                                       var timeInMins1 = milestone.TimeSinceTargetInMins; 
                                       var timeInMins2 = timeInMins1.split(":");
                                       timeInMins = parseInt(timeInMins2[0]*60) + parseInt(timeInMins2[1]);
                                       whiteColor=0;
                                       colorCheck = "#C50000";
                                       callChart(timeInMins,colorCheck,whiteColor);                                                        
                                   }
                                   
                                   window.setInterval(
                                       $A.getCallback(function() {
                                           if(colorCheck!=null && colorCheck!=undefined){
                                               if(colorCheck=="#006644"){
                                                   if(timeInMins>0 && milestone.IsCompleted==false){
                                                       timeInMins--;
                                                       whiteColor++;
                                                       callChart(timeInMins,colorCheck,whiteColor);
                                                       
                                                   }else if(timeInMins<=0 && milestone.IsCompleted==false){
                                                       colorCheck="#C50000"; 
                                                       timeInMins++;
                                                       whiteColor=0;
                                                       callChart(timeInMins,colorCheck,whiteColor);
                                                       
                                                   }       
                                               }else if(colorCheck=="#C50000"){
                                                   timeInMins++;
                                                   if( milestone.IsCompleted==false){  
                                                       whiteColor=0;
                                                       
                                                       callChart(timeInMins,colorCheck,whiteColor);
                                                       
                                                   }
                                               }
                                           }
                                       } ),1000);                                                        
                                   callChart(timeInMins,colorCheck,whiteColor);                                                           
						   }catch(e){
							   console.error(e);
						   }		 }					   
                           });
        
        function callChart(timeInMins,colorCheck,whiteColor){
            
            var hours =  Math.floor(timeInMins/3600);
            var finalHours = hours;
            if(hours.toString().length<2){
              finalHours = ("0" + hours);  
            }
            var finalMins1 = Math.floor(timeInMins % 3600/60);
            var Secs = Math.round(timeInMins%60);
            var finalSecs = ("0" + Secs).slice(-2);
            var finalMins;
            if(finalMins1.toString().length<2){
            	 finalMins = ("0" + finalMins1);
            }else{
                 finalMins = finalMins1;
            }
            cmp.set('v.milestone',finalHours+':'+finalMins+':'+finalSecs);
            
            
            var labelset=[] ;
            var dataset=[] ;
            
            cmp.set('v.completeStatus',IsCompleted);
            cmp.set('v.MilestoneType',MilestoneType);
            cmp.set('v.violateStatus',IsViolated);
            
            dataset.push(timeInMins,whiteColor) ;    
            
            /*var canvas1 = document.getElementById("pie-chart");  
            			if(canvas1.getContext) {  
       						     var ctx = canvas1.getContext("2d");  
    					}
             canvas1.parentNode.removeChild(canvas1);
            document.getElementById('chartDiv').innerHTML = '<canvas id="pie-chart"></canvas>';*/
          try{
            document.getElementById("chartDiv").innerHTML = '<canvas aura:id="pieChart" id="pie-chart"/>';
            console.log( document.getElementById("chartDiv").innerHTML);
            var chartArea = document.getElementById("pie-chart");
            var pieChart = new Chart(chartArea,{type:'doughnut', data:{}, options:{}});
            pieChart.clear();
            pieChart.destroy();
            pieChart = new Chart(chartArea, {
                type: 'doughnut',
                data: {
                    labels:labelset,
                    datasets: [{
                        label: "Count of Task",    
                        backgroundColor: [colorCheck,"#bfbfbf", "#8e5ea2","#e8c3b9"],
                        data: dataset
                    }]
                },
                options: {
                    cutoutPercentage: 64,
                    
                    layout: {
                        padding: {
                            left: 0,
                            right: 0,
                            top: 0,
                            bottom: 0,
                        }
                    },
                    
                    tooltips: {
                        enabled: false
                    },
                    responsive: true,
                    maintainAspectRatio: false,
                    animation: false,
                }                          
            });   
		}catch(e){
			console.error(e);
		}			
        } 
        //$A.get('e.force:refreshView').fire();
        $A.enqueueAction(action);         
   
    }
})