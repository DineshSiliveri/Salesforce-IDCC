({
    showListViewData : function(component, event, helper) {
        
        var setOptions = component.find("selectvalues");       
        var action = component.get("c.fetchListViews");
        
        var optionValues = [];
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == "SUCCESS") {                 
                $A.util.removeClass(component.find('div1'), 'slds-hide');
                $A.util.addClass(component.find('div1'), 'slds-show');
                var listviewvalue = response.getReturnValue();
                if(listviewvalue != null && listviewvalue != undefined) {
                    optionValues.push({
                        class:"optionclass",
                        label:"--None--",
                        value:""
                    });
                }
                for(var i=0; i<listviewvalue.length; i++) {
                    console.log(' '+JSON.stringify(listviewvalue));
                    optionValues.push({
                        class:"optionclass",
                        label:listviewvalue[i].Name,
                        value:listviewvalue[i].DeveloperName
                    });

                }
                setOptions.set("v.options", optionValues);
            }
        });
        $A.enqueueAction(action); 
    },
    
    showRecordsData : function(component, event, helper) {
        var selectedName = component.find("selectvalues").get("v.value");
        console.log('selectedName'+component.find("selectvalues"));
        component.set("v.viewName", selectedName);
        component.set("v.body" , []);
        $A.createComponent(
            "lightning:listView",
            {
                "objectApiName" : "Case",
                "listName" : component.get("v.viewName"),
                "rows": 10,
                "showActionBar":false,
                "enableInlineEdit":false,
                "showRowLevelActions":false,
                "showSearchBar":true
                            
            },
            function(newListView, status, errorMessage){
                if (status === "SUCCESS") {
                    var body = component.get("v.body");
                    body.push(newListView);
                    component.set("v.body", body);
                }
                else if (status === "INCOMPLETE") {
                    console.log("No response from server or client is offline.")
                }
                    else if (status === "ERROR") {
                        console.log("Error: " + errorMessage);
                    }
            }
        );  
    },
    
    convertArrayOfObjectsToCSV : function(component,objectRecords){
        
        
        // declare variables
        var csvStringResult, counter, keys, columnDivider, lineDivider;
       
        // check if "objectRecords" parameter is null, then return from function
        if (objectRecords == null || !objectRecords.length) {
            return null;
         }
        // store ,[comma] in columnDivider variabel for sparate CSV values and 
        // for start next line use '\n' [new line] in lineDivider varaible  
        columnDivider = ',';
        lineDivider =  '\n';
 
        // in the keys valirable store fields API Names as a key 
        // this labels use in CSV file header  
        keys = ['CaseNumber','Contact','Subject','Origin','Status','Priority','Owner','CreatedDate','RecordType'];        
        csvStringResult = '';
        csvStringResult += keys.join(columnDivider);
        csvStringResult += lineDivider;
 
        for(var i=0; i < objectRecords.length; i++){   
            counter = 0;
           
             for(var sTempkey in keys) {
                var skey = keys[sTempkey] ;  
 
              // add , [comma] after every String value,. [except first]
                  if(counter > 0){ 
                      csvStringResult += columnDivider; 
                   }   
                 if (skey=='Owner'){
                      if(objectRecords[i][skey]==undefined){
                         csvStringResult +='';
                     }else{
                     csvStringResult += '"'+ objectRecords[i][skey]['NameOrAlias']+'"';
                     }
                 }else if (skey=='Contact'){
                     if(objectRecords[i][skey]==undefined){
                         csvStringResult +='';
                     }else{
                     csvStringResult += '"'+ objectRecords[i][skey]['Name']+'"'; 
                     }
                 }else if (skey=='RecordType'){
                      if(objectRecords[i][skey]==undefined){
                         csvStringResult +='';
                     }else{
                     csvStringResult += '"'+ objectRecords[i][skey]['Name']+'"'; 
                         }
                 }
                 else                     
                 {
               csvStringResult += '"'+ objectRecords[i][skey]+'"';       
                 }
               
               
               counter++;
 
            } // inner for loop close 
             csvStringResult += lineDivider;
          }// outer main for loop close 
       
       // return the CSV formate String 
        return csvStringResult;        
    },
    generateCsv : function(component,listViewRecords){
    
  
        var csv = this.convertArrayOfObjectsToCSV(component,listViewRecords);   
         if (csv == null){return;} 
  
	     var hiddenElement = document.createElement('a');
          hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
          hiddenElement.target = '_self'; // 
          hiddenElement.download = 'ListView.csv';  // CSV file Name* you can change it.[only name not .csv] 
          document.body.appendChild(hiddenElement); // Required for FireFox browser
    	  hiddenElement.click(); // using click() js function to download csv file
	}
})