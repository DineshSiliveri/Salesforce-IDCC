({
    doInit : function(component, event, helper) {
        helper.showListViewData(component, event, helper);
    },
    
    onListViewChange : function(component, event, helper) {
        helper.showRecordsData(component, event, helper);
    },
    
        // ## function call on Click on the "Download As CSV" Button. 
    downloadCsv : function(component,event,helper){
        var viewName = component.get("v.viewName");
        console.log(viewName);
        var action = component.get("c.getFilteredAccounts");
        action.setParams({'filterId':viewName});
        
        action.setCallback(this, function(response){
            var state = response.getState();
            var listViewrecords = response.getReturnValue();
            console.log("Account List@@@"+listViewrecords);
            if(state == "SUCCESS") {    
                helper.generateCsv(component,listViewrecords);
            }
        });
         $A.enqueueAction(action);
        // get
        //  the Records [contact] list from 'ListOfContact' attribute 
        
        }, 
})