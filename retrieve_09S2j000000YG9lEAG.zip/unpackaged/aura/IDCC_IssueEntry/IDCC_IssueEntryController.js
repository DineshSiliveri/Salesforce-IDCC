({
	showIssueEntries : function(component, event, helper) {
        var baseUrl = $A.get("$Label.c.IDCC_SandboxURL");
        var staticLabel = baseUrl+'apex/IDCC_ConsoleIssueEntryListView?caseId=';
		var record = component.get("v.recordId");
        var tmp = staticLabel+record; 
       // var tmp = staticLabel+'resObjName=BA_Ledger_Res&apiName=Query_BA_Ledger&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
		
	}
})