({
    
    loginToPortal : function(component, event, helper) {
        var action = component.get("c.doLogin");
        action.setParams({
            user: component.get("v.User"),
            password: component.get("v.Password")
        });
        action.setCallback(this,function (response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if(result != null) {
                result = result.replace('username', 'Email Id');
                component.set("v.errorMsg",result);	  
            }
        });   
        $A.enqueueAction(action);	
    },
    createAndSendOTP : function (component,event, helper) {  
        var action = component.get("c.createAndSendOTPApex");
        action.setParams({
            user: component.get("v.User")
        });
        action.setCallback(this,function (response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS"){
                if(result){
                    console.log('In success IDCC_verifyOTP: createAndSendOTP');
                    helper.sendSMS(component,event, helper);
                }
                else{
                    console.log('Error while inserting record in USER_OTP Object :IDCC_verifyOTP');        
                }
            }
            else{
                console.log('Error in IDCC_verifyOTP : createAndSendOTP');
            }
        });
        $A.enqueueAction(action);    
    },
    sendSMS : function (component,event, helper) { 
        var action = component.get("c.sendSMSAPICall");
        action.setParams({
            user: component.get("v.User")
        });
        action.setCallback(this,function (response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state == "SUCCESS"){
                if(!$A.util.isEmpty(result)){
                 	for(var key in result) {
                        if(key =='Success'){
                            component.set("v.isSMSReSend",true);
                        }
                        else{
                        	component.set("v.errorMsg","Failed to send OTP. Please try again.");       
                        }
					}
                 }
                else{
                	console.log('Error in sendSMS : result'+result);   
                    component.set("v.errorMsg","Failed to send OTP. Please try again.");    
                }
            }
            else{
                console.log('Error in IDCC_VerifyOTP : sendSMS');
            }
        });
        $A.enqueueAction(action);    
    },
    remainingSeconds1 : function(component, sec) {
        if(sec>0){
            if(sec>=10 && sec<=60){
                component.set("v.otpTimer",'00:'+sec+' Secs');
            }else if(sec<10){
                component.set("v.otpTimer",'00:0'+sec+' Secs');
            }else if(sec>60){
                var min = Math.floor(sec/60);
                var sec1 = sec%60;
                if(sec1<10){
                    component.set("v.otpTimer",'0'+min+':0'+sec1+' Secs');
                }else{
                    component.set("v.otpTimer",'0'+min+':'+sec1+' Secs');    
                }
                
            }
            
        }else{
            component.set("v.otpTimer","Expired");
        }
        
        
    },
    remainingSeconds : function(component, event, helper) {
        var idVar;
        component.set("v.otpTimer","");
        var sec = $A.get("$Label.c.IDCC_OTP_TimerSeconds");
        var timerFun = component.get("v.timerFun");
        
        idVar = setInterval( () =>{
            sec--;
            if(sec>0){
            helper.remainingSeconds1(component,sec);
            document.getElementById("resendOTP").disabled = true;
            document.getElementById("resendOTP").style.cursor = 'none';
            document.getElementById("resendOTP").style.background = 'grey';
        }else{
            component.set("v.otpTimer","Expired");
            clearInterval(idVar); 
            document.getElementById("resendOTP").disabled = false;
            document.getElementById("resendOTP").style.background = '#ed1c24';
            document.getElementById("resendOTP").style.cursor = 'pointer';
        }
            
        }, 1000);
            
        }
            
        })