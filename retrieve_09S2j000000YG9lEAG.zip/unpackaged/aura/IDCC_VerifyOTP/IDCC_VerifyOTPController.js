({
    doInit : function(component, event, helper) {
        var msn = component.get("v.User");
        var res1 =  msn.MSISDN__c;
        var res = res1.substring(res1.length - 4, res1.length);
        component.set("v.msisdn4",res);
        
        $('.digit-group').find('input').each(function() {
            $(this).attr('maxlength', 1);
            $(this).on('keyup', function(e) {
                var parent = $($(this).parent());
                var digit1 = document.getElementById("digit-1").value;
                var digit2 = document.getElementById("digit-2").value;
                var digit3 = document.getElementById("digit-3").value;
                var digit4 = document.getElementById("digit-4").value;
                var digit5 = document.getElementById("digit-5").value;
                var digit6 = document.getElementById("digit-6").value;
                if(document.getElementById("digit-1").value && document.getElementById("digit-2").value
                   && document.getElementById("digit-3").value && document.getElementById("digit-4").value
                   && document.getElementById("digit-5").value && document.getElementById("digit-6").value){
                    document.getElementById("verfiyOTP").disabled = false;  
                    document.getElementById("verfiyOTP").style.background = "#ed1c24";
                    document.getElementById("verfiyOTP").style.cursor = 'pointer';
                }else{
                    document.getElementById("verfiyOTP").disabled = true;  
                    document.getElementById("verfiyOTP").style.background='grey';
                    document.getElementById("verfiyOTP").style.cursor = 'none';
                }
                if(e.keyCode === 8 || e.keyCode === 37) {
                    var prev = parent.find('input#' + $(this).data('previous'));
                    
                    if(prev.length) {
                        $(prev).select();
                    }
                }else if((e.keyCode >= 48 && e.keyCode <= 57) || e.keyCode === 39) {
                    var next = parent.find('input#' + $(this).data('next'));
                    
                    if(next.length) {
                        $(next).select();
                    } else {
                        if(parent.data('autosubmit')) {
                            parent.submit();
                        }
                    }
                }else if ((e.keyCode != 8 && e.keyCode < 48) || (e.keyCode > 57)) {
                    // e.preventDefault();
                    return false;
                    
                } 
            });
        });
        
        helper.remainingSeconds(component, event, helper);
    },
    verfiyOTP :function(component, event, helper) {
        if(component.get("v.otpTimer") == 'Expired'){
            component.set("v.errorMsg","OTP Expired, please use resend OTP option");
            var digit1 = document.getElementById("digit-1").value='';
			var digit2 = document.getElementById("digit-2").value='';
        	var digit3 = document.getElementById("digit-3").value='';
        	var digit4 = document.getElementById("digit-4").value='';
        	var digit5 = document.getElementById("digit-5").value='';
        	var digit6 = document.getElementById("digit-6").value='';
        }
        else{
            
            var digit1 = document.getElementById("digit-1").value;
            var digit2 = document.getElementById("digit-2").value;
            var digit3 = document.getElementById("digit-3").value;
            var digit4 = document.getElementById("digit-4").value;
            var digit5 = document.getElementById("digit-5").value;
            var digit6 = document.getElementById("digit-6").value;
            if(digit1=='' || digit2 =='' || digit3 =='' || digit4 =='' || digit5 =='' || digit6 ==''){
                component.set("v.errorMsg","Please enter all values");  
            }
            else{
                var finalOTP = digit1 + digit2 + digit3 + digit4 + digit5 + digit6;
                console.log(finalOTP);
                var action = component.get("c.verifyOTP");
                action.setParams({
                    user: component.get("v.User")
                });
                action.setCallback(this,function (response) {
                    var state = response.getState();
                    var result = response.getReturnValue();
                    if (state === "SUCCESS"){
                        if(result.Name == finalOTP  && component.get("v.isSMSReSend")){
                            component.set("v.errorMsg",""); 
                            helper.loginToPortal(component, event, helper);
                        }
                        else{
                            component.set("v.errorMsg","Wrong OTP entered Please check again."); 
                             var digit1 = document.getElementById("digit-1").value='';
        					 var digit2 = document.getElementById("digit-2").value='';
        					 var digit3 = document.getElementById("digit-3").value='';
        					 var digit4 = document.getElementById("digit-4").value='';
        					 var digit5 = document.getElementById("digit-5").value='';
        					 var digit6 = document.getElementById("digit-6").value='';
                        }
                    }
                    else{
                        console.log('Error in IDCC_VerrifyOTP : verfiyOTP');
                    }
                });
                $A.enqueueAction(action);        
            }
        }
    },
    resendOTP :function(component, event, helper) {
        var msn = component.get("v.User");
        var res1 =  msn.MSISDN__c;
        var res = res1.substring(res1.length - 4, res1.length);
        component.set("v.msisdn4",res);
        //document.getElementById("myForm").reset(); 
        var digit1 = document.getElementById("digit-1").value='';
    	var digit2 = document.getElementById("digit-2").value='';
    	var digit3 = document.getElementById("digit-3").value='';
    	var digit4 = document.getElementById("digit-4").value='';
    	var digit5 = document.getElementById("digit-5").value='';
    	var digit6 = document.getElementById("digit-6").value='';
        component.set("v.errorMsg","");
        var sec = $A.get("$Label.c.IDCC_OTP_TimerSeconds");
        helper.remainingSeconds(component, event, helper);
        helper.createAndSendOTP(component, event, helper);
    },
    
    
})