({
    //Init method
    doInit : function(component, event, helper){
        helper.getLevel3Data(component, event, helper);
    },
    //method for event handling of handling menu buton
    handleMenuSelect: function(component, event, helper) {
        var selectedMenuId = event.detail.menuItem.get("v.value");
        var menuItems = component.find("menuItems");
        menuItems.forEach(function (menuItem) {
            if (menuItem.get("v.checked")) {
                menuItem.set("v.checked", false);
            }
            if (menuItem.get("v.value") === selectedMenuId) {
                menuItem.set("v.checked", true);
            }
        });
        component.set("v.level3DeviceId",selectedMenuId);
        component.set("v.lstOfImages", null);
        var lst = component.get("v.imageURLLevel3Lst");
        for(var imageURL in lst){
            if(lst[imageURL].value.Id == selectedMenuId){
                var name = lst[imageURL].value.Name.split('-');
                component.set("v.selectedLevel3ImageName",name[0]); 
                break;
            }
        }
        helper.getLevel4Data(component, event, helper);
    },
    handleMenuSelectForLevel2 :function(component, event, helper) {
        var selectedMenuId = event.detail.menuItem.get("v.value");
        component.set("v.level2DeviceId",selectedMenuId);
        var menuItems = component.find("menuItemsLst");
        menuItems.forEach(function (menuItem) {
            if (menuItem.get("v.checked")) {
                menuItem.set("v.checked", false);
            }
            if (menuItem.get("v.value") === selectedMenuId) {
                menuItem.set("v.checked", true);
            }
        });
        if(component.get("v.calledFrom") == 'search'){
        	var level4ToLevel3EventForSearchCmp = component.getEvent("Level4ToLevel3EventForSearchCmp");
            level4ToLevel3EventForSearchCmp.setParams({
                "recordId" : component.get("v.level2DeviceId")
            });
            level4ToLevel3EventForSearchCmp.fire();        
        }
        else{
            var level4ToLevel3EventForDropDown = component.getEvent("Level4ToLevel3EventForDropDown");
            level4ToLevel3EventForDropDown.setParams({
                "recordId" : component.get("v.level2DeviceId")
            });
            level4ToLevel3EventForDropDown.fire();    
        }
        
    },
    
    //method called on click of left icon to see previous image
    previous : function(component, event, helper){
        helper.previous(component, event);
    },
     //method called on click of right icon to see next image
    next : function(component, event, helper){
        helper.next(component, event);
    },
})