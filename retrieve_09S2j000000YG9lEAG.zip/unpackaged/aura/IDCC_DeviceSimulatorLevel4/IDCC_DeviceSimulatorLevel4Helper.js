({
    getLevel3Data : function(component, event, helper) {
        var action = component.get("c.getLevel3NameLst");
        action.setParams({selectedLevel3DeviceId : component.get("v.level3DeviceId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                var imageURLLevel3NameLst = [];
                var imageURLLevel3 =[];
                var imageURLLevel3WithObj = [];
                for(var key in result){
                    if(result[key].Name.includes('-')){
                        var name = result[key].Name.split('-');
                        imageURLLevel3.push({value:name[0], key:key}); 
                    } 
                    else{
                        imageURLLevel3.push({value:result[key].Name, key:key});    
                    }
                    imageURLLevel3WithObj.push({value:result[key], key:key});    
                }
                component.set("v.level3Lst", imageURLLevel3);
                component.set("v.imageURLLevel3Lst", imageURLLevel3WithObj);
                helper.getLevel4Data(component, event, helper);
            }
            else{
                console.log('Error in IDCC_DeviceSimulatorLevel4 : getLevel3Data');
            }
        });
        $A.enqueueAction(action);
        
    },
    getLevel4Data : function(component, event, helper) {
        var action = component.get("c.getLevel4DeviceSimulator");
        action.setParams({selectedLevel3DeviceId : component.get("v.level3DeviceId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS"){
                if($A.util.isEmpty(result)){
                    component.set("v.lstOfImages", null);    
                }
                else{
                    var linkLst =  result[0];
                    var descLst = result[1];
                    var lstOfImages =[];
                    for(var i=0;i<linkLst.length;i++){
                        var index = i+1;
                        lstOfImages.push({image:linkLst[i],Header:"Step "+ index + " of "+ linkLst.length ,Description:descLst[i],AlterText:"",imgUrl: ""});             
                    }
                    component.set("v.lstOfImages", lstOfImages);
                    component.set("v.imageCount", lstOfImages.length);
                    console.log('lstOfImages---------------'+lstOfImages);    
                }
                
            }
            else{
                console.log('Error in IDCC_DeviceSimulatorlEVEL4 : getLevel4Data');
            }
        });
        $A.enqueueAction(action);
    },
    
    
    //method called on click of right icon to see next image
    next : function(component, event) {
        var start =component.get("v.startIndex");
        var end =component.get("v.endIndex");
        component.set("v.startIndex" , start+1);
        component.set("v.endIndex" , end+1);
    },
    
    //method called on click of left icon to see previous image
    previous : function(component, event) {
        var start =component.get("v.startIndex");
        var end =component.get("v.endIndex");
        component.set("v.startIndex" , start-1);
        component.set("v.endIndex" , end-1);
    },
})