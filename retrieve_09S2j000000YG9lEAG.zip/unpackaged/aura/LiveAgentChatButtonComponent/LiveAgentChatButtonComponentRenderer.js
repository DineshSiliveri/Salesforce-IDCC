({
	// Your renderer method overrides go here
	afterRender: function (component, helper) {
        this.superAfterRender();
        // interact with the DOM here
        if (!window._laq) { 
        window._laq = []; 
        console.log('0000 - !window._laq');    
        }
        var deploymentId = component.get("v.deploymentId");
		var buttonId = component.get("v.buttonId");
        window._laq.push(function(){
        console.log('in push function');
        console.log(component.find('liveagent_button_online_5735D000000002v').elements[0]);
        liveagent.showWhenOnline(buttonId, component.find('liveagent_button_online_5735D000000002v').elements[0]);
        liveagent.showWhenOffline(buttonId, component.find('liveagent_button_offline_5735D000000002v').elements[0]);
        console.log('0000 - window._laq.push');
        });
		var action = component.get("c.getUserName");
        action.setCallback(this, function(response){
        var state = response.getState();
        if (state === "SUCCESS") {
           liveagent.addCustomDetail('Name', response.getReturnValue());
         }
      	});
        $A.enqueueAction(action);
        var actionEmail = component.get("c.getUserEmail");
        actionEmail.setCallback(this, function(response){
        var state = response.getState();
        if (state === "SUCCESS") {
           liveagent.addCustomDetail('Email', response.getReturnValue());
         }
      	});
        $A.enqueueAction(actionEmail);
        var actionPhone = component.get("c.getUserPhone");
        actionPhone.setCallback(this, function(response){
        var state = response.getState();
        if (state === "SUCCESS") {
            if(response.getReturnValue() != null){
           		liveagent.addCustomDetail('Phone', response.getReturnValue());     
            } 
           
         }
      	});
        $A.enqueueAction(actionPhone);
        //liveagent.addCustomDetail('Name', );
		//liveagent.addCustomDetail('Email', );
        //liveagent.addCustomDetail('ContactNumber', );
		
         liveagent.init('https://d.la1-c1-ukb.salesforceliveagent.com/chat',deploymentId , '00D7F000002CnrR');
        console.log('0000 - Live Agent Initialized');
        liveagent.enableLogging();
    },
})