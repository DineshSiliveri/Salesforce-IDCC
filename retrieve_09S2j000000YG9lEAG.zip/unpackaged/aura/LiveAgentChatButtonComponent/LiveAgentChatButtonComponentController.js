({
	
    startChat : function(component, event, helper) {
        console.log('in start chat BEFORE ');
		var buttonId = component.get("v.buttonId");
        liveagent.startChat(buttonId);
        console.log('in start chat AFTER ');
    }
})