({
    init : function(component, event, helper) {
        helper.retrievePageLayout(component, helper);
    },
    
    onRecordSubmit : function(component, event, helper) {
        helper.onRecordSubmit(component, helper);
    },
  
    refreshAction: function(component, event, helper) {
        helper.refreshAction(component, helper);
    },
    
    handleError: function(component, event, helper) {
        helper.handleError(component, helper);
    },

})