({ 
    doInit : function(component, event, helper) {
        helper.getFileData(component, event, helper);
    },
    handleUploadFinished: function(component, event, helper) {
        var uploadedFiles = event.getParam("files");
        var fileIds=[];
        uploadedFiles.forEach(function(file){
            fileIds.push(file.documentId);
        });
        component.set('v.fileIds', fileIds);
        component.set("v.UploadedFiles",uploadedFiles);
        $A.get('e.force:refreshView').fire();
        helper.getFileData(component, event,helper)
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "type" : "success",
            "message": uploadedFiles.length+" files has been uploaded successfully!"
        });
        toastEvent.fire();
    },
    
    handleAttachFileScroll : function(component, event, helper) {
        var elmnt = document.getElementById('AllAttachments');
        elmnt.scrollIntoView();   
    },
    
    handleDeleteFile : function(component, event, helper) {
        var fileId = event.currentTarget.id;
        component.set("v.fileId",fileId); 
        component.set("v.openFileDeleteConfrim",true); 
    },
    handleDeleteDoc : function(component, event, helper) {
        helper.handledelete(component, event, helper,component.get("v.fileId"));
    },
    
    closeModel : function(component, event, helper) {
        component.set("v.openFileDeleteConfrim", false);
    },
    closeFileViewModal : function(component, event, helper) {
        component.set("v.isOpenFileViewModal", false);
    },
    getSelectedFile : function(component, event, helper) {
        component.set("v.isOpenFileViewModal" , true);
        component.set("v.selectedDocumentId" , event.currentTarget.getAttribute("data-Id")); 
    },
    
})