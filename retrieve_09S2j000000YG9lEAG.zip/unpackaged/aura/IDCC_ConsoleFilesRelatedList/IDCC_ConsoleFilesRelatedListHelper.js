({
    getFileData : function(component, event, helper) {
        var action = component.get("c.getFiles");
        action.setParams({  
            "recordId":component.get("v.recordId")  
        });      
        action.setCallback(this,function(response){  
            var state = response.getState(); 
            if(state=='SUCCESS'){  
                var result = response.getReturnValue();
                component.set("v.files",result);
                component.set("v.fileLstSize",result.length);
            }  
            else{
                console.log('Error in getFileData ---');
            }
        });          
        $A.enqueueAction(action); 
    },
    
    handledelete : function(component, event, helper,fileId) {
        var action = component.get("c.deleteFile");
        action.setParams({  
            "fileId":fileId  
        });      
        action.setCallback(this,function(response){  
            var state = response.getState(); 
            if(state=='SUCCESS'){  
                var result = response.getReturnValue();
                if(result){
                    this.getFileData(component,event, helper)
                    $A.get('e.force:refreshView').fire();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "type" : "success",
                        "message": "File deleted successfully"
                    });
                    toastEvent.fire();    
                }
                else{
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Warning!",
                        "type" : "warning",
                        "message": "you do not have permissions to delete this file."
                    });
                    toastEvent.fire();     
                }
                component.set("v.openFileDeleteConfrim",false); 
                
            }  
            else{
                console.log('Error in handledelete ---');
            }
        });          
        $A.enqueueAction(action); 
    },
})