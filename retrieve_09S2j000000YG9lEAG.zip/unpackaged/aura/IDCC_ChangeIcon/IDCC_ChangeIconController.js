({
    doInit : function(cmp, event, helper) {
        var workspaceAPI = cmp.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId; 		
            var instaIcon = $A.get('$Resource.final_icons') + '/custom/custom115_60.svg#instagram';
            var action = cmp.get("c.getIcon");
            // action.setParams({ caseId: response.recordId});
            action.setParams({ caseId: cmp.get("v.recordId")});
            action.setCallback(this,
                               $A.getCallback(function(response1)
                                              {
                                                  var state = response1.getState();    
                                                  console.log('state!!!!'+state);
                                                  if (state == "SUCCESS")  
                                                  {                                                      
                                                      var result= response1.getReturnValue();
                                                      var finalString=result.split("-");
                                                      console.log(finalString+'finalString');                                                      
                                                      if(finalString[0]=="call"){
                                                          workspaceAPI.setTabHighlighted({ tabId: focusedTabId,highlighted: true,options: {pulse: false,state: "error"}});//Addded by Vaidehi
                                                          workspaceAPI.setTabIcon({tabId: focusedTabId, icon: "action:"+ result, iconAlt: "Call"});   
                                                      }else if(finalString[0]=="web_link"){                                                          
                                                          workspaceAPI.setTabIcon({tabId: focusedTabId, icon: "action:"+ result, iconAlt: "Web"});   
                                                      }else if(finalString[0]=="email"){
                                                          
                                                          workspaceAPI.setTabIcon({tabId: focusedTabId, icon: "action:"+ result, iconAlt: "Email"});   
                                                      }else if(finalString[0]=="FB"){
                                                          
                                                          workspaceAPI.setTabIcon({tabId: focusedTabId, icon: "utility:like", iconAlt: "Facebook" }); 
                                                          workspaceAPI.setTabLabel({tabId: focusedTabId,label:" FB-"+finalString[1] });
                                                          workspaceAPI.setTabHighlighted({ tabId: focusedTabId,highlighted: true,options: {pulse: false,state: "success"}});
                                                      }else if(finalString[0]=="TW"){                                                          
                                                          workspaceAPI.setTabIcon({tabId: focusedTabId, icon: "utility:like", iconAlt: "Twitter"});
                                                          //   sforce.console.setTabStyle('background:red;', null, null);
                                                          workspaceAPI.setTabLabel({tabId: focusedTabId,label:" TW-"+finalString[1] });
                                                          workspaceAPI.setTabHighlighted({ tabId: focusedTabId,highlighted: true,options: {pulse: false,state: "error"}});//Modified by Vaidehi
                                                      }else if(finalString[0]=="IN"){
                                                          //       workspaceAPI.setTabStyle('background:red;', null, null);
                                                          workspaceAPI.setTabIcon({tabId: focusedTabId, icon: "utility:like", iconAlt: "Instagram"});
                                                          workspaceAPI.setTabLabel({tabId: focusedTabId,label:" IN-"+finalString[1] });
                                                          workspaceAPI.setTabHighlighted({ tabId: focusedTabId,highlighted: true,options: {pulse: false,state: "warning"}});// Modified by Vaidehi
                                                      }else if(finalString[0]=="chat"){
                                                          workspaceAPI.setTabIcon({tabId: focusedTabId, icon: "utility:"+ result, iconAlt: "Chat"});   
                                                          workspaceAPI.setTabHighlighted({ tabId: focusedTabId,highlighted: true,options: {pulse: false,state: "success"}});//Added By Vaidehi  
                                                      }
                                                      //  $A.get('e.force:refreshView').fire();
                                                  }
                                              }
                                             ));
            $A.enqueueAction(action);       
            
        })
        
    }
})