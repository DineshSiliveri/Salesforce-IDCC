({
	//Init method
    doInit : function(component, event, helper){
        var action = component.get("c.getListOfKnowledge");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                component.set('v.knowLst',response.getReturnValue());
            }
            else{
                console.log('Error in IDC_knowledegArticleList : doInit');
            }
        });
        $A.enqueueAction(action);
    },
    handleArticle :function(component, event, helper){
        var knowId =  event.currentTarget.dataset.id;
        var action = component.get("c.getKnowledgeDetail");
        action.setParams({recordId : knowId});
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                component.set('v.article',response.getReturnValue());
                component.set('v.OpenLst',false);
        		component.set('v.OpenDetails',true);
            }
            else{
                console.log('Error in IDC_knowledegArticleList : doInit');
            }
        });
        $A.enqueueAction(action);
    }
})