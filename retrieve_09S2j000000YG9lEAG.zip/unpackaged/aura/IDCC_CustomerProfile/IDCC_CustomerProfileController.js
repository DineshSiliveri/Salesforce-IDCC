({
	showCustDetails : function(component, event, helper) {
		//helper.showCustDetails(component, event);
		var recordId = component.get("v.recordId");
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleForm");	
        //alert(staticLabel);
        var tmp =staticLabel+'apiName=Query_Customer_Profile&resObjName=Query_Customer_Profile_Res&recordId='+recordId;
        //'https://indosat--indosatdev--c.cs75.visual.force.com/apex/IDCC_ConsoleForm?apiName=Query_Customer_Profile&resObjName=Query_Customer_Profile_Res&recordId=5000w000001UmaFAAS';
        //alert(tmp);
        component.set("v.URL",tmp);
        helper.scrolltoTop();
      
	},
    familyNFriends : function(cmp, event, helper) {
    	var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleForm");
		var recordId = cmp.get("v.recordId");         
        var tmp = staticLabel+'resObjName=Query_Family_and_Friends_Res&apiName=Query_Family_and_Friends&recordId='+recordId;
        cmp.set("v.URL",tmp);          
	},
    orderHistory : function(cmp, event, helper) {
    	var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
		var recordId = cmp.get("v.recordId");         
        var tmp = staticLabel+'resObjName=Query_Order_History_Res&apiName=Query_Order_History&recordId='+recordId;
        cmp.set("v.URL",tmp);          
	}
})