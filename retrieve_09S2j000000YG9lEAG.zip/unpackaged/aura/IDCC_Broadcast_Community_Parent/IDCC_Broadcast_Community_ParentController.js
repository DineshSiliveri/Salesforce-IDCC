({
	doInit : function(component, event, helper) {
		var action = component.get("c.Communityuser");
        
        action.setCallback(this, function(response) {
            component.set('v.CommunityUser', response.getReturnValue());  
            //component.set('v.CommunityUser', true);  
            
        });
        $A.enqueueAction(action);  
	}
})