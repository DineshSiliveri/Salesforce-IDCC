({
    
    doInit : function(component, event, helper) {
      
        var empApi = component.find("empApi");

        // Get the channel from the input box.
        var channel = '/data/';
          
            var currentRecordId = component.get('v.recordId');
        	var sObjectName = component.get("v.sObjectName"); 
        	var field1 = component.get("v.field1");  
         	var field2 = component.get("v.field2");
        	var value1 = component.get("v.value1");  
         	var value2 = component.get("v.value2");
            var displayField = component.get("v.displayField"); 
         	var message1 = component.get("v.message"); 
     		var color = component.get("v.color"); 
            var duration = component.get("v.duration"); 
            var duration1 = duration*1000;
        
            var colorType;
        if(color=="Red"){
                     colorType = "error";
                }else  if(color=="Green"){
                     colorType = "success";
                }else  if(color=="Orange"){
                     colorType = "warning";
                }else{
                 colorType = "other";   
                }
       
        if (sObjectName.endsWith('__c')) {
            // Custom object
            channel = channel + sObjectName.substring('0', sObjectName.length-3) + '__ChangeEvent';
        }
        else {
            // Standard object
            channel = channel + sObjectName + 'ChangeEvent';
        }
        console.log('channel'+channel );
        
        var replayId = '-1';
        
        // Callback function to be passed in the subscribe call.
        // After an event is received, this callback prints the event
        // payload to the console.
        var callback = function (message) {
            console.log("Received [" + message.channel +
                " : " + message.data.event.replayId + "] payload=" +
                JSON.stringify(message.data.payload));
                       
            // ChangeEventHeader fields
            var entityName = message.data.payload.ChangeEventHeader.entityName;
            var modifiedRecords = message.data.payload.ChangeEventHeader.recordIds;
            var changeType = message.data.payload.ChangeEventHeader.changeType;
            
                 
        /*    
            alert('entityName'+entityName);
            alert('modifiedRecords'+modifiedRecords);
            alert('changeType'+changeType);
														*/
            // SObject Modified fields
            var employeeRecordID = message.data.payload.ChangeEventHeader.recordIds[0];
            //Added by SFDC
            console.log('employeeRecordID ==>'+employeeRecordID);
           // console.log('Logs--->> CaseId'+CaseId);
           
            if(field2==null && message.data.payload[field1]!=undefined){
     		 
                var flag;
                if(value1 == "true" || value1 == "false"){
                   var  val1 = message.data.payload[field1];
                    flag = val1.toString();
                }else{     
                     flag = message.data.payload[field1];
                }
            if (modifiedRecords.includes(currentRecordId) &&   flag == value1) {
               
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    
                     "mode": "dismissible",
                     "title": entityName+" !!!",
                     "message": message1,
                     "type": colorType,
                    "duration": duration1,  
                    
                });
                
                toastEvent.fire();
            }
            } if(field2!=null && message.data.payload[field1]!=undefined && message.data.payload[field2]!=undefined){
                
                var flag1;
                if(value1 == "true" || value1 == "false"){
                   var  val1 = message.data.payload[field1];
                    flag1 = val1.toString();
                }else{     
                     flag1 = message.data.payload[field1];
                }
                var flag2;
                if(value2 == "true" || value2 == "false"){
                   var  val2 = message.data.payload[field2];
                    flag2 = val2.toString();
                }else{     
                     flag2 = message.data.payload[field2];
                }
            if (modifiedRecords.includes(currentRecordId)  && flag1 == value1 && flag2 == value2) {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    
                     "mode": "dismissible",
                     "title": entityName+" !!!",
                     "message": message1,
                     "type": colorType,
                    "duration": duration1,  
                    
                });
                toastEvent.fire();
            }
            }
        }.bind(this);

       /*
        * SFDC LOG - Previous
        // Error handler function that prints the error to the console.
        var errorHandler = function (message) {
            console.log("Received error ", message);


        // Register error listener and pass in the error handler function.
        empApi.onError(errorHandler);

        // Subscribe to the channel and save the returned subscription object.
        empApi.subscribe(channel, replayId, callback).then(function(value) {
            console.log("Subscribed to channel " + channel);
        });
    }*/
        
        //SFDC LOG#01 - Removed subscription from error handler 
       // Error handler function that prints the error to the console.
        var errorHandler = function (message) {
            console.log("Received error ", message);
        } ;
        
        
        // Register error listener and pass in the error handler function.
        empApi.onError(errorHandler);
        
        // Subscribe to the channel and save the returned subscription object.
        empApi.subscribe(channel, replayId, callback).then(function(value) {
            console.log("Subscribed to channel " + channel);
        });
        
    }
})