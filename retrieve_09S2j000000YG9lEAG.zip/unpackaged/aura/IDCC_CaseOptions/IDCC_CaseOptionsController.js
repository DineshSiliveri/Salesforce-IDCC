({
    showCaseDetails: function(component, event, helper) {
        helper.showCaseDetails(component, event);
    },
    
    
    init : function(component, event, helper) {
        // helper.retrievePageLayout(component, event);
        helper.showCaseDetails(component, event);
    },
    
    //Calling a History component clicking on the "History" button
    gotoHistory:function(component,event,helper){
        helper.gotoHistory(component,event);
        
    },
    showFeed: function(component, event, helper) {
        helper.showFeedDetails(component, event);
    },
    
    showCustPro: function(component, event, helper) {
        helper.showCustPro(component, event);
    },
    
     showSocialPersona: function(component, event, helper) {
        helper.showSocialPersona(component, event, helper);
    },
    showAssets: function(component, event, helper) {
        helper.showAssets(component, event, helper);
    },
    serviceRequest: function(component, event, helper) {
        helper.serviceRequest(component, event, helper);
    },
    paymentHistory: function(component, event, helper) {
        helper.paymentHistory(component, event, helper);
    },
    invoiceHistory: function(component, event, helper) {
        helper.invoiceHistory(component, event, helper);
    },
     scrollLeft: function(component, event, helper) {
        $(document).ready(function() { 
               
            
            $("#icon_1").show();  
            $("#icon_2").show();  
            $("#icon_3").show();  
            $("#icon_4").show();  
            $("#icon_5").show();  
            $("#icon_6").show();  
            $("#icon_7").show();  
            $("#icon_8").show();  
            $("#icon_9").show();
            
            component.set("v.prev", "prev");
        	component.set("v.next", "next_y");
            
        }); 
    },
    scrollRight: function(component, event, helper) {
           $(document).ready(function() { 
            
            $("#icon_1").hide();  
            $("#icon_2").hide();  
            $("#icon_3").hide();  
            $("#icon_4").hide();  
            $("#icon_5").hide();  
            $("#icon_6").hide();  
            $("#icon_7").hide();  
            $("#icon_8").hide();  
            $("#icon_9").hide();  
            
        component.set("v.prev", "prev_y");
        component.set("v.next", "next");
               
           });
    },
                             
    
})