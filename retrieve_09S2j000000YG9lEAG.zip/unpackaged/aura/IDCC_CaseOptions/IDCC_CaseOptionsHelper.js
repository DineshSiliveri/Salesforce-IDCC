({
    showCaseDetails : function(component, event) {
        component.set("v.checkedCaseDetails", true);  
        component.set("v.showCaseHistory", false);
        component.set("v.showFeed", false);
        component.set("v.showCustDetails", false);
        component.set("v.showSocialPersona", false);
        component.set("v.icon1", "icon_y");
        component.set("v.icon2", "icon2");
        component.set("v.icon3", "icon3");
        component.set("v.icon4", "icon4");
        component.set("v.icon5", "icon5");
        component.set("v.icon6", "icon6");
        component.set("v.icon7", "icon7");
        component.set("v.icon8", "icon8");
        component.set("v.icon9", "icon9");
        
        component.set('v.caseColumns', [
            { label: 'Case', fieldName: 'LinkName', type: 'url', typeAttributes: {label: { fieldName: 'CaseNumber' }, target: '_top'} },
            { label: 'Case Origin', fieldName: 'Origin', type:"text"},
            { label: 'Status', fieldName: 'Status', type:"text"},
            { label: 'Subject', fieldName: 'Subject', type:"text"},
            { label: 'Owner', fieldName: 'Owner', type:"text"},
            { label: 'Priority', fieldName: 'Priority', type: 'text' }
        ])
        var actionIcon = component.get("c.getIconName");        
        var action = component.get("c.setViewStat"); 
        var actionLayout = component.get("c.casePageLayout"); 
        var caseId = component.get("v.recordId");       
        
        action.setParams({
            "caseId":caseId
        });
        actionLayout.setParams({
            "caseId":caseId
        });
        actionIcon.setParams({
            "sobjectApiName":"Case"
        });
        
        // Set up the callback
        actionIcon.setCallback(this, function(response) {
            component.set('v.iconName', response.getReturnValue());  
            
        });      
        action.setCallback(this, function(response) {
            component.set('v.caseData', response.getReturnValue());  
            
        });
          actionLayout.setCallback(this, function(response) {
            component.set('v.LayoutName', 'Case-'+response.getReturnValue());  
            //alert(component.get("v.LayoutName"));
              //alert(response.getReturnValue());
        });
        // Queue this action to send to the server
        $A.enqueueAction(action);
        $A.enqueueAction(actionIcon);
        $A.enqueueAction(actionLayout);
        
        
        //var elements = document.getElementsByClassName("myTest");
        //elements[0].style.display = 'none';
        
        
    },
    
    retrievePageLayout : function(component, helper) {
        var action = component.get("c.getPageLayoutMetadata");
        var pageLayoutName = component.get("v.PageLayoutName");        
        console.log("pageLayoutName: " + pageLayoutName);        
        var actionParams = {
            "pageLayoutName" : pageLayoutName
        };
        
        action.setParams(actionParams);
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var pageLayout = response.getReturnValue();
                console.log("pageLayout: " + pageLayout.toString());                
                component.set("v.PageLayout", pageLayout);
            }
        });        
        $A.enqueueAction(action);
    },
    
    //Calling a next component clicking on the "Next" button
    gotoHistory:function(component,event){
        component.set("v.checkedCaseDetails", false);
        component.set("v.showCaseHistory", true);
        component.set("v.showFeed", false);
        component.set("v.showSocialPersona", false);
        component.set("v.showCustDetails", false);
        component.set("v.icon1", "icon1");
        component.set("v.icon2", "icon2");
        component.set("v.icon3", "icon3");
        component.set("v.icon4", "icon4");
        component.set("v.icon5", "icon5");
        component.set("v.icon6", "icon_y");
        component.set("v.icon7", "icon7");
        component.set("v.icon8", "icon8");
        component.set("v.icon9", "icon9");
    },
    
    
    showFeedDetails : function(component, event, helper) {
        // var divId = component.find('modalDiv');
        //  $A.util.toggleClass(divId, 'slds-hide');
        component.set("v.checkedCaseDetails", false);
        component.set("v.showCaseHistory", false);
        component.set("v.showFeed", true);
        component.set("v.showSocialPersona", false);
        component.set("v.showCustDetails", false);
        component.set("v.icon1", "icon1");
        component.set("v.icon2", "icon2");
        component.set("v.icon3", "icon_y");
        component.set("v.icon4", "icon4");
        component.set("v.icon5", "icon5");
        component.set("v.icon6", "icon6");
        component.set("v.icon7", "icon7");
        component.set("v.icon8", "icon8");
        component.set("v.icon9", "icon9"); 
    },
    
    showCustPro : function (component, event) {
        component.set("v.checkedCaseDetails", false);
        component.set("v.showCaseHistory", false);
        component.set("v.showFeed", false);
        component.set("v.showSocialPersona", false);  
         component.set("v.showCustDetails", true);
        component.set("v.icon1", "icon1");
        component.set("v.icon2", "icon_y");
        component.set("v.icon3", "icon3");
        component.set("v.icon4", "icon4");
        component.set("v.icon5", "icon5");
        component.set("v.icon6", "icon6");
        component.set("v.icon7", "icon7");
        component.set("v.icon8", "icon8");
        component.set("v.icon9", "icon9");
    },
    
    showSocialPersona : function(component, event, helper) {
        
        component.set("v.checkedCaseDetails", false);
        component.set("v.showCaseHistory", false);
        component.set("v.showFeed", false);
        component.set("v.showSocialPersona", true);
        component.set("v.showCustDetails", false);
        component.set("v.icon1", "icon1");
        component.set("v.icon2", "icon2");
        component.set("v.icon3", "icon3");
        component.set("v.icon4", "icon_y");
        component.set("v.icon5", "icon5");
        component.set("v.icon6", "icon6");
        component.set("v.icon7", "icon7");
        component.set("v.icon8", "icon8");
        component.set("v.icon9", "icon9");
    },
    showAssets : function(component, event, helper) {
        
        component.set("v.icon1", "icon1");
        component.set("v.icon2", "icon2");
        component.set("v.icon3", "icon3");
        component.set("v.icon4", "icon4");
        component.set("v.icon5", "icon_y");
        component.set("v.icon6", "icon6");
        component.set("v.icon7", "icon7");
        component.set("v.icon8", "icon8");
        component.set("v.icon9", "icon9");
    },
      serviceRequest : function(component, event, helper) {
        
        component.set("v.icon1", "icon1");
        component.set("v.icon2", "icon2");
        component.set("v.icon3", "icon3");
        component.set("v.icon4", "icon4");
        component.set("v.icon5", "icon5");
        component.set("v.icon6", "icon6");
        component.set("v.icon7", "icon_y");
        component.set("v.icon8", "icon8");
        component.set("v.icon9", "icon9");
    }, 
    paymentHistory : function(component, event, helper) {
        
        component.set("v.icon1", "icon1");
        component.set("v.icon2", "icon2");
        component.set("v.icon3", "icon3");
        component.set("v.icon4", "icon4");
        component.set("v.icon5", "icon5");
        component.set("v.icon6", "icon6");
        component.set("v.icon7", "icon7");
        component.set("v.icon8", "icon_y");
        component.set("v.icon9", "icon9");
    },
     invoiceHistory : function(component, event, helper) {
        
        component.set("v.icon1", "icon1");
        component.set("v.icon2", "icon2");
        component.set("v.icon3", "icon3");
        component.set("v.icon4", "icon4");
        component.set("v.icon5", "icon5");
        component.set("v.icon6", "icon6");
        component.set("v.icon7", "icon7");
        component.set("v.icon8", "icon8");
        component.set("v.icon9", "icon_y");
    },
     
})