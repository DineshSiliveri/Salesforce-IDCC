({
	personalLink : function(component, event, helper) {        
		helper.personalLink(component, event);
	},
    
    businessLink : function(component, event, helper) {        
		helper.businessLink(component, event);
	},
    
    investorRelLink : function(component, event, helper) {        
		helper.investorRelLink(component, event);
	},
    
    homeLink : function(component, event, helper) {        
		helper.homeLink(component, event);
	},
    openLogin : function(component, event, helper) {        
		helper.loginLink(component, event);
	},
})