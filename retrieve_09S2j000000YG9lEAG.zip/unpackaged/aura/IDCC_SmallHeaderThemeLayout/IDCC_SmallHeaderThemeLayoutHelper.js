({
    //Redirecting to Facebook link
    personalLink : function(component, event) {  
        window.open($A.get("$Label.c.IDCC_CommunityPersonalLink"),'_top');       
    },
    
    businessLink : function(component, event) {  
        window.open($A.get("$Label.c.IDCC_CommunityBusinessLink"),'_top');       
    },
    
    investorRelLink : function(component, event) {  
        window.open($A.get("$Label.c.IDCC_CommunityInvestorRelationLink"),'_top');       
    },
    loginLink : function(component, event) {  
       window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/login/', '_self');     
    },
    homeLink : function(component, event) { 
        //var index = event.target.getAttribute('data-index');
        component.find("navService").navigate(    {
            type: "comm__namedPage",
            attributes: {
                pageName: "home"
            }
        }    , true);
    },       
    
})