({
    init: function (cmp, event, helper) {
        helper.fetchData(cmp, event, helper);
        helper.initColumnsWithActions(cmp, event, helper)
        //helper.fetchCaseData(cmp, event, helper);
    },
    
    handleColumnsChange: function (cmp, event, helper) {
        helper.initColumnsWithActions(cmp, event, helper)
    },
    
    handleRowAction: function (cmp, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        var onRowActionHandler = cmp.get('v.onRowActionHandler');
        
        if(onRowActionHandler){
            $A.enqueueAction(onRowActionHandler)                       
        }else{            
            switch (action.name) {
                case 'edit':
                    helper.editRecord(cmp, row)
                    break;
                case 'delete':
                    helper.removeRecord(cmp, row)
                    break;
            }
        }
    },
    
    handleGotoRelatedList : function (cmp, event, helper) {
        var relatedListEvent = $A.get("e.force:navigateToRelatedList");
        relatedListEvent.setParams({
            "relatedListId": cmp.get("v.parentRelationshipApiName"),
            "parentRecordId": cmp.get("v.recordId")
        });
        relatedListEvent.fire();
    },
    
    handleCreateRecord : function (cmp, event, helper) {
        var createRecordEvent = $A.get("e.force:createRecord");
        createRecordEvent.setParams({
            "entityApiName": cmp.get("v.sobjectApiName"),
            "defaultFieldValues": {
                [cmp.get("v.relatedFieldApiName")] : cmp.get("v.recordId")
            }
        });
        createRecordEvent.fire();
    },   
    
    handleToastEvent  : function (cmp, event, helper) {
        var eventType = event.getParam('type');
        var eventMessage= event.getParam('message');
        if(eventType == 'SUCCESS' && eventMessage.includes(cmp.get('v.sobjectLabel'))){
            helper.fetchData(cmp, event, helper);
            helper.fetchCaseData(cmp, event, helper)
            event.stopPropagation();            
        }        
    },  
    navigateToRecord : function(component, event, helper) {  
        var idx= event.currentTarget.id;
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": idx,
            "slideDevName": "detail"            
        });
        navEvt.fire();         
    },
    openCodePage : function(cmp, event, helper) { 
        var ctarget = event.currentTarget;
        console.log('**==selected item-----'+ctarget);
        var check = ctarget.dataset.value;
        console.log('Check Id**'+check); //Selected Case Id
        var id_str = event.currentTarget.dataset.id;
        console.log('Check Id**'+id_str);
        var records = cmp.get('v.records');
        //Added by Komal
        /*var CaseIDToBooleanMap1 = cmp.get('v.CaseIDToBooleanMap');
        var tempMap =[];
       for(var index  in CaseIDToBooleanMap1){
           if(CaseIDToBooleanMap1[index].key == id_str){
               alert('in of..');
           	  	tempMap.push({value:'Yes', key:id_str}); 
                helper.fetchIssueCode(cmp, event, id_str) ;
           }
           else{
           	tempMap.push({value:'No', key:CaseIDToBooleanMap1[index].key});     
           }
        }
         cmp.set('v.CaseIDToBooleanMap', tempMap);
         console.log('after***'+JSON.stringify(cmp.get('v.CaseIDToBooleanMap')));*/
        for (var i = check ; i < records.length; i++) {
            console.log('indexVar**'+i);
            console.log('record Id**'+records[i].Id);
            if(records[i].Id == id_str && cmp.get("v.caseActivity") == false){
                cmp.set("v.caseActivity",true);
            }
            helper.fetchIssueCode(cmp, event, id_str) ;
            break;
        } 
        
    },
    closeModel : function(component, event, helper) {
      component.set("v.isOpen", false);
    },
    OpenModal: function(component, event, helper) {
        var ctarget = event.currentTarget;
        console.log('**==selected item-----'+ctarget);
        var check = ctarget.dataset.value;
        console.log('Check Id**'+check); //Selected Case Id
        var id_str = event.currentTarget.dataset.id;
        console.log('Check Id**'+id_str);
        var records = component.get('v.records');
     
        for (var i = check ; i < records.length; i++) {
            console.log('indexVar**'+i);
            console.log('record Id**'+records[i].Id);
            if(records[i].Id == id_str && component.get("v.caseActivity") == false){
                component.set("v.caseActivity",true);
            }
            helper.fetchIssueCode(component, event, id_str) ;
            break;
        }
      component.set("v.isOpen", true);
    }
    
    
})