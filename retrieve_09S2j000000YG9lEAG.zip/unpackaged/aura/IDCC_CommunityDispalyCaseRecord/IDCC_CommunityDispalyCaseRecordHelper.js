({    
    getJsonFromUrl : function () {
        console.log('in helper getJsonFromUrl')
        var query = location.search.substr(1);
        
        var result = {};
        query.split("&").forEach(function(part) {
            var item = part.split("=");
            result[item[0]] = decodeURIComponent(item[1]);
        });
        console.log('result  ',result)
        return result;
    },
     /*previewFile :function(){ 
        console.log('in previewFile');
        var rec_id = event.currentTarget.id;  
        console.log('rec_id ',rec_id);
        $A.get('e.lightning:openFiles').fire({ 
            recordIds: [rec_id]
        });  
    }, */
    getuploadedFiles:function(component){
        console.log('getuploadedFiles ');
        var action = component.get("c.getFiles");  
        action.setParams({  
            "recordId":component.get("v.testRecordId")  
        });      
        action.setCallback(this,function(response){  
            var state = response.getState();  
            console.log('state ',state);
            if(state=='SUCCESS'){  
                var result = response.getReturnValue();   
                console.log('result ',result);
                component.set("v.files",result);  
            }  
        });          
        $A.enqueueAction(action);  
    }
})