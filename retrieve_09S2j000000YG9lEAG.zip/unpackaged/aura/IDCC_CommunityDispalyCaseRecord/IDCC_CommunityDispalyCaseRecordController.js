({
    doInit : function(component, event, helper) {
        
        window.setTimeout(
            $A.getCallback(function() {
                var pid = helper.getJsonFromUrl();
                console.log('in doInit', pid);
                component.set("v.testRecordId", pid.id);
                console.log(pid);
                helper.getuploadedFiles(component);
            }), 1000
        );
        
    },
    
    handleUploadFinished: function (cmp, event) {
        console.log('in handleUploadFinished');
        //Get the list of uploaded files
        var uploadedFiles = event.getParam("files");
        console.log('uploadedFiles '+uploadedFiles.id);
        cmp.set("v.UploadedFiles",uploadedFiles);
        
        
        //Show success message – with no of files uploaded
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "type" : "success",
            "message": uploadedFiles.length+" files has been uploaded successfully!"
        });
        toastEvent.fire();
         
        $A.get('e.force:refreshView').fire();
        
        helper.getuploadedFiles(component);         
        window.location.reload();
        //Close the action panel
        var dismissActionPanel = $A.get("e.force:closeQuickAction");
        dismissActionPanel.fire();
        
    }
})