({
	handleDeviceSimulator : function(component, event, helper) {
    	  window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/devicesimulatorpage/', '_self');  
    },
    handleDiscussion :function (component, event) {
    	window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/discussionforumspage/', '_self');
    },
    handleNetworkLocator : function (component, event) {
    	//window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/login/', '_self');
       	  window.open($A.get("$Label.c.IDCC_Comm_OrderSIM_URL"),'_self');		
    },
    handleSelfHelpPortal : function (component, event) {
    	window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/login/', '_self');
    }
})