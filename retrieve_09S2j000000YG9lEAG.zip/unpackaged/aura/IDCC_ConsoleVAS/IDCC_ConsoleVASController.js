({
	showVASDetails : function(component, event, helper) {
		var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        //var staticLabel = 'https://indosat--indosatdev--c.cs75.visual.force.com/apex/IDCC_ConsoleTablePrem?';
		var recordId = component.get("v.recordId"); 
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleVASUnReg?apiName=QUERY_VAS_SDP_Subscription_List&resObjName=Query_VAS_SDP_Subscription_List_Res&recordId='+recordId; 
        //var tmp =  staticLabel+'apiName=QUERY_VAS_SDP_Subscription_List&resObjName=Query_VAS_SDP_Subscription_List_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
	},
    Historical : function(component, event, helper) {
		var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        //var staticLabel = 'https://indosat--indosatdev--c.cs75.visual.force.com/apex/IDCC_ConsoleTablePrem?';
		var recordId = component.get("v.recordId");  
        var tmp =  staticLabel+'apiName=Query_VAS_Transaction_Historical&resObjName=Query_VAS_Transaction_Historical_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
	},
    VASTransHisotry : function(cmp, event, helper) {
    	var staticLabel = $A.get("$Label.c.URL_IDCC_VASHistoryConsoleTable");
		var recordId = cmp.get("v.recordId");         
        var tmp = staticLabel+'resObjName=Query_VAS_Transaction_History_Res&apiName=Query_VAS_Transaction_History&recordId='+recordId;
        cmp.set("v.URL",tmp);          
	}, 
    VLRStatus : function(cmp, event, helper) {
    	var staticLabel = $A.get("$Label.c.URL_IDCC_VASHistoryConsoleTable");
		var recordId = cmp.get("v.recordId");  
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleVLRStatus?resObjName=Query_VLR_Res&apiName=Query_VLR&recordId='+recordId;
        //var tmp = staticLabel+'resObjName=Query_VLR_Res&apiName=Query_VLR&recordId='+recordId;
        cmp.set("v.URL",tmp);          
	},
    VASiRing : function(cmp, event, helper) {
    	var staticLabel = $A.get("$Label.c.URL_IDCC_VASHistoryConsoleTable");
		var recordId = cmp.get("v.recordId");  
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsolePackageInfoTable?resObjName=Query_VAS_iRing_Subscription_List_Res&apiName=Query_VAS_iRing_Subscription_List&recordId='+recordId;
        //var tmp = staticLabel+'resObjName=Query_VLR_Res&apiName=Query_VLR&recordId='+recordId;
        cmp.set("v.URL",tmp);          
	},
    VASContUsage : function(cmp, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
		var recordId = cmp.get("v.recordId");         
        var tmp = staticLabel+'resObjName=Query_VAS_Content_Usage_Res&apiName=Query_VAS_Content_Usage&recordId='+recordId;
        cmp.set("v.URL",tmp); 
        
    	/*var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
		var recordId = cmp.get("v.recordId");  
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'resObjName=Query_VAS_Content_Usage_Res&apiName=Query_VAS_Content_Usage&recordId='+recordId;
        //var tmp = staticLabel+'resObjName=Query_VLR_Res&apiName=Query_VLR&recordId='+recordId;
        cmp.set("v.URL",tmp); */         
	},
    hideSpinner: function (component, event, helper) {         
        var spinner = component.find('spinner');
        $A.util.removeClass(spinner, 'loadSpinner');
        $A.util.addClass(spinner, 'newLoadSpinner');
    },
})