({
    showArticles : function(component, event, helper) { 
        helper.showArticles(component, event);
    },
    openUrl : function(component, event, helper) {
        helper.navigateToArticlePage(component, event);
    }
})