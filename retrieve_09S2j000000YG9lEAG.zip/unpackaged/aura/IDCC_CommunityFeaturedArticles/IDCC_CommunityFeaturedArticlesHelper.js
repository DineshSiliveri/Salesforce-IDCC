({
    showArticles : function(component, event) {
        var action1 = component.get("c.getDataCategoryFeaturedArticles");
        var labelNetworkValue = $A.get("$Label.c.IDCC_Comm_Tips");
        action1.setParams({"dataCategory": labelNetworkValue}); 
        action1.setCallback(this, function(response) {
            var state = response.getState();
            var errors = response.getError();
            if(component.isValid() && state == "SUCCESS"){             
                var records = response.getReturnValue();
                var knowArtLst = [];
                for(var key in records){    
                    knowArtLst.push({value:records[key], key:key});  
                }
                component.set("v.knowledgeNetwork", knowArtLst);
            }
            else {
                console.log("Unknown error"+errors[0].message);
            }
        });  
        
        var action2 = component.get("c.getDataCategoryFeaturedArticles");
        var labelBillingValue = $A.get("$Label.c.IDCC_Comm_LWC_PFAQ");
        action2.setParams({"dataCategory": labelBillingValue}); 
        action2.setCallback(this, function(response) {
            var state = response.getState();
            var errors = response.getError();
            if(component.isValid() && state == "SUCCESS"){             
                var records = response.getReturnValue();
                var knowArtLst1 = [];
                for(var key in records){    
                    knowArtLst1.push({value:records[key], key:key});  
                }
                component.set("v.knowledgeBilling", knowArtLst1);
            }
            else {
                console.log("Unknown error"+errors[0].message);
            }
        });       
        
        var action3 = component.get("c.getDataCategoryFeaturedArticles");
        var labelComplaintValue = $A.get("$Label.c.IDCC_Comm_H_Others");
        action3.setParams({"dataCategory": labelComplaintValue}); 
        action3.setCallback(this, function(response) {
            var state = response.getState();
            var errors = response.getError();
            if(component.isValid() && state == "SUCCESS"){             
                var records = response.getReturnValue();
                var knowArtLst2 = [];
                for(var key in records){    
                    knowArtLst2.push({value:records[key], key:key});  
                }
                component.set("v.knowledgeComplaint", knowArtLst2);
            }
            else {
                console.log("Unknown error"+errors[0].message);
            }
        });       
        $A.enqueueAction(action1);
        $A.enqueueAction(action2);
        $A.enqueueAction(action3);		
    },
    //This will navigate to standard Article Detail page
    navigateToArticlePage: function(component, event) {
        var urlName = event.target.getAttribute('data-index');
        component.find("navService").navigate({
            type: "standard__knowledgeArticlePage",
            attributes: {
                "urlName": urlName
            },             
        }, true);        
    }
   
})