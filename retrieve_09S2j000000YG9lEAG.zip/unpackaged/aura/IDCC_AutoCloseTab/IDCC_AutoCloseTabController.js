({	
    
    doInit : function(component, event, helper) {
		 helper.chkprofileAccess(component,event,helper);
         //helper.closeIE(component, event, helper);        
    }
	
})