({
    chkprofileAccess : function(component, event, helper){        
        var action = component.get("c.checkProfileAccess");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(component.isValid() && state == "SUCCESS"){
                var result = response.getReturnValue();
                if(result){
                    this.closetab(component, event, helper);                    
                }
            }else {
                console.log("Unknown error in IDCC_AutoCloseTab--chkprofileAccess");
            }
        });        
        $A.enqueueAction(action);	
    },
    closetab : function(component, event, helper){
        var caseStatus = component.get("v.caseRecord").Status;
        var statusFlag = component.get("v.caseRecord").IDCC_Status_Flag__c; 
        var eventParams = event.getParams();
        console.log("caseStatus: " + caseStatus);
        console.log("eventParams: " + eventParams.changeType);
        if(eventParams.changeType === "LOADED" && (caseStatus =='Cancel' || caseStatus =='Closed') && !statusFlag) {
            var caseId = component.get("v.recordId");
            this.changeStatusflag(component, event, helper,caseId);
            var changedFields = eventParams.changedFields;
            //alert('Fields that are changed: ' + JSON.stringify(changedFields));
            var workspaceAPI = component.find("workspace");
            workspaceAPI.getFocusedTabInfo().then(function(response) {
                var focusedTabId = response.tabId;
                // alert('ID focusedTabId '+focusedTabId);
                workspaceAPI.closeTab({tabId: focusedTabId});
                //alert('after close');
            })
            .catch(function(error) {
                console.log("Unknown error in IDCC_AutoCloseTab--closetab");
            });
        }
    },
    changeStatusflag:function(component, event, helper, caseId){
    	var action = component.get("c.updateStatusFlag");        
        action.setParams({
            "caseId": caseId
        });
        action.setCallback(component,function(response) {
            var state = response.getReturnValue(); 
        });
        $A.enqueueAction(action);    
    },
/*    closeIE : function(component, event, helper){
        var IEUpdated = component.get("v.caseRecord").IDCC_IE_Updated__c;
        //alert(IEUpdated);
        var eventParams = event.getParams();
         var caseId = component.get("v.recordId");
        //alert(eventParams.changeType);
        if(eventParams.changeType === "CHANGED" && IEUpdated == true) {
            this.revertIEField(component, event, helper,caseId);
            var changedFields = eventParams.changedFields;
            console.log('Fields that are changed: ' + JSON.stringify(changedFields));
            var workspaceAPI = component.find("workspace");
            workspaceAPI.getFocusedTabInfo().then(function(response) {
                var focusedTabId = response.tabId;
                // alert('ID focusedTabId '+focusedTabId);
                workspaceAPI.closeTab({tabId: focusedTabId});
                //alert('after close');
            })
            .catch(function(error) {
                console.log("Unknown error in IDCC_AutoCloseTab--closetab");
            });
        }
        
    },
    
    revertIEField : function(component, event, helper, caseId){
        //alert('Done');
        var action = component.get("c.revertIEField");        
        action.setParams({
            "caseId": caseId
        });
        action.setCallback(component,function(response) {
            var state = response.getReturnValue(); 
        });
        $A.enqueueAction(action);
    }*/
    
   
    
    
    
})