({
	 scrolltoTop : function() {
		 $('body, html').animate({
            scrollTop: $('[id^="topDiv"]').offset().top - 40
        }, 1500);
	} 
})