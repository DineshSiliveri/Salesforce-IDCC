({
	  prepaidRegHistory : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Prepaid_Registration_History&resObjName=Query_Prepaid_Registration_History_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},
    auditTrail : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Audit_Trail&resObjName=Query_Audit_Trail_Res&Type123=auditTrail&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},
    auditTrailAva : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Audit_Trail&resObjName=Query_Audit_Trail_Res&Type123=auditAvatar&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},
})