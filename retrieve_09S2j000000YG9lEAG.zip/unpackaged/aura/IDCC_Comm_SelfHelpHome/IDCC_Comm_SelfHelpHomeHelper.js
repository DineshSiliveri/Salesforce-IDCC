({
	handleCreateCase : function(component, event, helper) {
        var allValid = component.find('fieldId').reduce(function (validSoFar, inputCmp) {
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && !inputCmp.get('v.validity').valueMissing;
        }, true);
        if(allValid) {
            var loogedInUser = component.get('v.loggedInUser');
            var action = component.get("c.createNewCase");
            action.setParams({
                "accountId" : loogedInUser.Contact.AccountId,
                "newCase": component.get("v.newCase")
            }); 
            action.setCallback(this, function(response) {
                var state = response.getState();
                var result = response.getReturnValue();
                if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                    component.set("v.isOpenModal", false);
                    $A.get('e.force:refreshView').fire();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "type": "success",
                        "message": "Case Created Successfully"
                    });
                    toastEvent.fire();
                }
                else{
                    console.log('Error in IDCC_Comm_MyCases : handleCreateCase');
                }
            });
            $A.enqueueAction(action); 	    
        }
    },
     getCasesDetails : function(component, event, helper) {
        var loogedInUser = component.get('v.loggedInUser');
        var action = component.get("c.getCaseDetails");
        action.setParams({"accountId": loogedInUser.Contact.AccountId}); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                component.set('v.cases',response.getReturnValue());
                component.set('v.caseCount', response.getReturnValue().length);
                //this.getCountOfStatus(component, event);
            }
            else{
                console.log('Error in IDCC_Comm_MyCases : getCasesDetails');
            }
        });
        $A.enqueueAction(action); 	
    },
})