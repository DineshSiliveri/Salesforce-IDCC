({
	doInit : function(component, event, helper) {
        const min = window.matchMedia( "(min-width: 319px)" );
        const max = window.matchMedia( "(max-width: 430px)" );
        if (min.matches && max.matches ) {
               component.set('v.remainingQuota',true);
               component.set('v.myPackage',true);
        } 
        const tabMin = window.matchMedia( "(min-width: 768px)" );
        const tabMax = window.matchMedia( "(max-width: 1023px)" );
        if(tabMin.matches && tabMax.matches){
            component.set('v.myPackage',true);
        }
        var action = component.get("c.getUserDetails");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                component.set('v.loggedInUser',response.getReturnValue());
                component.set('v.accountId',component.get('v.loggedInUser.Contact.AccountId'));
              //  component.set('v.msisdn',component.get('v.loggedInUser.Contact.Account.IDCC_MSISDN_No__c'));
                console.log('account id'+component.get('v.loggedInUser.Contact.AccountId'));
                console.log('msisdn id ==>'+component.get('v.loggedInUser.Contact.Account.IDCC_MSISDN_No__c'));
               // component.set('v.billingNo',component.get('v.loggedInUser.Contact.Account.IDCC_Billing_Account_Number__c'));
                //console.log('Error in account id'+component.get('v.loggedInUser.Contact.Account.IDCC_Billing_Account_Number__c'));
               
                helper.getCasesDetails(component, event, helper);
            }
            else{
                console.log('Error in IDCC_Comm_MyCases : doInit');
            }
        });
      		
        var action1 = component.get("c.packageInfo");
        action1.setCallback(this, function(response) {
            var state = response.getState();
           // var result = response.getReturnValue();
           // console.log('test result***'+result);
            console.log('package state***'+state);
            if (state === "SUCCESS" ){
                //component.set('v.packageInfo',response.getReturnValue());
                var res = response.getReturnValue();
                
                var obj = JSON.parse(res);
                var obj1 = JSON.parse(obj);
                console.log('package parse***'+obj);  
                if(obj1.httpstatus == 200 ){
                var httpstatus = obj1.httpstatus;
                var servicedata = obj1.servicedata.Status;
                var packageSize = obj1.servicedata.packagelist.length;
           //     console.log('packageSize***'+packageSize);
                var packageName = obj1.servicedata.packagelist[0].ServiceName;
                component.set('v.packageName',packageName);
                var quataSize = obj1.servicedata.packagelist[0].Quotas.length;
                var quataName=[];
                for (var i=0;i<quataSize;i++){
                    quataName.push(
                        {value : obj1.servicedata.packagelist[0].Quotas[i].name}
                    );   
                }
                if(packageSize>1){
                    var addOnpackageName = obj1.servicedata.packagelist[1].ServiceName;
                component.set('v.addOnpackageName',addOnpackageName);
                var addOnQuotaSize = obj1.servicedata.packagelist[1].Quotas.length;
                var addOnQuotaName=[];
                for (var i=0;i<addOnQuotaSize;i++){
                    addOnQuotaName.push(
                        {value : obj1.servicedata.packagelist[0].Quotas[i].name}
                    );   
                }
                }
                
                component.set('v.QuotaList',quataName);
                component.set('v.addOnpackageName',addOnpackageName);
                component.set('v.addOnQuotaList',addOnQuotaName);
             /*   console.log('Quata***'+quataSize);
                console.log('Status***'+servicedata);
                console.log('packageName***'+packageName);
                console.log('quataName***'+quataName[0].value); */
                var dataTotal=0,
                	callTotal=0,
                    smsTotal=0,
                    dataUsed=0,
                    callUsed=0,
                    smsUsed=0,
                    dataRem=0,
                    callRem=0,
                    smsRem=0;
                
                for (var i in obj1.servicedata.packagelist) {
               //     console.log('package***'+obj1.servicedata.packagelist);
                  
                    for (var j in obj1.servicedata.packagelist[i].Quotas) {
                        if(obj1.servicedata.packagelist[i].Quotas[j].benefitType == 'DATA'){
                           dataTotal += obj1.servicedata.packagelist[i].Quotas[j].initialQuota;
                            dataUsed += obj1.servicedata.packagelist[i].Quotas[j].usedQuota;
                        }else if(obj1.servicedata.packagelist[i].Quotas[j].benefitType == 'VOICE'){
                           callTotal += obj1.servicedata.packagelist[i].Quotas[j].initialQuota;
                            callUsed += obj1.servicedata.packagelist[i].Quotas[j].usedQuota;
                        }if(obj1.servicedata.packagelist[i].Quotas[j].benefitType == 'SMS'){
                           smsTotal += obj1.servicedata.packagelist[i].Quotas[j].initialQuota;
                            smsUsed += obj1.servicedata.packagelist[i].Quotas[j].usedQuota;
                        }
                    } 
                }
                
                dataTotal = Math.round(dataTotal/1024);
                dataUsed = Math.round(dataUsed/1024).toFixed(2);
               
           //    console.log('dataTotal***'+dataTotal);
            //   console.log('dataTotal***'+dataUsed); 
               component.set('v.callTotal',callTotal);
               component.set('v.callUsed',callUsed);
               component.set('v.smsTotal',smsTotal);
               component.set('v.smsUsed',smsUsed);
                component.set('v.dataTotal',dataTotal);
               component.set('v.dataUsed',dataUsed);
               
                
                if(dataTotal!=0){
                    dataRem=Math.round(((dataUsed)/dataTotal)*100);
                 document.getElementById('loaddiv3').style.width = dataRem+"%"; }
                if(callTotal!=0){
                    callRem=Math.round(((callUsed)/callTotal)*100);
               //     console.log(' call total'+callTotal+'call used -->'+callUsed+' call remaining-->'+callRem);
                 document.getElementById('loaddiv1').style.width = callRem+"%"; }
                if(smsTotal!=0){
                    smsRem=Math.round(((smsUsed)/smsTotal)*100);
                 document.getElementById('loaddiv2').style.width = smsRem+"%"; }
                component.set('v.dataRem',dataRem); 
                component.set('v.callRem',callRem); 
                component.set('v.smsRem',smsRem); 
              //   console.log('dataTotal***'+dataRem);
                } 
            }
            else{
                console.log('Error in package info call');
            }
        });
		
         var action2 = component.get("c.paymentHistory");
        action2.setCallback(this, function(response) {
            var state2 = response.getState();
            console.log('after payment state***'+state2);
            if (state2 === "SUCCESS" ){

                var res2 = response.getReturnValue();
                  
                var obj = JSON.parse(res2);
                var obj1 = JSON.parse(obj);
                   console.log('after payment parse***'+obj); 
                if(obj1.SiebelMessage.ErrorMessage == '' || obj1.SiebelMessage.ErrorMessage == null ){
                
       /*         var idsmoney=[];
                var idsdate=[];
                var arrayLength = JSON.stringify(obj1.SiebelMessage.ListOfIdsPaymhistIoVbc.IdsPaymentHistory.length);
                for(var i=0;i<arrayLength;i++){
                    idsmoney.push(
                        {value : JSON.stringify(obj1.SiebelMessage.ListOfIdsPaymhistIoVbc.IdsPaymentHistory[i].IDSInvoiceMoney)}
                    );
                    idsdate.push(
                        {value : JSON.stringify(obj1.SiebelMessage.ListOfIdsPaymhistIoVbc.IdsPaymentHistory[i].IDSPaymentDate)}
                    );
                }
                //var IDSInvoiceMoney = JSON.stringify(obj1.SiebelMessage.ListOfIdsPaymhistIoVbc.IdsPaymentHistory[0].IDSInvoiceMoney);
                 var IDSInvoiceMoney1 =(idsmoney.reduce(function(prev, current) { 
                    return (prev.IDSInvoiceMoney < current.IDSInvoiceMoney) ? prev : current 
                }));
                var IDSInvoiceDate1 =(idsdate.reduce(function(prev, current) { 
                    return (prev.IDSPaymentDate < current.IDSPaymentDate) ? prev : current 
                })); */
                var IDSInvoiceMoney = JSON.stringify(obj1.SiebelMessage.ListOfIdsPaymhistIoVbc.IdsPaymentHistory[0].IDSInvoiceMoney);
                var IDSInvoiceMoney = IDSInvoiceMoney.slice(1,IDSInvoiceMoney.length-1); 
                 var IDSInvoiceDate = JSON.stringify(obj1.SiebelMessage.ListOfIdsPaymhistIoVbc.IdsPaymentHistory[0].IDSPaymentDate);
                var IDSInvoiceDate = IDSInvoiceDate.slice(1,IDSInvoiceDate.length-1);
                const months = ["JAN", "FEB", "MAR","APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
				let current_datetime = new Date(IDSInvoiceDate)
				let formatted_date = current_datetime.getDate() + " " + months[current_datetime.getMonth()] + " " + current_datetime.getFullYear()
				
                 component.set('v.paymentMoney',IDSInvoiceMoney);
                console.log('payment IDSInvoiceMoney1***'+ IDSInvoiceMoney);
                 component.set('v.paymentDate',formatted_date);
                console.log('payment IDSInvoiceDate***'+ formatted_date);
                }
            }
            else{
                console.log('Error in payment call');
            }
        });
		var action3 = component.get("c.assetInfo");
        action3.setCallback(this, function(response) {
            var state = response.getState();
            
            if (state === "SUCCESS" ){
                var res = response.getReturnValue();
                 
                var obj = JSON.parse(res);
                 var obj1 = JSON.parse(obj);
                  console.log('asset parse***'+obj); 
                var serviceDesc = JSON.stringify(obj1.servicedesc).toUpperCase();
                serviceDesc = serviceDesc.slice(1,serviceDesc.length-1);
                console.log('asset serviceDesc***'+serviceDesc);
                if(serviceDesc=='SUCCESS'){
                var usageLimit = JSON.stringify(obj1.servicedata.ListOfIdsEaiAssetIdccInternalIo.IdsEaiIdccParentAsset[0].UsageLimit); 
                if(usageLimit != 'null'){
                     usageLimit = usageLimit.slice(1,usageLimit.length-1);
                }    
                console.log('usageLimit***'+usageLimit);
               
                component.set('v.usageLimit',usageLimit);
                }
            }
            
        });
  
        var action4 = component.get("c.unbilledUsage");
        action4.setCallback(this, function(response) {
            var state = response.getState();
            
            if (state === "SUCCESS" ){
                var res = response.getReturnValue();
                 
                var obj = JSON.parse(res);
                 var obj1 = JSON.parse(obj);
                 console.log('unbilled parse***'+obj); 
              var serviceDesc = JSON.stringify(obj1.servicedesc).toUpperCase();
                   serviceDesc = serviceDesc.slice(1,serviceDesc.length-1);
                console.log('unbilled serviceDesc***'+serviceDesc);
                
                if(serviceDesc == 'SUCCESS'){
               
                var unbilled = JSON.stringify(obj1.servicedata.TotalUnbilledUsage);
                 console.log('unbilled***'+unbilled);
               
                component.set('v.unbilled',unbilled);
                }
            }
            
        });
        
        var action5 = component.get("c.invoiceHistory");
        action5.setCallback(this, function(response) {
            var state = response.getState();
            
            if (state === "SUCCESS" ){
                var res = response.getReturnValue();
                 
                var obj = JSON.parse(res);
                 var obj1 = JSON.parse(obj);
             
                console.log('invoice parse***'+obj); 
                if(obj1.SiebelMessage.ErrorMessage == '' || obj1.SiebelMessage.ErrorMessage == null ){
               /*  var idsInvoiceDate=[];
                var arrayLength = JSON.stringify(obj1.SiebelMessage.ListOfIdsInvoiceIoVbc.IdsInvoice.length);
                for(var i=0;i<arrayLength;i++){
                   
                    idsInvoiceDate.push(
                        {value : JSON.stringify(obj1.SiebelMessage.ListOfIdsInvoiceIoVbc.IdsInvoice[i].IDSInvoiceDate)}
                    );
                }
               
                var invoiceDate1 =(idsInvoiceDate.reduce(function(prev, current) { 
                    return (prev.IDSInvoiceDate > current.IDSInvoiceDate) ? prev : current 
                }));
             */
                 var invoiceDate2 = JSON.stringify(obj1.SiebelMessage.ListOfIdsInvoiceIoVbc.IdsInvoice[0].IDSInvoiceDate);
                console.log('invoiceDate2***'+invoiceDate2);
                var invoiceDate = invoiceDate2.slice(1,invoiceDate2.length-1);
                const months = ["JAN", "FEB", "MAR","APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
				let current_datetime = new Date(invoiceDate)
				let formatted_date = current_datetime.getDate() + " " + months[current_datetime.getMonth()] + " " + current_datetime.getFullYear()
                console.log('invoiceDate***'+formatted_date);
               
                component.set('v.invoiceDate',formatted_date);
                }
            }
            
        });
        
         var action6 = component.get("c.getCaseId");
        action6.setCallback(this, function(response) {
            var state = response.getState();
            var result1 = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result1)){
                component.set('v.recordId',result1.Id);
            }
            
        });
        $A.enqueueAction(action);
        $A.enqueueAction(action1);
		$A.enqueueAction(action2);
		$A.enqueueAction(action3);
        $A.enqueueAction(action4);
        $A.enqueueAction(action5);
        $A.enqueueAction(action6);
	},
     handleCreateCaseModal : function(component, event, helper) {
        component.set("v.isOpenModal", true);
    },
     closeModel : function(component, event, helper) {
        component.set("v.isOpenModal", false);
    },
    createCase : function(component, event, helper) {
        helper.handleCreateCase(component, event, helper);
    },
    myBillingHistory : function(component, event, helper) {
        var recordId = component.get('v.accountId');
        
        if(recordId!=null){
            
            var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_CommunityBillingHistory?resObjName=Community_Billing_History_Res&recordId='+recordId; //Query_Payment_History_Res
            
            component.set("v.URL",tmp);
        } 
	},
    paymentHistory1: function(component, event, helper){
        
        var recordId = component.get('v.accountId');
        
        if(recordId!=null){
            
             window.open($A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_CommunityBillingHistory?resObjName=Query_Payment_History_Res&recordId='+recordId, "myWindow", "width=800,height=400,top=100, left=160");
            return false; 
        }
    },
     createAppointment: function(component, event, helper){
        
       var recordId = component.get('v.accountId');
        
        if(recordId!=null){
            var staticLabel = $A.get("$Label.c.IDCC_SandboxURL");
            var receipt1 =   window.open(staticLabel+'apex/IDCC_ConsoleAppointmentStep1?recordId='+recordId, "myWindow", "width=800,height=400,top=100, left=160");
            return false; 
        }
    },
})