({
	toLoginPage :function(component, event, helper) {
        window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/login/', '_self');
    }
    
})