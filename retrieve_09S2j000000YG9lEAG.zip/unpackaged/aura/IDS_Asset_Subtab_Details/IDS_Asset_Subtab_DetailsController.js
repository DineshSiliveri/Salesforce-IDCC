({
    doInit : function(component, event, helper) {
        //Get the parameter being passed from the main case page
        var pageReference = component.get('v.pageReference');
        component.set("v.apiEndPoint", pageReference.state.c__params);
        component.set("v.TestChildAPI", pageReference.state.c__TestChildAPI);
        component.set("v.cmpTitle", pageReference.state.c__title);
        component.set("v.cmpLtIcon", pageReference.state.c__icon);
        component.set("v.contentbody", pageReference.state.c__contentbody);
        component.set("v.contentsubbody", pageReference.state.c__contentsubbody);
        component.set("v.contentsecondsubbody", pageReference.state.c__contentsecondsubbody);
        component.set("v.recordId", pageReference.state.c__recordId);
        
        //Set the errors as null
        component.set('v.Error', false);
        component.set('v.StateError', false);

        //Run helper class
        helper.InitialChecking(component,event, helper);
    },
    
     RefreshComponent: function (component, event, helper) {
        var a = component.get('c.doInit');
        $A.enqueueAction(a);
    }
})