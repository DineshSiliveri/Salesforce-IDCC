({
    //This function is for checking the condition to run the entire callout and calculation
    //This will prevent the components from being continuously reload due to the session
    InitialChecking: function(component, event, helper){
        var CurrentCaseID = component.get("v.CaseId");
        var RecordID = component.get("v.recordId");
        
        //Check if Case ID from Event and Current record ID is the same, if they are different don't do anything and do not refresh the component
        //If CaseID == undefined && RecordID exists -> It is first time Loading
        if(CurrentCaseID != undefined && CurrentCaseID != RecordID){
            console.log('No Changes Made')
        }
        else{
            helper.CreateWrapper(component,event, helper);
        }
    },
    
    //This function is for spinner purposes
    showSpinner : function (component, event) {
        var spinner = component.find("spinner");
        $A.util.removeClass(spinner, "slds-hide");
        $A.util.addClass(spinner, "slds-show");
        component.set('v.NoSpinner', true);
    },
    
    //This function is for spinner purposes
    hideSpinner : function (component, event) {
        var spinner = component.find("spinner");
        $A.util.removeClass(spinner, "slds-show");
        $A.util.addClass(spinner, "slds-hide");
        component.set('v.NoSpinner', false);
    },
    
    //This function will call the apex controller and return a wrapper with information needed
    CreateWrapper: function(component, event, helper){
        this.showSpinner(component, event);
        var APIEndPoint = component.get("v.apiEndPoint");
        var TestChildAPI = component.get("v.TestChildAPI");
        var ContentBody = component.get("v.contentbody");
        var ContentSubBody = component.get("v.contentsubbody");
        var ContentSecondSubBody = component.get("v.contentsecondsubbody");
        var RecordID = component.get("v.recordId");
        
        console.log('DBG Asset Details: ');
        console.log("-----------Do Apex Callout-----------");
        console.log('APIEndPoint: '+ APIEndPoint);
        console.log('TestChildAPI: '+ TestChildAPI);
        console.log('ContentBody: '+ ContentBody);
        console.log('ContentSubBody: '+ ContentSubBody);
        console.log('ContentSecondSubBody: '+ ContentSecondSubBody);
        console.log('RecordID: '+ RecordID);
        console.log("-----------Do Apex Callout-----------");

        if (APIEndPoint === undefined || TestChildAPI === undefined || ContentBody === undefined || ContentSubBody === undefined ||
            ContentSecondSubBody === undefined || RecordID === undefined) {
            console.log('DBG a parameter is undefined');
            return;
        }
        // start and end date are not needed on Asset
        var action = component.get("c.doContsructWrapper");
        if (!action) {
            return;
        }
        action.setParams({
            APIEndPoint: APIEndPoint,
            ContentBody: ContentBody,
            ContentSubBody: ContentSubBody,
            TestChildAPI: TestChildAPI,
            ContentSecondSubBody: ContentSecondSubBody,
            RecordID: RecordID,
            StartDate: null,
            EndDate: null
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log('DBG asset detail state: ', state);
            if (state == "SUCCESS") {
                //console.log('DBG asset detail getReturnValue: ', JSON.stringify(JSON.parse(response.getReturnValue())));
                var allValues = JSON.parse(response.getReturnValue());
                component.set('v.ResponseWrapper', allValues);
                
                //If error exists, skip the calculation and just show an error on the component
                if(allValues.ErrorMessage != 'Success'){
                    component.set('v.Error', true);
                }
                helper.ProcessHeader(component,event, helper);
            }
            else{
                console.log('DBG State is failure');
                component.set('v.Error', true);
                component.set('v.StateError', true);
            }
            this.hideSpinner(component, event);
        });
        $A.enqueueAction(action);
    },
    
    
    //This function will process the raw data for the header
    ProcessHeader: function(component, event, helper){
        var temp = [];
        var temp2 = [];
        var finaltemp = [];
        var finaltemp2 = [];
        var displayorder = {};
        var displayorder2 = {};
        var displayfinalorder = [];
        var displayfinalorder2 = [];
        var temporary = [];
        var temporary2 = [];
        var finaltemporary = [];
        var finaltemporary2 = [];
        try{
            var temporarystorage = component.get("v.ResponseWrapper.FieldsToDisplay");
            var temporarystorage2 = component.get("v.ResponseWrapper.SecondFieldsToDisplay");
            //console.log('DBG temporarystorage: ', JSON.stringify(temporarystorage));
            //console.log('DBG temporarystorage2: ', temporarystorage2);

            if (temporarystorage) {
                for (var i = 0; i < temporarystorage.length; i++) {
                        temp.push(temporarystorage[i]);
                }
            }
            
            if (temporarystorage2) {
                for (var i = 0; i < temporarystorage2.length; i++) {
                        temp2.push(temporarystorage2[i]);
                }
            }
            
            if (temp) {
                for (var x=0; x < temp.length; x++){
                        temporary.push(temp[x].LTC_Field_Name__c);
                        displayorder[temp[x].LTC_Field_Name__c] = temp[x].Display_Order__c;
                        displayfinalorder.push(temp[x].Display_Order__c);
                }
            }
            
            if (temp2) {
                for (var x=0; x < temp2.length; x++){
                        temporary2.push(temp2[x].LTC_Field_Name__c);
                        displayorder2[temp2[x].LTC_Field_Name__c] = temp2[x].Display_Order__c;
                        displayfinalorder2.push(temp2[x].Display_Order__c);
                }
            }

            if (displayfinalorder) {
                displayfinalorder = displayfinalorder.sort(function(a,b) {return a-b;});
            }

            if (displayfinalorder2) {
                displayfinalorder2 = displayfinalorder2.sort(function(a,b) {return a-b;});
            }

            if (temporary) {
            //Sort the tableheader into display order
                for (var i=0; i<temporary.length;i++) {
                    var currentorder = displayfinalorder[i];
                    for (var key in displayorder) {
                        var value = displayorder[key];
                        if (value == currentorder) {
                            finaltemporary.push(key)
                        }
                    }
                    
                }
            }
            
            if (temporary2) {
            	for (var i=0; i<temporary2.length;i++) {
                    var currentorder2 = displayfinalorder2[i];
                    for (var key in displayorder2) {
                        var value2 = displayorder2[key];
                        if (value2 == currentorder2) {
                            finaltemporary2.push(key)
                        }
                    }
                    
                }
            }

            if (displayfinalorder) {
                //Push sorted labels into final array
                for (var i=0; i<displayfinalorder.length;i++) {
                    for (var x=0; x<temp.length;x++) {
                        if (temp[x].Display_Order__c == displayfinalorder[i]) {
                        	finaltemp.push(temp[x]);
                        }
                    }
                }
            }

            if (displayfinalorder2) {
                for (var i=0; i<displayfinalorder2.length;i++) {
                    for (var x=0; x<temp2.length;x++) {
                        if (temp2[x].Display_Order__c == displayfinalorder2[i]) {
                        	finaltemp2.push(temp2[x]);
                        }
                    }
                }
            }
            
            component.set('v.FormHeader', finaltemp);
            
            component.set('v.TableHeader', finaltemp2);
            helper.ProcessRecords(component,event, helper);
        }
        catch(err){
            console.log('DBG error in process header: ', err);
            component.set('v.Error', true);
        }
    },   
    
    //This function is for processing the data
    ProcessRecords: function(component, event, helper){
        var allrecordstorage = component.get("v.ResponseWrapper.AllRecords");
        var formheader = component.get("v.FormHeader");
        var tableheader = component.get("v.TableHeader");
        var mainstorage = [];
        var subname = component.get("v.contentsecondsubbody");
        var ErrorMessage = component.get("v.ResponseWrapper.ErrorMessage");
        var temporarytypes = component.get("v.ResponseWrapper.FieldsToDisplay");
        var temptypes = {};
        
        //If there is any error, show Errors in the UI
        if(ErrorMessage == 'Success'){
            component.set('v.StateError', true);
        }else{
            component.set('v.StateError', false);
        }

		//Need to input logic for data-type conversion and display if needed below (Edmond)        
        for (var i=0;i<temporarytypes.length;i++) {
            var typename = temporarytypes[i].LTC_Field_Name__c;
            var datatype = temporarytypes[i].LTC_Field_Type__c;
            temptypes[typename] = datatype;
        } 
        
        //If callout succeed but there is no data returned, show a "No Record Found" on the UI
        if(allrecordstorage.length == 0 || allrecordstorage.length == null){;
            component.set('v.Error', true);
        }
        else{
            try{
                //Taking just the API Name and put them into a temporary storage
                var temporaryformheader = [];
                for(var x=0; x < formheader.length; x++){
                    temporaryformheader.push(formheader[x].LTC_Field_Name__c);
                }
                
                //Taking just the API Name and put them into a temporary storage
                var temporarytableheader = [];
                for(var x=0; x < tableheader.length; x++){
                    temporarytableheader.push(tableheader[x].LTC_Field_Name__c);
                }
                
                var temporarylabel = [];
                for(var x=0; x < formheader.length; x++){
                    temporarylabel.push(formheader[x].LTC_Field_Label__c);
                }
                
                //Loop through every single records and process them one by one
                for(var m=0; m < allrecordstorage.length; m++){
                    console.log('processing records')
                    var temporarystorage = allrecordstorage[m];
                    //Taking the values of each records related to the API Name and store into a storage
                    var NewBody = "";
                    var TempBody = "";
                    var storage = [];
                    var secondarystorage = [];
                    var tracker = 0;
                    var NoIteration = Math.floor((temporaryformheader.length)/2);
                    
                    //Processing the forms
                    for(var x=0; x<NoIteration; x++){
                        var opt = [];
                        opt.push({
                            header: temporaryformheader[tracker],
                            label: temporarylabel[tracker],
                            value: temporarystorage[temporaryformheader[tracker]]
                        });
                        opt.push({
                            header: temporaryformheader[tracker+1],
                            label: temporarylabel[tracker+1],
                            value: temporarystorage[temporaryformheader[tracker+1]]
                        });
                        storage.push({
                            recordposition: x,
                            inside: opt
                        });
                        tracker = tracker + 2;
                    }
                    
                    if(NoIteration != ((temporaryformheader.length)/2)){
                        var opt = [];
                        opt.push({
                            header: temporaryformheader[temporaryformheader.length-1],
                            label: temporarylabel[temporarylabel.length-1],
                            value: temporarystorage[temporaryformheader[temporaryformheader.length-1]]
                        })
                        storage.push({
                            recordposition: -1,
                            inside: opt
                        });
                    }
                    
                    
                    //This function is for processing the data in the table
                    for (var i=0; i<temporarystorage[subname].length; i++){
                        var opt = [];
                        for (var ii=0; ii<temporarytableheader.length; ii++){
                            NewBody = temporarystorage[subname][i][temporarytableheader[ii]];
                            opt.push({
                                header: temporarytableheader[ii],
                                value: NewBody
                            });
                            
                        }
                        secondarystorage.push({
                            recordposition: i,
                            inside: opt
                        });
                    }
                    
                    if(secondarystorage.length==0){
                        mainstorage.push({
                            record: m,
                            storage: storage,
                            secondary: secondarystorage
                        });
                    }else{
                        mainstorage.push({
                            record: m,
                            storage: storage,
                            secondary: secondarystorage,
                            tableheader: tableheader
                        });
                    }
                    
                    
                }
                console.log('DBG FormRecords: ', mainstorage);
                component.set('v.FormRecords', mainstorage);
            }
            catch(err){
                console.log('DBG processRecords error');
                component.set('v.StateError', true);
                component.set('v.Error', true);
            }
        }
    }
})