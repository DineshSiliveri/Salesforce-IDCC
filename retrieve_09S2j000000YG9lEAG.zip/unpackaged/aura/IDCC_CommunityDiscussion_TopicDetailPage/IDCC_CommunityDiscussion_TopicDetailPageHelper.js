({
	init : function(component, event, helper) {
        var action = component.get("c.getTopicDetailName");
        action.setParams({"topicId": component.get("v.recordId")}); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(component.isValid() && state == "SUCCESS"){
                var c = response.getReturnValue();
                component.set("v.recordStrng", c); 
            }else {
                    console.log("Unknown error"+errors[0].message);
                }
        });        
        $A.enqueueAction(action);
    }
})