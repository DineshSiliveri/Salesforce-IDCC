({
    //Init Method
    init : function(component, event, helper) {
    	console.log('Id&&&'+component.get("v.recordId"));
     	helper.init(component,event,helper);
    }
})