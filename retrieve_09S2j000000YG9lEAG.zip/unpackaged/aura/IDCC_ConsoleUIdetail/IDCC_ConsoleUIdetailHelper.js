({ 
    
    //This method is called on init action to fetch Case data and it is setting columns to be shown
    //on 'Previous Case' tabs
    showCaseDetails : function(component, event) {
        //This is used to set columns to be shown on 'Previous Cases'tabs
        component.set('v.caseColumns', [
            { label: 'Case', fieldName: 'LinkName', type: 'url', typeAttributes: {label: { fieldName: 'CaseNumber' }, target: '_top'} },
            { label: 'Case Origin', fieldName: 'Origin', type:"text"},
            { label: 'Status', fieldName: 'Status', type:"text"},
            { label: 'Subject', fieldName: 'Subject', type:"text"},
            { label: 'Owner', fieldName: 'Owner', type:"text"},
            { label: 'Priority', fieldName: 'Priority', type: 'text' },
            { label: 'Activity Code', fieldName: '', type: 'url' }
        ])
        
        var action = component.get("c.setViewStat"); 
        //var actionLayout = component.get("c.casePageLayout"); 
        var caseId = component.get("v.recordId");
        action.setParams({
            "caseId":caseId
        });
        
        action.setCallback(this, function(response) {
            component.set('v.caseData', response.getReturnValue());              
        });
        // Queue this action to send to the server
        $A.enqueueAction(action); 
    },
    
    
})