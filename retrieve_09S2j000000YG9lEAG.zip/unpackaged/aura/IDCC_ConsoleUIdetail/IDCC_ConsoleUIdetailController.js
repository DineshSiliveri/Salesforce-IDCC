({
     init : function(component, event, helper) {
         //Calling helper method on init action
        helper.showCaseDetails(component, event);
    },
    
    //Passing the clicked icon's name  using event
    handleApplicationEvent : function(cmp, event, helper) {  
        // Get value from Event
        var tmp = event.getParam("iconClicked");
        cmp.set("v.openIcon", tmp);
        //console.log('*** tmp ==> ' + tmp); 		
    }
})