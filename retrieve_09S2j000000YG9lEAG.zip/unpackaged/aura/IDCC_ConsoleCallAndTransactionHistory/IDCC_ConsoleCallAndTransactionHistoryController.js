({
    getCallHistoryMorethanDetails : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleHistoryTable?resObjName=Query_Call_History_More24_Res&apiName=Query_Call_History_More24&recordId='+recordId; 
        component.set("v.URL",tmp);
        helper.scrolltoTop();
        
    },
    getCallHistoryLessthanDetails : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleHistoryTableUnder24Hour?resObjName=Query_Call_History_Under24_Hour_Res&apiName=Query_Call_History_Under_24_Hour&recordId='+recordId; 
        component.set("v.URL",tmp);
        helper.scrolltoTop();
    },
    getTransHistoryMorethanDetails : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleTransHistoryTable?resObjName=Query_Transaction_His_more_24hrs_Dis_Res&apiName=Query_Transaction_His_more_than_24_Hours&recordId='+recordId; 
        component.set("v.URL",tmp);
        helper.scrolltoTop();
    },
    getTransHistoryLessthanDetails : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleTransHistoryTableUnder24Hour?resObjName=Query_Transaction_History_Under_24_Hour&apiName=Query_Transaction_History_Under_24_Hour&recordId='+recordId; 
        component.set("v.URL",tmp);
        helper.scrolltoTop();
    },
    hideSpinner: function (component, event, helper) {         
        var spinner = component.find('spinner');
        $A.util.removeClass(spinner, 'loadSpinner');
        $A.util.addClass(spinner, 'newLoadSpinner');
    },
})