({
    SearchArticle : function(cmp, event, helper) {
        
        var term = cmp.get("v.SearchKey");
        if(term.length >0){
        var action = cmp.get('c.searchAllArticles');
        var args = {
            'key': cmp.get('v.SearchKey')
        }
        action.setParams(args);
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var result = response.getReturnValue();
                cmp.set('v.articles', result);
                console.log(result);
            } else {
                console.log(response.getError());
            }
        })
        $A.enqueueAction(action);
        }
        cmp.set('v.articles', cmp.get('v.dupArticles'));
    },
    
    
    doInit: function(cmp, helper) {
        var action = cmp.get('c.search');
        var args = {
            'recordId': cmp.get('v.recordId')
        }
        action.setParams(args);
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var result = response.getReturnValue();
                cmp.set('v.articles', result);
                cmp.set('v.dupArticles', result);
                console.log(result);
            } else {
                console.log(response.getError());
            }
        })
        $A.enqueueAction(action);
    }
})