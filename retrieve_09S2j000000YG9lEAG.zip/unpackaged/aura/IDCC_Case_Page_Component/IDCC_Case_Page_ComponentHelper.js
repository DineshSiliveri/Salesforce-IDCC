({
    editStatus : function(component, event) {
        // Set isModalOpen attribute to true
        component.set("v.isModalOpen", true);
    },
    
    cancelModel : function(component, event) {
        // Set isModalOpen attribute to false  
        component.set("v.isModalOpen", false);
    },
    
    submitDetails : function(component, event) {
        // Set isModalOpen attribute to false
        //Add your code to call apex method or do some processing      
        component.set('v.ErrorMessage', '');
        var action = component.get("c.updateCaseStatus");    
        var caseId = component.get("v.recordId"); 
        var caseStatus = component.find("Status").get("v.value");
        var cancelReason = component.find("cancelReason").get("v.value");
        var duplicateCase = component.find("duplicateCase").get("v.value"); 
        
        if(caseStatus != 'Cancel' && cancelReason != 'Double / Duplicate' && !(duplicateCase == null || duplicateCase== '')){
            component.set('v.ErrorMessage', "Duplicate Case can be only selected when the cancellation reason is 'Double / Duplicate'. ");
        }
        
        action.setParams({
            "caseId":caseId,
            "cStatus":caseStatus, 
            "cancelReason" : cancelReason,
            "duplicateCase" : duplicateCase
        });  
        if(component.get("v.ErrorMessage") == ''){
            action.setCallback(component,function(response) {
                var state = response.getReturnValue(); 
                
                if (state == 'true' && component.get("v.ErrorMessage") == ''){  
                    component.set("v.isModalOpen", false);
                    window.location.reload( );                    
                    // $A.get('e.force:refreshView').fire();               
                } else {  
                    component.set("v.isModalOpen", true);
                    component.set('v.ErrorMessage', state); 
                    // window.location.reload( );
                }
            }
                              );
        }
        
        // Queue this action to send to the server        
        $A.enqueueAction(action);
    },
    
    //Method to show case details on init action  
    showDetails:function(component, event,helper){
        var action = component.get("c.setViewStat"); 
        var action1 = component.get("c.showPersonaDetails"); //Action to get Social Persona Details
        var caseId = component.get("v.recordId");       
        
        action.setParams({
            "caseId":caseId
        });
        action1.setParams({
            "caseId":caseId
        });
        
        // Set up the callback
        action.setCallback(this, function(response) {
            component.set('v.caseData', response.getReturnValue()); 
            //Added by Vaidehi to add filter to delete button
            component.set('v.spamMailCheck' ,response.getReturnValue().IDCC_Is_Spam_Junk_Susupicious__c);
            this.checkforProfile(component, event, helper);
        });
        
        // Set up the callback
        action1.setCallback(this, function(response1) {
            var state = response1.getState();
            var result = response1.getReturnValue();
            if(state === "SUCCESS"){
                if(!$A.util.isEmpty(result)){
                    component.set('v.personaData', response1.getReturnValue());
                }
            }else{
                console.log('Error');
            }
        });
        // Queue this action to send to the server
        $A.enqueueAction(action);
        $A.enqueueAction(action1);
    },
    //Added by Komal for delete case and  update case owner
    checkforProfile :function(component, event, helper) {
        var action = component.get("c.checkForProfile");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS"){
                if(!$A.util.isEmpty(result)){
                    component.set('v.isSupervisor',response.getReturnValue());    
                }
            }
            else{
                console.log('Error in IDCC_case_PageComponent : checforProfile');
            }
        });
        $A.enqueueAction(action); 	
    },
    
    changeOwner :function(component, event, helper) {
        var message ="Owner has been changed successfully.";
        var action = component.get("c.updateOwner");
        var caseId =component.get("v.recordId");
        action.setParams({
            "caseId":caseId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS"){
                if(result == 'true'){
                    this.showToast(component, event, message)
                    this.showDetails(component, event, helper)
                } } });
        $A.enqueueAction(action); 	
    },
    
    
    showToast : function(component, event, message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "",
            "message": message
        });
        toastEvent.fire();
    }
    
})