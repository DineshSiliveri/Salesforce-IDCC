({
    /* doInit : function(component, event, helper) {	
      
        var relatedListEvent = $A.get("e.force:navigateToRelatedList");
        
        relatedListEvent.setParams({
            "relatedListId": "Cases",
            "parentRecordId": '5000w000001GJnN'             
        });
        alert('test');
        relatedListEvent.fire();
       
        
    }*/
    doInit : function(component, event, helper) {
        helper.showDetails(component, event,helper); 
    },
    
    //Method to edit status
    editStatus : function(component, event, helper) {
        helper.editStatus(component, event);        
    },  
    
    
    cancelModel: function(component, event, helper) {
        helper.cancelModel(component, event);     
    },
    
    changeOwner: function(component, event, helper) {
       /* var selectedEventId = event.target.id;
        var msg ='Are you sure you want to change owner?';
        if (!confirm(msg)) {
            console.log('No');
            return false;
        } else {
            console.log('Yes');
            // 
        }*/
        helper.changeOwner(component, event, helper); 
    },
    
    submitDetails: function(component, event, helper) {
        helper.submitDetails(component, event);      
    },
    //Added by Komal for delete Case
    handleDeteleCase :function( component, event, helper ) {
        component.set('v.isOpenDeleteCase',true);
    },
    updateNotifications : function( component, event, helper ) {
       var actionAPI = component.find("quickActionAPI");
        alert(actionAPI);
        var args = { actionName :"Case.Change_Owner",entityName:"Case", targetFields : fields }; 
        alert(args);
         var fields = {
                       Subject : { value : "Sets by lightning:quickActionAPI component" }, 
                        };
        actionAPI.selectAction(args).then(function() {
           actionAPI.invokeAction(args);
            alert('in action');
        
        }).catch(function(e) {
            if (e.errors) {
                console.log('--------------------'+e.errors);
                alert('in error');
            }
    	});
    },
      //Added by Komal for delete Case
    handlecloseDeleteCaseModal :function(component, event, helper ) {
        component.set('v.isOpenDeleteCase',false);    
    },
     //Added by Komal for delete Case
    handleYes :function(component, event, helper ) {
        component.set('v.isOpenDeleteCase',false);    
        component.find("recordHandler").deleteRecord($A.getCallback(function(deleteResult) {
            if (deleteResult.state === "SUCCESS" || deleteResult.state === "DRAFT") {
                var workspaceAPI = component.find("workspace");
                workspaceAPI.getFocusedTabInfo().then(function(response) {
                    var focusedTabId = response.tabId;
                    workspaceAPI.closeTab({tabId: focusedTabId});
                })
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "type": "success",
                    "message": "Case Deleted Successfully"
                });
                toastEvent.fire();  
            } 
        }));  
    },
     //Added by Komal for update case owner
     handleSaveRecord: function(component, event, helper) {
        component.find("recordEditor").saveRecord($A.getCallback(function(saveResult) {
            if (saveResult.state === "SUCCESS" || saveResult.state === "DRAFT") {
                alert("Save completed successfully.");
            } else if (saveResult.state === "INCOMPLETE") {
                console.log("User is offline, device doesn't support drafts.");
            } else if (saveResult.state === "ERROR") {
                console.log('Problem saving record, error: ' + 
                           JSON.stringify(saveResult.error));
            } else {
                console.log('Unknown problem, state: ' + saveResult.state + ', error: ' + JSON.stringify(saveResult.error));
            }
        }));
     },
      //Added by Komal for update case owner
    handleChangeOwner : function(component, event, helper) {
       var recordid1 = component.get("v.recordId") ;
        var actionAPI = component.find("quickActionAPI");
        alert(actionAPI);
       
        var fields = { Status : { value : "Closed"}  };
        alert(JSON.stringify(fields));
        
        var args = {actionName: "Case.Change_Owner", entityName: "Case",targetFields: fields};
        alert('args:'+args);
        actionAPI.setActionFieldValues(args).then(function(){
            actionAPI.invokeAction(args);
        }).catch(function(e){
            alert(e.errors);
            console.log(e.errors);
            console.error(e.errors);
        });
        /* var actionAPI = component.find("quickActionAPI");
        actionAPI.getAvailableActions().then(function(result){
            //All available actions shown;
        }).catch(function(e){
            if(e.errors){
                alert(e.errors);
                //If the specified action isn't found on the page, show an error message in the my component 
            }
        });*/
         /*var actionAPI = component.find("quickActionAPI");
        var args = { actionName :"Case.Change_Owner" };
        actionAPI.selectAction(args).then(function(result) {
            // Action selected; show data and set field values
        }).catch(function(e) {
            if (e.errors) {
                alert(e.errors);
                // If the specified action isn't found on the page, 
                // show an error message in the my component 
            }
        });*/
      /*   alert('Hello');
    var actionAPI = component.find("quickActionAPI");
      var recordId = component.get("v.recordId");
    var args = {actionName :"Case.Change_Owner", entityName: "Case"};
    actionAPI.getAvailableActionFields(args).then(function(result){
      console.log('Available Fields are ', JSON.stringify(result));
    }).catch(function(e){
      if(e.errors){
        console.log('Action Field Log Errors are ',e.errors);
        console.error('Full error is ', JSON.stringify(e));
      }
    });*/
   },
      //Added by Komal for update case owner
    handleSubmit : function(component, event, helper) {
       // alert('submit');
    },
      //Added by Komal for update case owner
 	handleSuccess : function(component, event, helper) {
       // alert('success');
    },
      //Added by Komal for update case owner
    handleLoad :function(component, event, helper) {
       // alert('load');
    },
    
    
})