({
	displayDiscussion : function(component, event, helper) {
        var topicName =  event.currentTarget.dataset.id;
        var tolicLst = component.get("v.topicLst");
        for(var i = 0; i < tolicLst.length; i++){
            if(tolicLst[i].Name == topicName){
            	window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/topic/'+tolicLst[i].Id,'_self');	  
            }
		}
	},
    doInit : function(component, event, helper) {
        helper.getTopicDetails(component, event, helper);
		component.set("v.displayHeader", true);
        component.set("v.displayFooter",true);
	},
    handleBackButton : function(component, event, helper) {
		component.set("v.displayHeader", true);
        component.set("v.displayFooter",true);
        component.set("v.displayServices", false);
    
	},  
    backToL1Handler :function(component, event, helper) {
		component.set("v.displayHeader", true);
        component.set("v.displayFooter",true);
        component.set("v.displayServices", false);
    
    }
})