({
	getTopicDetails : function(component, event, helper) {
		var action = component.get("c.getTopicDetails");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                component.set('v.topicLst',response.getReturnValue());
            }
            else{
                console.log('Error in : getTopicDetails');
            }
        });
        $A.enqueueAction(action);	
	}
})