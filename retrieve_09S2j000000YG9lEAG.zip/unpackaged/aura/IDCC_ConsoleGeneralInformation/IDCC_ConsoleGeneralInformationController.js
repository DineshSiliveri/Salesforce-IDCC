({
    getAccumumlator : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleTable?resObjName=Query_General_Info_Accu_Res&apiName=Query_general_Info&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
    },
    getDedicatedAccount : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleTable?resObjName=Query_General_Info_Dalist_Res&apiName=Query_general_Info&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
    },
    getPrepaidBalance : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        //var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_Console_GeneralInfoAdjustment?resObjName=Query_General_Info_Prepaid_Res&apiName=Query_general_Info&recordId='+recordId;
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsolePrepaidBalance?resObjName=Query_General_Info_Prepaid_Res&apiName=Query_general_Info&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
    },
    getOffer : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleTable?resObjName=Query_General_Info_Offer_Res&apiName=Query_general_Info&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
    },
    getAccountDetails : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleGeneralInfo?resObjName=Query_General_Info_AccDetails_Res&apiName=Query_general_Info&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
    },
    sOfferings : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Service_Offerings&resObjName=Query_Service_Offerings_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},
    packageList : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var recordId = component.get("v.recordId");
        //var tmp = staticLabel+'apiName=Query_Package_List&resObjName=Query_Package_List_Res&recordId='+recordId;
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsolePackageInfoTable?apiName=Query_Package_List&resObjName=Query_Package_List_Res&recordId='+recordId; 
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},
    reloadVoucher : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ReloadVoucher");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Reload_Voucher&Form&resObjName=Query_Reload_Voucher_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},
    packageInfo : function(component, event, helper) {
        
        var recordId = component.get("v.recordId");
       // var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsolePackageList?apiName=Query_Package_List&resObjName=Query_Package_List_Res&recordId='+recordId;
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsolePackageInfoTable?resObjName=Query_Package_Info_Res&apiName=Query_Package_Info&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	} ,
    queryBestOffer : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleBestAndActivateOffer?resObjName=Query_Next_Best_Offer_Res&apiName=Query_Next_Best_Offer&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();          
	},
})