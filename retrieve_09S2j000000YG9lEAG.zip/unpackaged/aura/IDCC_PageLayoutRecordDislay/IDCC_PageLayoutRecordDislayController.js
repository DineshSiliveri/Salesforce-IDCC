({
    init : function(component, event, helper) {
        helper.retrievePageLayout(component, helper);
    },
    
    EditPage : function(component, event, helper) {
        helper.EditPage(component, event);
    }
})