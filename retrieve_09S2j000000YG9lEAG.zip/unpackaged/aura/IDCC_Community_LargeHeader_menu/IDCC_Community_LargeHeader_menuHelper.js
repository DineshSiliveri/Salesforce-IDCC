({
	userDetails: function(component, event){	
        var action = component.get("c.getUserDetails");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            console.log(state+'state');
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){                
                component.set('v.loggedInUser',response.getReturnValue());
                //Checking for the user type if it is not guest then multiple links will appear 
                //on header page
                if(result.UserType != "Guest"){
                    component.set("v.headerStyle", "LoggedInheaderStyle");
                    component.set("v.leftCol", "loggedInleftCol");
                    component.set("v.checkLoggedIn", true); 
                }
            }  else{
                console.log('Error in IDCC_SelfHelpHeader : doInit');
            }   
            
        });        
        $A.enqueueAction(action); 
    },
     personalLink : function(component, event) {  
        window.open($A.get("$Label.c.IDCC_CommunityPersonalLink"),'_top');       
    },
    //It will redirect to Business Link provided by Indosat
    businessLink : function(component, event) {  
        window.open($A.get("$Label.c.IDCC_CommunityBusinessLink"),'_top');       
    },
    //It will redirect to Investor Link provided by Indosat
    investorRelLink : function(component, event) {  
        window.open($A.get("$Label.c.IDCC_CommunityInvestorRelationLink"),'_top');       
    },
    //It will redirect to LoginPage of Community
    loginLink : function(component, event) {  
        window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/login/', '_self');     
    },
    //It will redirect to home page of community
    homeLink : function(component, event) { 
        component.find("navService").navigate(    {
            type: "comm__namedPage",
            attributes: {
                pageName: "home"
            }
        }    , true);
    },
    //It will redirect to logout page
    logoutLink  :function(component, event) {
        window.location.replace($A.get("$Label.c.IDCC_CommunityURL")+"secur/logout.jsp");
    },
    
    //This part is to render title color based on URL/Page name
    //It will check for the url and then based on it, color will be decided 
    pageDetails  :function(component, event) {
        var urlString = window.location.href;        
        var baseURL = urlString.substring(urlString.indexOf("/s/"), urlString.length); 
        if(baseURL.includes($A.get("$Label.c.IDCC_Comm_DeviceSimulatorPage"))){
            component.set("v.flag","device"); }
        else if(baseURL.includes($A.get("$Label.c.IDCC_Comm_DiscForumPage"))){
            component.set("v.flag","forum"); 
        }else if(baseURL.includes($A.get("$Label.c.IDCC_Comm_SelfHelpLoginPage"))){
          component.set("v.flag","selfHelp");   	
        }else if(baseURL.includes($A.get("$Label.c.IDCC_Comm_SelfHelpHomePage"))){
          component.set("v.flag","selfHelpHome");  	
        }else if(baseURL.includes($A.get("$Label.c.IDCC_Comm_MyProfile") )){
          component.set("v.flag","profile");  	
        }
    }
})