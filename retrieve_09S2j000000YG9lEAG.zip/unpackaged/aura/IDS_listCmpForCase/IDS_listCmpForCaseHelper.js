({
    //This function is to determine the default value of the "Date fields" for activity history
    //If default date is not null (it is updated), then this function will not run
    CalculateDate: function(component, event, helper){
        var date = new Date();
        var days = 60;
        var today = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD");
        
        var pastdate = new Date(date.getTime() - (days * 24 * 60 * 60 * 1000));
        var newday = pastdate.getDate();
        var newmonth = pastdate.getMonth()+1;
        var newyear = pastdate.getFullYear();
        var finaldate = newyear +'-'+ newmonth +'-' + newday;
        
        component.set('v.EndDate', today);
        component.set('v.StartDate', finaldate);
    },
    
    //This function is for spinner purposes
    showSpinner : function (component, event) {
        var spinner = component.find("spinner");
        $A.util.removeClass(spinner, "slds-hide");
        $A.util.addClass(spinner, "slds-show");
        component.set('v.NoSpinner', true);
    },
    
    //This function is for spinner purposes
    hideSpinner : function (component, event) {
        var spinner = component.find("spinner");
        $A.util.removeClass(spinner, "slds-show");
        $A.util.addClass(spinner, "slds-hide");
        component.set('v.NoSpinner', false);
    },
    
    //This function is for checking the condition to run the entire callout and calculation
    //This will prevent the components from being continuously reload due to the session
    InitialChecking: function(component, event, helper){
        
        var CurrentCaseID = component.get("v.CaseId");
        var RecordID = component.get("v.recordId");

        //Check if Case ID from Event and Current record ID is the same, if they are different don't do anything and do not refresh the component
        //If CaseID == undefined && RecordID exists -> It is first time Loading
        if (CurrentCaseID == RecordID) {
            component.set('v.Error', false);
            component.set('v.StateError', false);
            component.set('v.DateRangeError', false);
            helper.CreateWrapper(component,event, helper);
        }
    },
    
    initialLoad: function(component, event, helper) {
        helper.CreateWrapper(component, event, helper);
    },

    //This function will call the apex controller and return a wrapper with information needed
    CreateWrapper: function(component, event, helper){
        this.showSpinner(component, event);
        component.set('v.NoSpinner', true);
        
        var APIEndPoint = component.get("v.apiEndPoint");
        var TestChildAPI = component.get("v.TestChildAPI");
        var ContentBody = component.get("v.contentbody");
        var ContentSubBody = component.get("v.contentsubbody");
        var ContentSecondSubBody = component.get("v.contentsecondsubbody");
        var RecordID = component.get("v.recordId");
        var StartDate = component.get("v.StartDate");
        var EndDate = component.get("v.EndDate");
        
        // console.log('DBG cmpTitle: ' + component.get('v.cmpTitle'));
        // console.log("-----------Do Apex Callout-----------");
        // console.log('APIEndPoint: '+ APIEndPoint);
        // console.log('TestChildAPI: '+ TestChildAPI);
        // console.log('ContentBody: '+ ContentBody);
        // console.log('ContentSubBody: '+ ContentSubBody);
        // console.log('ContentSecondSubBody: '+ ContentSecondSubBody);
        // console.log('RecordID: '+ RecordID);
        // console.log('StartDate: '+ StartDate);
        // console.log('EndDate: '+ EndDate);
        // console.log("-----------Do Apex Callout-----------");
        
        if (APIEndPoint === undefined || TestChildAPI === undefined || ContentBody === undefined || ContentSubBody === undefined ||
            ContentSecondSubBody === undefined || RecordID === undefined || StartDate === undefined || EndDate === undefined) {
            console.log('DBG a parameter is undefined');
            return;
        }
        var action = component.get("c.doContsructWrapper");
        action.setParams({
            APIEndPoint: APIEndPoint,
            ContentBody: ContentBody,
            ContentSubBody: ContentSubBody,
            TestChildAPI: TestChildAPI,
            ContentSecondSubBody: ContentSecondSubBody,
            RecordID: RecordID,
            StartDate: StartDate,
            EndDate: EndDate
        });

        action.setCallback(this, function(response) {
            var state = response.getState();
            //console.log('DBG state: ' + state + '---' + component.get('v.cmpTitle'));
            if (state == "SUCCESS") {
                var allValues = JSON.parse(response.getReturnValue());
                //console.log(allValues);
                component.set('v.ResponseWrapper', allValues);

                //If error exists, skip the calculation and just show an error on the component
                if(allValues.ErrorMessage != 'Success'){
                    component.set('v.StateError', false);                    
                    component.set('v.Error', true);
                }
                else{
                    component.set('v.Error', false);
                    helper.ProcessHeader(component,event, helper);
                }
            }
            else{
                alert('Unexpected Error. Please reach out to your Admin: ' + JSON.stringify(response.getError()[0]));
                component.set('v.StateError', true);
                component.set('v.Error', true);
            }
            this.hideSpinner(component, event);
            component.set('v.NoSpinner', false);
        });
        $A.enqueueAction(action);
    },
    
    //This function will process the raw data for the header
    ProcessHeader: function(component, event, helper){
        var temp = [];
        var finaltemp = [];
        var temporarystorage = component.get("v.ResponseWrapper.FieldsToDisplay");
        var format = component.get("v.format");
        var displayorder = {};
        var displayfinalorder = [];
        var temporary = [];
        var finaltemporary = [];
        try{
            for (var i = 0; i < temporarystorage.length; i++) {
                if(temporarystorage[i].Show__c == true){
                    
                    temp.push(temporarystorage[i])
                }
            }
            
            for(var x=0; x < temp.length; x++){
                    temporary.push(temp[x].LTC_Field_Name__c);
                    displayorder[temp[x].LTC_Field_Name__c] = temp[x].Display_Order__c;
                    displayfinalorder.push(temp[x].Display_Order__c);
                }
            
            displayfinalorder = displayfinalorder.sort(function(a,b) {return a-b;});
            
            //Sort the tableheader into display order
                for (var i=0; i<temporary.length;i++) {
                    var currentorder = displayfinalorder[i];
                    for (var key in displayorder) {
                        var value = displayorder[key];
                        if (value == currentorder) {
                            finaltemporary.push(key)
                        }
                    }
                    
                }
          
            //Push sorted labels into final array
            for (var i=0; i<displayfinalorder.length;i++) {
                for (var x=0; x<temp.length;x++) {
                    if (temp[x].Display_Order__c == displayfinalorder[i]) {
                    	finaltemp.push(temp[x]);
                    }
                }
            }

            component.set('v.TableHeader', finaltemp);
            //helper.convertValue(component,event,helper);
            
            //There are 2 formats available: Table and Form
            //Choose the correct function to process the record
            if(format =='Table'){
                helper.ProcessTableRecords(component,event, helper);
            }
            else{
                helper.ProcessFormRecords(component,event, helper);
            }
        }
        catch(err){
            component.set('v.Error', true);
        }   
    },
    
    //This function is for processing the data when the user choose "Table" format
    ProcessTableRecords:  function(component, event, helper){
        var temporarystorage = component.get("v.ResponseWrapper.AllRecords");
        var temporarytypes = component.get("v.ResponseWrapper.FieldsToDisplay");
        var temptypes = {};
        var tableheader = component.get("v.TableHeader");
        var ErrorMessage = component.get("v.ResponseWrapper.ErrorMessage");
        if(ErrorMessage == 'Success'){
            component.set('v.StateError', true);
            component.set('v.Error', false);
            console.log('Process Header Err = Success');
        }else{
            component.set('v.StateError', false);
            console.log('Process Header Err = Err');            
        }
        
        for (var i=0;i<temporarytypes.length;i++) {
            var typename = temporarytypes[i].LTC_Field_Name__c;
            var datatype = temporarytypes[i].LTC_Field_Type__c;
            temptypes[typename] = datatype;
        }
        console.log('temporarystroage:'+ temporarystorage);
        //If callout succeed but there is no data returned, show a "No Record Found" on the UI
        if(temporarystorage.length == 0 || temporarystorage == null || temporarystorage == undefined){
            component.set('v.StateError', true);            
            component.set('v.Error', true);
            console.log('0 length');
        }
        else{
            console.log('OK');
            try{
                //Taking just the API Name and put them into a temporary storage
                var temporary = [];
                for(var x=0; x < tableheader.length; x++){
                    temporary.push(tableheader[x].LTC_Field_Name__c);
                }
              
                //Taking the values of each records related to the API Name and store into a storage
                var NewBody = "";
                var FieldType = "";
                var storage = [];
                
                //Only want to display at most 3 records on the main component
                if(temporarystorage.length > 3){
                    for (var i=0; i<3; i++){
                        var opt = [];
                        for (var ii=0; ii<temporary.length; ii++){
                            NewBody = temporarystorage[i][temporary[ii]];
                            FieldType = temptypes[temporary[ii]];
                            opt.push({
                                header: temporary[ii],
                                value: NewBody,
                                type: FieldType
                            });
                        }
                        storage.push({
                            recordposition: i,
                            inside: opt
                        });
                    }
                }else{
                    for (var i=0; i<temporarystorage.length; i++){
                        var opt = [];
                        for (var ii=0; ii<temporary.length; ii++){
                            NewBody = temporarystorage[i][temporary[ii]];
                            FieldType = temptypes[temporary[ii]];
                            opt.push({
                                header: temporary[ii],
                                value: NewBody,
                                type: FieldType
                            });
                        }
                        storage.push({
                            recordposition: i,
                            inside: opt
                        });
                    }
                }
                component.set('v.TableRecords', storage);
            }
            catch(err){
                component.set('v.Error', true);
                component.set('v.StateError', true);
                console.log('Exception');
            }
        }
    },    
    
    //This function is for processing the data when the user choose "Form" format
    ProcessFormRecords: function(component, event, helper){
        //Assuming that form will only show 1 record at any point of time
        var allrecordstorage = component.get("v.ResponseWrapper.AllRecords");
        var temporarytypes = component.get("v.ResponseWrapper.FieldsToDisplay");
        var temporarystorage = allrecordstorage[0];
        var temptypes = {};
        var tableheader = component.get("v.TableHeader");
        var ErrorMessage = component.get("v.ResponseWrapper.ErrorMessage");
        if(ErrorMessage == 'Success'){
            component.set('v.StateError', true);
            component.set('v.Error', false);
        }else{
            component.set('v.StateError', false);
        }
        
        for (var i=0;i<temporarytypes.length;i++) {
            var typename = temporarytypes[i].LTC_Field_Name__c;
            var datatype = temporarytypes[i].LTC_Field_Type__c;
            temptypes[typename] = datatype;
        }
        
        //If callout succeed but there is no data returned, show a "No Record Found" on the UI
        if(allrecordstorage.length == 0 || allrecordstorage == null || allrecordstorage == undefined){
            component.set('v.StateError', true);            
            component.set('v.Error', true);
        }
        else{
            try{
                //Taking just the API Name and put them into a temporary storage
                var temporary = [];
                for(var x=0; x < tableheader.length; x++){
                    temporary.push(tableheader[x].LTC_Field_Name__c);
                }
                
                var temporarylabel = [];
                for(var x=0; x < tableheader.length; x++){
                    temporarylabel.push(tableheader[x].LTC_Field_Label__c);
                }
                
                //Taking the values of each records related to the API Name and store into a storage
                //The form consists of 2 column, thus split accordingly
                var NewBody = "";
                var storage = [];
                var tracker = 0;
                var NoIteration = Math.floor((temporary.length)/2);
                
                for(var x=0; x<NoIteration; x++){
                    var opt = [];
                    opt.push({
                        header: temporary[tracker],
                        label: temporarylabel[tracker],
                        value: temporarystorage[temporary[tracker]],
                        type: temptypes[temporary[tracker]]
                    });
                    opt.push({
                        header: temporary[tracker+1],
                        label: temporarylabel[tracker+1],
                        value: temporarystorage[temporary[tracker+1]],
                        type: temptypes[temporary[tracker+1]]
                    });
                    storage.push({
                        recordposition: x,
                        inside: opt
                    });
                    tracker = tracker + 2;
                }
                
                if(NoIteration != ((temporary.length)/2)){
                    var opt = [];
                    opt.push({
                        header: temporary[temporary.length-1],
                        label: temporarylabel[temporarylabel.length-1],
                        value: temporarystorage[temporary[temporary.length-1]],
                        type: temptypes[temporary[temporary.length-1]]
                    })
                    storage.push({
                        recordposition: -1,
                        inside: opt
                    });
                }
                component.set('v.FormRecords', storage);
            }
            catch(err){
                component.set('v.Error', true);
                component.set('v.StateError', true);
                console.log('Exception');
            }
        }
    },
    
    
    //Navigate to a subtab and pass the necessary parameters
    ShowAllRecords: function(component, event, helper){
        var workspaceAPI = component.find("workspace");
        var navService = component.find("navService");
        
        // set the pageReference object used to navigate to the component. Include any parameters in the state key.
        var pageReference = {
            "type": "standard__component",
            "attributes": {
                "componentName": "c__IDS_ShowAllRecords" //This is the name of the component
            },
            "state": { //This is what you are passing as parameters
                "c__params": component.get("v.apiEndPoint"),
                "c__TestChildAPI": component.get("v.TestChildAPI"),
                "c__title": component.get("v.cmpTitle"),
                "c__icon": component.get("v.cmpLtIcon"),
                "c__contentbody": component.get("v.contentbody"),
                "c__contentsubbody": component.get("v.contentsubbody"),
                "c__contentsecondsubbody": component.get("v.contentsecondsubbody"),
                "c__recordId": component.get("v.recordId"),
                "c__startdate": component.get("v.StartDate"),
                "c__enddate": component.get("v.EndDate")
            }
        };
        var parentSubTabId;
        var childSubTabId;
        // handles checking for console and standard navigation and then navigating to the component appropriately
        workspaceAPI
        .isConsoleNavigation()
        .then(function(isConsole) {
            if (isConsole) {
                //in a console app - generate a URL and then open a subtab of the currently focused parent tab
                navService.generateUrl(pageReference).then(function(cmpURL) {
                    workspaceAPI
                    .getEnclosingTabId()
                    .then(function(tabId) {
                        parentSubTabId = tabId;
                        return workspaceAPI.openSubtab({
                            parentTabId: tabId,
                            url: cmpURL,
                            focus: true
                        });
                    })
                    .then(function(subTabId) {
                        childSubTabId = subTabId;
                        // the subtab has been created, use the Id to set the label
                        workspaceAPI.setTabLabel({
                            tabId: subTabId,
                            label: component.get("v.cmpTitle")
                        });
                        workspaceAPI.setTabIcon({
                            tabId: subTabId,
                            icon: component.get("v.cmpLtIcon")
                        });
                        // to fix the stuck "Loading..." title on browser tab name
                        workspaceAPI.focusTab({tabId : parentSubTabId});
                        workspaceAPI.focusTab({tabId : childSubTabId});
                    });
                });
            } else {
                // this is standard navigation, use the navigate method to open the component
                navService.navigate(pageReference, false);
            }
        })
        .catch(function(error) {
            console.log(error);
        });
    },
    
    //This function is to listen to changes and act accordingly
    subscribeEventChange : function(component, event, helper){
        const empApi = component.find('empApi');
        const channel = component.get('v.channel');
        const replayId = -1;
        
        //If there are changes related to the case record, redo the logic
        const callback = function (message) {
            component.set('v.MSISDN', message.data.payload.MSISDN__c);
            component.set('v.CaseId', message.data.payload.CaseId__c);
            helper.InitialChecking(component,event, helper);
        };
        empApi.subscribe(channel, replayId, $A.getCallback(callback)).then($A.getCallback(function (newSubscription) {
            console.log('Subscribed to channel ' + channel);
        }));

    },
    
    //This function is to convert a given string value into a specified value
    convertValue : function(component,event,helper) {
        var localecode = $A.get("$Locale.currencyCode");
        var temporarystorage = component.get("v.ResponseWrapper.AllRecords"); //Array of arrays, each sub-array containing values corresponding to each field in a record ("ActivityCode: 130229243".etc)
        var temporarytypes = component.get("v.TableHeader"); //Array of arrays, each sub-arry containing metadata values corresponding to each field (data type: text, field label.etc)
        var tempnames = [];
        var masterdata = {};
        
        for (var i=0; i<temporarytypes.length; i++) {
            tempnames.push(temporarytypes[i].LTC_Field_Name__c);
        }

        for (var i=0; i < temporarystorage.length; i++){ //Iterate through each record of fields
            var holdingdata = {};
            var indivrecord = Object.entries(temporarystorage[i]);
            
            for (var x=0; x < indivrecord.length;x++) { //Iterate through each field within the record
                var fieldname = indivrecord[x][0];
                var fieldvalue = indivrecord[x][1]; //Stores the value of the field
                var datatype = "";
                for (var ii = 0; ii < temporarytypes.length; ii++) {
                    if (temporarytypes[ii].LTC_Field_Name__c == fieldname) {
                    	datatype = temporarytypes[ii].LTC_Field_Type__c;
                    };
                };
                //console.log(datatype);
                if (datatype == "date") {
                    //console.log("Date spotted");
                    var localdate = new Date(fieldvalue);
                    fieldvalue = localdate;
                } else if (datatype == "number") {
                    //console.log("Number spotted");
                    fieldvalue = parseFloat(fieldvalue);
                } else if (datatype == "currency") {
                    //console.log("Currency spotted");
                    fieldvalue = helper.formatMoney(helper, parseFloat(fieldvalue));
                    fieldvalue = localecode + " " + fieldvalue;
                    //console.log(fieldvalue);
                };
            	holdingdata[fieldname] = fieldvalue;
                };
           	
            masterdata[i]=holdingdata;
			};	
        
    },
    
    //Function used to format text literal into currency number
    formatMoney : function(helper, number) {
       			
        					var value = number;
    						var c = 2,
                            d = d == undefined ? "." : d,
                            t = t == undefined ? "," : t,
                            s = value < 0 ? "-" : "",
                            i = String(parseInt(value = Math.abs(Number(value) || 0).toFixed(c))),
                            j = (j = i.length) > 3 ? j % 3 : 0;
                          var callout = s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(value - i).toFixed(c).slice(2) : "");
                          
        return callout;
    },
    
    //Function used to order the fields sequence for tableheader
    compareDisplayOrder : function(helper, a, b) {
        const orderA = a.Display_Order__c;
        const orderB = b.Display_Order__c;
        console.log("hi")
        let comparison = 0
        if (orderA > orderB) {
            comparison = 1;
        } else if (orderA < orderB) {
            comparison = -1;
        }
        return comparison;
        
    }
	
})