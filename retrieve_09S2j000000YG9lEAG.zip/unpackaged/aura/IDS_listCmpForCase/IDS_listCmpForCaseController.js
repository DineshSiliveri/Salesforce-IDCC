({
    doInit: function (component, event, helper) {
        if(component.get("v.apiEndPoint")=='Retrieve_Activity_History'){
            var StartDate = component.get("v.StartDate");
            var EndDate = component.get("v.EndDate");
            
            //Only if the default date is null 
            if(StartDate == null || EndDate == null){
                helper.CalculateDate(component, event, helper);
            }
        }
        
        helper.subscribeEventChange(component,event, helper);
        helper.initialLoad(component,event, helper);
    },
    
    ShowAll: function (component, event, helper) {
        helper.ShowAllRecords(component,event, helper);
    },
    
    // Will relegate refreshing to doInit
    // recalculate: function (component, event, helper) {
    //     helper.InitialChecking(component,event, helper);
    // },
    
    Filter : function(component, event, helper) {
        //This function will only run for Activity History
        //Calculate the range of days before processing the callout
        var oneDay = 24*60*60*1000;
        var StartDate = new Date(component.get("v.StartDate"));
        var EndDate = new Date(component.get("v.EndDate"));
        var days = (EndDate-StartDate)/oneDay;
        
        //Number of days is fixed to be 60 days. It should never reach 61 days.
        if(days>60.99){
            component.set('v.DateRangeError', true);
        }
        else{
            component.set('v.DateRangeError', false);
            helper.CreateWrapper(component,event, helper);
        }
    },
    
    RefreshComponent: function (component, event, helper) {
        var a = component.get('c.doInit');
        $A.enqueueAction(a);
    }
    
})