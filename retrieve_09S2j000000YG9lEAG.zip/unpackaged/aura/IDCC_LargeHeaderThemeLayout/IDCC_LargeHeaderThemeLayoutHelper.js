({
	//This method will fetch user details and will be displayed
    userDetails: function(component, event){	
        var action = component.get("c.getUserDetails");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            console.log(state+'state');
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){                
                component.set('v.loggedInUser',response.getReturnValue());
                //Checking for the user type if it is not guest then multiple links will appear 
                //on header page
                if(result.UserType != "Guest"){
                    component.set("v.headerStyle", "LoggedInheaderStyle");
                    component.set("v.leftCol", "loggedInleftCol");
                    component.set("v.checkLoggedIn", true); 
                }
            }  else{
                console.log('Error in IDCC_SelfHelpHeader : doInit');
            }   
            
        });        
        $A.enqueueAction(action); 
    }, 
    
     //It will redirect to LoginPage of Community
    loginLink : function(component, event) {  
        window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/login/', '_self');     
    },
      //It will redirect to logout page
    logoutLink  :function(component, event) {
        window.location.replace($A.get("$Label.c.IDCC_CommunityURL")+"secur/logout.jsp");
    },
    openMobileTabHelper :function(component, event) {
        var menuToggle = component.get("v.menuToggle");
        var cmpTarget = component.find('header'); 
        if(menuToggle){
        component.set("v.isOpenPageBody",false);
        component.set("v.isOpenMobileTab",true); 
        component.set("v.menuToggle",false);
        $A.util.removeClass(cmpTarget, 'containerParent');
        $A.util.addClass(cmpTarget, 'newContainerParent');
        }
        else{
        component.set("v.isOpenPageBody",true);
        component.set("v.isOpenMobileTab",false); 
        component.set("v.menuToggle",true);
        $A.util.removeClass(cmpTarget, 'newcontainerParent');
        $A.util.addClass(cmpTarget, 'containerParent');
        }
          
               
       
   
    }
})