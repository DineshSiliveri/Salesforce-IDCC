({doInit: function(component, event, helper){
    //To fetch logged in user details
    helper.userDetails(component, event);
},
  personalLink : function(component, event) {  
      window.open($A.get("$Label.c.IDCC_CommunityPersonalLink"),'_top');       
  },
  handleDiscussion :function (component, event) {
      window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/discussionforumspage', '_self');
  },
  handleDeviceSimulator : function(component, event, helper) {
      window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/devicesimulatorpage/', '_self');  
  },
  businessLink : function(component, event) {  
      window.open($A.get("$Label.c.IDCC_CommunityBusinessLink"),'_top');       
  },
  
  investorRelLink : function(component, event) {  
      window.open($A.get("$Label.c.IDCC_CommunityInvestorRelationLink"),'_top');       
  },
  //This will redirect to selfHelpHomePage
  selfHelpHomePage :  function(component, event, helper) {   
      window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/'+$A.get("$Label.c.IDCC_Comm_SelfHelpHomePage	"), '_self'); 
  },
  //It will redirect to myCasesPage
  myCases: function(component, event, helper) {
      window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/'+$A.get("$Label.c.IDCC_Comm_SelfHelpLoginPage"), '_self');
  }, 
  //It will redirect to profile Page
  myProfile: function(component, event, helper) {
      window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/'+$A.get("$Label.c.IDCC_Comm_MyProfile")+'/'+$A.get( "$SObjectType.CurrentUser.Id"),'_self');
  },    
  //It will redirect to LoginPage of Community
  loginLink : function(component, event, helper) {        
      helper.loginLink(component, event);
  },
  //It will redirect to logout page
  logout:  function(component, event, helper) {   
      helper.logoutLink(component, event);
  },
  homeLink : function(component, event) { 
      component.find("navService").navigate(    {
          type: "comm__namedPage",
          attributes: {
              pageName: "home"
          }
      }    , true);
  },
  
   openMobileTab : function(component, event, helper) {  
     // alert('hi');
       helper.openMobileTabHelper(component, event);
  }
  
  
 })