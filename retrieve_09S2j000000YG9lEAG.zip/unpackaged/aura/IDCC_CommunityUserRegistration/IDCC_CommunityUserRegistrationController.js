({
    CancelReset: function (cmp, event, helper) { 
        cmp.set("v.mylabel","");
        cmp.set("v.openLoginPage",true);
        cmp.set("v.showRegPage",false);
        cmp.set("v.openSuccessMsgPage",false);
    },
    handleLogIn :function (cmp, event, helper) { 
        cmp.set("v.mylabel","");
        cmp.set("v.openLoginPage",true);
        cmp.set("v.showRegPage",false);
        cmp.set("v.openSuccessMsgPage",false);
    },
    validateUser: function (component, event, helper) {  
       component.set("v.mylabel","");
       helper.validateUser(component, event,helper);
    },
      // this function automatic call by aura:waiting event
    showSpinner: function (component,event, helper) {
        // make Spinner attribute true for display loading spinner
        component.set("v.Spinner1",true);
    },
    
    // this function automatic call by aura:doneWaiting event
    hideSpinner: function (component,event, helper) {
        // make Spinner attribute to false for hide loading spinner
        component.set("v.Spinner1",false);
    },
   
})