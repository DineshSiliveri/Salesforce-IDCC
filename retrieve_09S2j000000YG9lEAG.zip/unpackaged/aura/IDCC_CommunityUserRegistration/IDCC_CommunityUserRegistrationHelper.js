({
    validateUser : function(component, event, helper) {
        var fname = component.get("v.firstName");
        var validForm = component.find('FormVal').reduce(function (validSoFar,inputCmp) {
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;}, true);
        // If we pass error checking, do some real work
        if (validForm) {
            if(component.get("v.Password") != component.get("v.confPassword")){
                component.set("v.mylabel","Password is not matching, Please re-enter again");     
                component.set("v.Password","");
                component.set("v.confPassword","");
            }
            else{
                 this.checkMsisdn(component, event, helper);
               // this.checkExistingUser(component, event, helper);
            }    
        }
        
    },
    checkExistingUser :function(component, event, helper) {
        var action = component.get("c.checkExisitingUser");
        action.setParams({
            Email:component.get("v.Email")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state == "SUCCESS"){ 
                if(result){
                    component.set("v.mylabel",$A.get("$Label.c.IDCC_SelfRegErrorMsg"));       
                }
                else{
                    this.accoutnCreation(component, event, helper);    
                }
            }
            else{
                console.log('Error in IDCC_DeviceSimulatorComponentController : createUser');
            }
        });
        $A.enqueueAction(action);
    },
    
     
    checkMsisdn :function(component, event, helper) {
        var action = component.get("c.getAllPatterns");
        action.setParams({
            MSISDN:component.get("v.MSISDN")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state == "SUCCESS"){ 
                if(result){
                    component.set("v.MSISDNLabel",$A.get("$Label.c.IDCC_Community_MSISDN_Error_Message"));       
                }
                else{
                     component.set("v.MSISDNLabel","");
                     this.checkExistingUser(component, event, helper);
                }
            }
            else{
                console.log('Error in IDCC_DeviceSimulatorComponentController : createUser');
            }
        });
        $A.enqueueAction(action);
    },
    
    accoutnCreation :function(component, event, helper) {
        var action = component.get("c.PAccountCreation");
        action.setParams({
            firstName: component.get("v.firstName"),
            lastName :component.get("v.lastName"),
            Email:component.get("v.Email"),
            MSISDN :component.get("v.MSISDN")
        });
        // Add callback behavior for when response is received
        action.setCallback(this,function (response) {
            var state = response.getState();
            var rtnValue = response.getReturnValue();
            console.log('rtnValue'+rtnValue);
            console.log('state'+state);
            if (state === "SUCCESS"){
                if(!$A.util.isEmpty(rtnValue)){
                    component.set("v.AccountId",rtnValue);
                    this.createUser(component, event, helper);
                }
                else{
                    console.log('AccountId is null');    
                }
            }
            else{ 
                console.log('Error in IDCC_CommunityUSerRegistration : validateUser');
            }
        });
        $A.enqueueAction(action);	  
    },
    createUser :function(component, event, helper) {
        var action = component.get("c.createUser");
        action.setParams({
            Password :component.get("v.Password"),
            accId :component.get("v.AccountId"),
            Email:component.get("v.Email")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            console.log('state***'+state);
            if (state == "SUCCESS"){ 
                console.log('in success');
                component.set("v.Spinner1",true);
                this.getResult(component, event, helper);
            }
            else{
                console.log('Error in IDCC_DeviceSimulatorComponentController : createUser');
            }
        });
        $A.enqueueAction(action);
    },
    
    getResult :function(component, event, helper) {
        component.set("v.Spinner1",true);
        component.set("v.isDisabled",true);
        component.set("v.ProcessingText",'Processing Request.....');
        window.setTimeout(
            $A.getCallback(function() {
                console.log('Timeout');
                component.set("v.isDisabled",false);
                component.set("v.ProcessingText",'');
                var action = component.get("c.createresultMap");
                action.setParams({
                    Password :component.get("v.Password"),
                    Email:component.get("v.Email")
                });
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    var result = response.getReturnValue();
                    if (state == "SUCCESS"){
                        for(var key in result){
                            console.log('Key----'+key+'Result---'+result[key]);
                            if(key== 'Success'){
                                component.set("v.mylabel","");
                                component.set("v.showRegPage",false);
                                component.set("v.openLoginPage",false);
                                component.set("v.openSuccessMsgPage",true);
                            }
                            else if( key =='Error'){   
                                component.set("v.mylabel",result[key]);   
                            }
                        }
                    }
                    else{
                        console.log('Error in IDCC_DeviceSimulatorComponentController : createUser');
                    }
                });
                 $A.enqueueAction(action);
            }), 10000
        );
       
    }
})