({
	thresholdStatus : function(component, event, helper) {
		var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Threshold_Status&resObjName=Query_Threshold_status_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
	},
    
    customerNtwkInfo : function(component, event, helper) {
		
        var recordId = component.get("v.recordId");
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleNeometricsForm?resObjName=Get_Netmetrics_Info_Res&apiName=Get_Neometrics_Info&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
	},
    
    customerInternetSpeed : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleNeometricsFormLocation?recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
	},
    customerDeviceInfoADM : function(component, event, helper) {
		var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleForm");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Customer_Device_Info_ADM&resObjName=Query_Customer_Device_Info_ADM_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
	},
})