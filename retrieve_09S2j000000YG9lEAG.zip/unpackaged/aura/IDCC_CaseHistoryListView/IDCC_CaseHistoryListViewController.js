({
    
    getCaseHistory : function(component, event, helper) {
        helper.getCaseHistory(component);//get data from the helper
        helper.showUpdatestoSupervisor(component);
    },
    showAllUpdates : function(component, event, helper) {
        component.set("v.allUpdates", !component.get("v.allUpdates"));
        //alert(component.get("v.allUpdates"));
        helper.showAllUpdates(component);//get data from the helper
    },
    showUpdatestoSupervisor : function(component, event, helper) {
        helper.showUpdatestoSupervisor(component);//get data from the helper
    }
})