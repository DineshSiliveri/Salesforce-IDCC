({
    getCaseHistory : function(component) {
        console.log('recordId***'+component.get("v.recordId"));
        var action = component.get("c.getCaseHistoryList");//get data from controller       
        action.setParams({"caseID": component.get("v.recordId")});
        action.setCallback(this, function(a) {
            component.set("v.CaseHistory", a.getReturnValue());//set data in the page variable  
            
        });
        $A.enqueueAction(action);
    },
    showAllUpdates : function(component) {
        
        var action = component.get("c.getCaseHistoryListAll");//get data from controller
        action.setParams({"caseID": component.get("v.recordId")}); 
        action.setCallback(this, function(a) {
            component.set("v.CaseHistoryAllUpdates", a.getReturnValue());//set data in the page variable              
        });
        $A.enqueueAction(action);
    },
    showUpdatestoSupervisor  : function(component)
    {
        //alert('inside super');
        var action = component.get("c.showAllUpdatesToSupervisor");//get data from controller
        action.setCallback(this, function(a) {
            component.set("v.supervisorAllUpdates", a.getReturnValue());//set data in the page variable              
        });
        $A.enqueueAction(action);
    }
})