({
    getLevel2Data : function(component, event, helper) {
        var action = component.get("c.getLevel2NameLst");
        action.setParams({selectedLevel2DeviceId : component.get("v.level2DeviceId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                var imageURLLevel2NameLst = [];
                var imageURLLevel2 =[];
                for(var key in result){
                    imageURLLevel2NameLst.push({value:result[key].Name, key:result[key].Id});
                    imageURLLevel2.push({value:result[key], key:key});
                }
                component.set("v.level2Lst", imageURLLevel2NameLst);
                component.set("v.imageURLLevel2Lst", imageURLLevel2);
                helper.getLevel3Data(component, event, helper);
            }
            else{
                console.log('Error in IDCC_DeviceSimulatorLevel3 : getLevel2Data');
            }
        });
        $A.enqueueAction(action);
    },
    getLevel3Data : function(component, event, helper) {
        var action = component.get("c.getLevel3DeviceSimulator");
        action.setParams({selectedLevel2DeviceId : component.get("v.level2DeviceId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if(state === "SUCCESS"){
                if($A.util.isEmpty(result)){
                    component.set("v.imageURLLevel3Lst", null);    
                }
                else{
                    component.set('v.level3DeviceToAttchMap',response.getReturnValue());
                    var imageURLLevel3WithObj = [];
                    var imageURLLevel3 = [];
                    for(var key in result){
                        if(result[key].Name.includes('-')){
                            var name = result[key].Name.split('-');
                            imageURLLevel3.push({value:name[0], key:key}); 
                        } 
                        else{
                            imageURLLevel3.push({value:result[key].Name, key:key});    
                        }
                        imageURLLevel3WithObj.push({value:result[key], key:key});    
                    }
                    component.set("v.imageURLLevel3Lst", imageURLLevel3);
                    component.set("v.imageURLLevel3WithObj", imageURLLevel3WithObj);
                    console.log('imageURLLevel3Lst---------------'+imageURLLevel3);    
                }
            }
            else{
                console.log('Error in IDCC_DeviceSimulatorLevel3 : getLevel3Data');
            }
        });
        $A.enqueueAction(action);	
    },
})