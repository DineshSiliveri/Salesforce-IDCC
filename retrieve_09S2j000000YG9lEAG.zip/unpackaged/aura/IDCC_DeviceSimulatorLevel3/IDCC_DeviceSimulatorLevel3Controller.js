({
    //Init mehtod
    doInit : function(component, event, helper){
        helper.getLevel2Data(component, event, helper);
        component.set("v.openLevel3Local",true);
    },
    // On click handler of Images of Level3
    clickHandler : function(component, event, helper) {
        var deviceId = event.currentTarget.dataset.id;
        component.set("v.selectedLevel3DeviceId",deviceId);
        var lst = component.get("v.imageURLLevel3WithObj");
        for(var imageURL in lst){
            if(lst[imageURL].value.Id == deviceId){
                var name = lst[imageURL].value.Name.split('-');
                component.set("v.selectedLevel3ImageName",name[0]); 
                break;
            }
        }
        component.set("v.openLevel3Local",false);
        component.set("v.openLevel4", true);
    },
    //Method for event handling of IDCC_Level4ToLevel3Event
    handleBackButton :function(component, event, helper) {
        var recordId = event.getParam("recordId");
        component.set("v.level2DeviceId",recordId);
        component.set("v.openLevel4", false);
        component.set("v.openLevel3", true);
        component.set("v.openLevel3Local", true);
    },
    //method for event handling of handling menu buton
    handleMenuSelect: function(component, event, helper) {
        var selectedMenuId = event.detail.menuItem.get("v.value");
        component.set("v.level2DeviceId",selectedMenuId);
        var menuItems = component.find("menuItems");
        menuItems.forEach(function (menuItem) {
            if (menuItem.get("v.checked")) {
                menuItem.set("v.checked", false);
            }
            if (menuItem.get("v.value") === selectedMenuId) {
                menuItem.set("v.checked", true);
            }
        });
        var lst = component.get("v.imageURLLevel2Lst");
        for(var imageURL in lst){
            if(lst[imageURL].value.Id == selectedMenuId){
                component.set("v.selectedLevel2imageURL",lst[imageURL].key);  
                component.set("v.selectedLevel2ImageName",lst[imageURL].value.Name); 
                break;
            }
        }
        helper.getLevel3Data(component, event, helper);
    },
    handleDropDownEvent : function(component, event, helper) {
        var recordId = event.getParam("recordId");
        component.set("v.level2DeviceId", recordId);
        helper.getLevel3Data(component, event, helper);
        var lst = component.get("v.imageURLLevel2Lst");
        for(var imageURL in lst){
            if(lst[imageURL].value.Id == recordId){
                component.set("v.selectedLevel2imageURL",lst[imageURL].key);  
                component.set("v.selectedLevel2ImageName",lst[imageURL].value.Name); 
                break;
            }
        }
        component.set("v.openLevel4", false);
        component.set("v.openLevel3", true);
        component.set("v.openLevel3Local", true);
    }
})