({   doInit: function(component, event, helper){     
    //Based on URL it will fetch page details and link color will apperar accordingly
    helper.pageDetails(component, event);
    //To fetch logged in user details
    helper.userDetails(component, event);
},
  //It will redirect to DeviceSimulatorPage
  handleDeviceSimulator : function(component, event, helper) {   
      window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/'+$A.get("$Label.c.IDCC_Comm_DeviceSimulatorPage"), '_self'); 
  },
  //This will redirect to selfHelpHomePage
  selfHelpHomePage :  function(component, event, helper) {   
      window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/'+$A.get("$Label.c.IDCC_Comm_SelfHelpHomePage	"), '_self'); 
  },
  //It will redirect to myForumPAge
  handleForum: function(component, event, helper) {
      window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/'+$A.get("$Label.c.IDCC_Comm_DiscForumPage"), '_self');
  },
  //It will redirect to myCasesPage
  myCases: function(component, event, helper) {
      window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/'+$A.get("$Label.c.IDCC_Comm_SelfHelpLoginPage"), '_self');
  }, 
  //It will redirect to profile Page
  myProfile: function(component, event, helper) {
      window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/'+$A.get("$Label.c.IDCC_Comm_MyProfile")+'/'+$A.get( "$SObjectType.CurrentUser.Id"),'_self');
  },  
  //It will redirect to Personal Link provided by Indosat
  personalLink : function(component, event, helper) {        
      helper.personalLink(component, event);
  },
  //It will redirect to Business Link provided by Indosat
  businessLink : function(component, event, helper) {        
      helper.businessLink(component, event);
  },
  //It will redirect to Investor Link provided by Indosat
  investorRelLink : function(component, event, helper) {        
      helper.investorRelLink(component, event);
  },
  //It will redirect to home page of community
  homeLink : function(component, event, helper) { 
      helper.homeLink(component, event);
  },
  //It will redirect to LoginPage of Community
  loginLink : function(component, event, helper) {        
      helper.loginLink(component, event);
  },
  //It will redirect to logout page
  logout:  function(component, event, helper) {   
      helper.logoutLink(component, event);
  },
  openMobileTab : function(component, event, helper) {  
     // alert('hi');
       helper.openMobileTabHelper(component, event);
  }
 })