({
	caseDetail : function(cmp,event,helper) {
    
        cmp.set("v.selectedIcon","icon1");
        this.iconBackground(cmp);
    },


	customerProfile : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon3");
        this.iconBackground(cmp);
    },
    issueEntry : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon2");
        this.iconBackground(cmp);
    },
    
    prepaid : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon9");
        this.iconBackground(cmp);
    },
    
    postpaid : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon10");
        this.iconBackground(cmp);
    },
    
    assetPrepaid : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon5");
        this.iconBackground(cmp);
    },
    
    assetPostpaid : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon5");
        this.iconBackground(cmp);
    },
    
    caseHistory : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon5");
        this.iconBackground(cmp);
    },
    
     socialPersona : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon7");
        this.iconBackground(cmp);
    },
     neoMetrics : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon11");
        this.iconBackground(cmp);
    },
    
    vas : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon12");
        this.iconBackground(cmp);
    },
    
    hadoop : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon7");
        this.iconBackground(cmp);
    },
    charging : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon13");
        this.iconBackground(cmp);
    },
    campaign : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon14");
        this.iconBackground(cmp);
    },
    vlr : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon15");
        this.iconBackground(cmp);
    },
    feed : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon1");
        this.iconBackground(cmp);
    },
    callTransaction : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon6");
        this.iconBackground(cmp);
    },
     //Added by Komal
    adjustmentHistoryHelper : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon16");
        this.iconBackground(cmp);
    },
    generalInformationHelper : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon17");
        this.iconBackground(cmp);
    },
    healthCheck: function(cmp,event,helper) {
     cmp.set("v.selectedIcon","icon8");
      this.iconBackground(cmp);  
    },
    quickLinks: function(cmp,event,helper) {
     cmp.set("v.selectedIcon","icon12");
      this.iconBackground(cmp);  
    },
    //End by Komal
    //Add by prm
    billAccount : function(cmp,event,helper) {
        cmp.set("v.selectedIcon","icon4");
        this.iconBackground(cmp);
    },
    //End by prm
    // change icon background color for selected icon
        
    iconBackground : function(component){ 
        
		// icons default background color    
     	component.set("v.icon1", "menu-icons");
        component.set("v.icon2", "menu-icons");
        component.set("v.icon3", "menu-icons");
        component.set("v.icon4", "menu-icons");
        component.set("v.icon5", "menu-icons");
        component.set("v.icon6", "menu-icons");
        component.set("v.icon7", "menu-icons");
        component.set("v.icon8", "menu-icons");
        component.set("v.icon9", "menu-icons");
        component.set("v.icon10", "menu-icons");
        component.set("v.icon11", "menu-icons");
        component.set("v.icon12", "menu-icons"); 
        component.set("v.icon13", "menu-icons");
        component.set("v.icon14", "menu-icons");
        // Start by prm
         component.set("v.icon15", "menu-icons");
        // End by prm
        // Start by Komal
         component.set("v.icon16", "menu-icons");
         component.set("v.icon17", "menu-icons");
        // End by Komal
        if(component.get("v.selectedIcon")=="icon1"){
        	component.set("v.icon1", "menu-icons_y"); 
           
        }else if(component.get("v.selectedIcon")=="icon2"){
        	component.set("v.icon2", "menu-icons_y"); 
           
        }else if(component.get("v.selectedIcon")=="icon3"){
        	component.set("v.icon3", "menu-icons_y"); 
           
        }else if(component.get("v.selectedIcon")=="icon4"){
        	component.set("v.icon4", "menu-icons_y");
           
        }else if(component.get("v.selectedIcon")=="icon5"){
        	component.set("v.icon5", "menu-icons_y");   
        }else if(component.get("v.selectedIcon")=="icon6"){
        	component.set("v.icon6", "menu-icons_y"); 
              
        }else if(component.get("v.selectedIcon")=="icon7"){
        	component.set("v.icon7", "menu-icons_y");   
        }else if(component.get("v.selectedIcon")=="icon8"){
        	component.set("v.icon8", "menu-icons_y");   
        }else if(component.get("v.selectedIcon")=="icon9"){
        	component.set("v.icon9", "menu-icons_y");   
        }else if(component.get("v.selectedIcon")=="icon10"){
        	component.set("v.icon10", "menu-icons_y");   
        }else if(component.get("v.selectedIcon")=="icon11"){
        	component.set("v.icon11", "menu-icons_y");   
        }else if(component.get("v.selectedIcon")=="icon12"){
        	component.set("v.icon12", "menu-icons_y");   
        }else if(component.get("v.selectedIcon")=="icon13"){
        	component.set("v.icon13", "menu-icons_y");   
        }else if(component.get("v.selectedIcon")=="icon14"){
        	component.set("v.icon14", "menu-icons_y");   
        }else if(component.get("v.selectedIcon")=="icon15"){
            component.set("v.icon15", "menu-icons_y");   
        }else if(component.get("v.selectedIcon")=="icon16"){
            component.set("v.icon16", "menu-icons_y");   
        }else if(component.get("v.selectedIcon")=="icon17"){
        	component.set("v.icon17", "menu-icons_y");   
        }else if(component.get("v.selectedIcon")=="icon18"){
        	component.set("v.icon18", "menu-icons_y");   
        }
       // End by Komal.
},
})