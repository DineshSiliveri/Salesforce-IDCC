({
    
    init :function(cmp,event,helper, handler){
        var action = cmp.get("c.getCaseData");
        action.setParams({recordId : cmp.get("v.recordId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS"){
                cmp.set("v.caseRec",result);
            }
            else{
                console.log('Error in IDCC_ConeIcon : init');
            }
        });
        $A.enqueueAction(action);
        
    },
    caseDetail: function(cmp,event,helper, handler){
        
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "CASEDETAILS" } );
        appEvent.fire(); 
        helper.caseDetail(cmp,event,helper);
        
    },
    
    customerProfile: function(cmp,event,helper){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "CUSTOMERPROFILE" } );
        appEvent.fire();
        helper.customerProfile(cmp,event,helper);
        
    },
    
    caseHistory: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "CASEHISTORY" } );
        appEvent.fire();
        helper.caseHistory(cmp,event,helper);
    },
    
    socialPersona: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "SOCIALPERSONA" } );
        appEvent.fire();
        helper.socialPersona(cmp,event,helper);
    },
    
    prepaid: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "PREPAID" } );
        appEvent.fire();
        helper.prepaid(cmp,event,helper);
    },
    
    postpaid: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "POSTPAID" } );
        appEvent.fire();
        helper.postpaid(cmp,event,helper);
    },
    
    assetPrepaid: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "ASSETPREPAID" } );
        appEvent.fire();
        helper.assetPrepaid(cmp,event,helper);
    },
    
    assetPostpaid: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "ASSETPOSTPAID" } );
        appEvent.fire();
        helper.assetPostpaid(cmp,event,helper);
    },
    
    //Added for Neometric Login Page
    //Added by Dinesh --04/08/2020
    neoMetrics: function(cmp,event,helper,handler){
        var urlEvent = $A.get("e.force:navigateToURL");
        var urlValue =$A.get("$Label.c.IDCC_NeoMetrics_URL");
        urlEvent.setParams({
            "url": urlValue 
        });
        urlEvent.fire();
    },
    
    vas: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "VAS" } );
        appEvent.fire();
        helper.vas(cmp,event,helper);
    },
    
    hadoop: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "HADOOP" } );
        appEvent.fire();
        helper.hadoop(cmp,event,helper);
    },
    
    charging: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "CHARGING" } );
        appEvent.fire();
        helper.charging(cmp,event,helper);
    },
    
    campaign: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "CAMPAIGN" } );
        appEvent.fire();
        helper.campaign(cmp,event,helper);
    },
    
    vlr: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "vlr" } );
        appEvent.fire();
        helper.vlr(cmp,event,helper);
    },
    
    feed: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "feed" } );
        appEvent.fire();
        helper.feed(cmp,event,helper);
    }, 
    //Added by Komal
    adjustmentHistory: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "AdjustmentHistory" } );
        appEvent.fire();
        helper.adjustmentHistoryHelper(cmp,event,helper);
    },
    generalInfo: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "GeneralInformation" } );
        appEvent.fire();
        helper.generalInformationHelper(cmp,event,helper);
    },
    //end added by Komal
    // start add by prm.
    billAccount: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "Billing Account" } );
        appEvent.fire();
        helper.billAccount(cmp,event,helper);
    },
    issueEntry: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "IssueEntry" } );
        appEvent.fire();
        helper.issueEntry(cmp,event,helper);
    },
    
    // End add by prm    
    callTransaction: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "callTransaction" } );
        appEvent.fire();
        helper.callTransaction(cmp,event,helper);
    }, 
    healthCheck: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "healthCheck" } );
        appEvent.fire();
        helper.healthCheck(cmp,event,helper);
    },
    quickLinks: function(cmp,event,helper,handler){
        var appEvent = $A.get("e.c:AgentUIEvent");
        appEvent.setParams( { "iconClicked" : "QuickLinks" } );
        appEvent.fire();
        helper.quickLinks(cmp,event,helper);
    },
    scrollLeft: function(component, event, helper) {
        //   $(document).ready(function() { 
        
        if (window.matchMedia('screen and (min-width: 500px) and (max-width: 1280px)').matches) {
            for(var i=8; i<18; i++){
                //	$("#icon_"+i).hide(); 
                if(document.getElementById('icon_'+i) != null){   
                    document.getElementById('icon_'+i).style.display = 'none';
                }
            }
            for(var i=1; i<8; i++){
                //	$("#icon_"+i).show();
                if(document.getElementById('icon_'+i) != null){  
                    document.getElementById('icon_'+i).style.display = 'block';
                }
            }  
            
        }else if (window.matchMedia('screen and (min-width: 1280px)').matches) {
            for(var i=10; i<18; i++){
                //	$("#icon_"+i).hide();  
                if(document.getElementById('icon_'+i) != null){  
                    document.getElementById('icon_'+i).style.display = 'none';
                }
            }
            for(var i=1; i<10; i++){
                //	$("#icon_"+i).show();
                if(document.getElementById('icon_'+i) != null){  
                    document.getElementById('icon_'+i).style.display = 'block';
                }
            }  
        }
        
        component.set("v.prev", "prev");
        component.set("v.next", "next_y");
        
        //   }); 
    },
    scrollRight: function(component, event, helper) {
        //    $(document).ready(function() { 
        
        if (window.matchMedia('screen and (min-width: 500px) and (max-width: 1280px)').matches) {
            for(var i=8; i<18; i++){
                //	$("#icon_"+i).hide(); 
                if(document.getElementById('icon_'+i) != null){   
                    document.getElementById('icon_'+i).style.display = 'block';
                }
            }
            for(var i=1; i<8; i++){
                //	$("#icon_"+i).show();
                if(document.getElementById('icon_'+i) != null){  
                    document.getElementById('icon_'+i).style.display = 'none';
                }
            }  
            
        }else if (window.matchMedia('screen and (min-width: 1280px)').matches) {
            // below updated  from 15 to 16
            for(var i=10; i<18; i++){
                //	$("#icon_"+i).hide();
                if(document.getElementById('icon_'+i) != null){    
                    document.getElementById('icon_'+i).style.display = 'block';
                }
            }
            for(var i=1; i<10; i++){
                //	$("#icon_"+i).show();
                if(document.getElementById('icon_'+i) != null){  
                    document.getElementById('icon_'+i).style.display = 'none';
                }
            }  
        }
        
        
        component.set("v.prev", "prev_y");
        component.set("v.next", "next");
        
        //     });
    },
    
    /*  doInit : function(component, event, helper) {
     
     if (window.matchMedia('screen and (min-width: 500px) and (max-width: 1280px)').matches) {
         // var x = document.getElementById("hideDisplay"); 
         // var y = x.getElementsByClassName("menu-icons");
         for(var i=10; i<18; i++){
            	//	$("#icon_"+i).hide();
            	if(document.getElementById('icon_'+i) != null){  
            	document.getElementById('icon_'+i).style.display = 'none';
                }
            	}
        for(var i=1; i<10; i++){
            	//	$("#icon_"+i).show();
            if(document.getElementById('icon_'+i) != null){
              document.getElementById('icon_'+i).style.display = 'block';  
            }
                 
            	}  
        
     }else if (window.matchMedia('screen and (min-width: 1280px)').matches) {
         //Added by prm updated from 15 to 16
          for(var i=10; i<18; i++){
            	if(document.getElementById('icon_'+i) != null){ 
            	document.getElementById('icon_'+i).style.display = 'none';
                }
            	}
        for(var i=1; i<10; i++){
            if(document.getElementById('icon_'+i) != null){
                 document.getElementById('icon_'+i).style.display = 'block';
            }
            	}  
     }
        component.set("v.prev", "prev");
        component.set("v.next", "next_y"); 
    }, */
    
    
})