({
    init: function (cmp, event, helper) { 
        helper.getCaseComments(cmp, event, helper);
    },
    
    //method to create new case comment
     createNewComments : function(component, event, helper){
        helper.createCaseCommentsHandler(component, event, helper); 
    },
        
	handleToastEvent  : function (cmp, event, helper) {
        var eventType = event.getParam('type');
        var eventMessage= event.getParam('message');
        if(eventType == 'SUCCESS' && eventMessage.includes(cmp.get('v.sobjectLabel'))){
            helper.getCaseComments(cmp, event, helper)
            //helper.fetchData(cmp, event, helper)
        	event.stopPropagation();            
        }        
	},
    
    cancelCaseComment : function(component, event, helper) {
        component.set("v.caseComment",''); 
    },
    
        
    
})