({
    getCaseComments : function(component, event, helper) {
        var action = component.get("c.getCaseComments");
        action.setParams({  
            "recordId":component.get("v.recordId")  
        });      
        action.setCallback(this,function(response){  
            var state = response.getState(); 
            if(state=='SUCCESS'){  
                var result = response.getReturnValue();
                component.set("v.caseComments",result);
                if(result == null){
                    component.set("v.caseCommentLstSize",0);     
                }else{
                    component.set("v.caseCommentLstSize",result.length); 
                }
            }  
            else{
                console.log('Error in getFileData ---');
            }
        });          
        $A.enqueueAction(action); 
    },
    createCaseCommentsHandler: function(component, event, helper) {
        var action = component.get("c.createCaseComment");
        action.setParams({  
            "recordId":component.get("v.recordId"),
            "commentBody" :component.get("v.caseComment")
        });      
        action.setCallback(this,function(response){  
            var state = response.getState(); 
            if(state=='SUCCESS' && component.isValid()){
                $A.get('e.force:refreshView').fire();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "type" : "success",
                    "message": "Case Comment added successfully"
                });
                toastEvent.fire();
                component.set("v.caseComment",'');
                helper.getCaseComments(component, event, helper)
            }  
            else{
                console.log('Error in getFileData ---');
            }
        });          
        $A.enqueueAction(action); 
    },         
})