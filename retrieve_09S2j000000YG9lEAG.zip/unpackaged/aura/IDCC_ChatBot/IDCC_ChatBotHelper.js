({
    helperMethod : function() {
        
    },
    gotoURL : function (component, event) {
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "https://indira2.indosatooredoo.com:6569/client"
        });
        urlEvent.fire();
        
        // window.open(href="https://indira2.indosatooredoo.com:6569/client" , '_parent' );
       
    }
})