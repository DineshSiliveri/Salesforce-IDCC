({
    doInit : function(component, event, helper){
        //alert("before");
        // component.set("v.test", "https://indira2.indosatooredoo.com:6569/client");
        // alert("after");
    },
    
    doSomething : function(component,event, helper) {  
        //call_chat();
        helper.gotoURL(component,event);
       // var href = "https://indira2.indosatooredoo.com:6569/client";       
       // window.open(href="https://indira2.indosatooredoo.com:6569/client" , '_blank' );
    } 
})