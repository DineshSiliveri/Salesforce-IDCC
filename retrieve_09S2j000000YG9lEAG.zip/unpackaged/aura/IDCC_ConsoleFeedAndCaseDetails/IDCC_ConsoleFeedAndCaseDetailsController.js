({
	init : function(component, event, helper) {
         //Calling helper method on init action
        helper.showCaseDetails(component, event);
    },
})