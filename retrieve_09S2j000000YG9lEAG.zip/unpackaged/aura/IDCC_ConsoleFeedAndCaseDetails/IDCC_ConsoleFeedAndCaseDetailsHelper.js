({
    //This method is called on init action to fetch Case data and it is setting columns to be shown
    //on 'Previous Case' tabs
    showCaseDetails : function(component, event) {
        //This is used to set columns to be shown on 'Previous Cases'tabs
        component.set('v.caseColumns', [
            { label: 'Case', fieldName: 'LinkName', type: 'url', typeAttributes: {label: { fieldName: 'CaseNumber' }, target: '_top'} },
            { label: 'Case Origin', fieldName: 'Origin', type:"text"},
            { label: 'Status', fieldName: 'Status', type:"text"},
            { label: 'Subject', fieldName: 'Subject', type:"text"},
            { label: 'Priority', fieldName: 'Priority', type: 'text' },
            { label: 'Activity Code', fieldName: '', type: 'url' }
        ]);
        
        component.set('v.filesColumns', [
            { label: 'Case', fieldName: 'LinkName', type: 'url', typeAttributes: {label: { fieldName: 'ParentId' }, target: '_top'} },
            { label: 'ContentSize', fieldName: 'ContentSize', type: 'integer' }
        ]);    
        
        component.set('v.caseMilestone', [            
            { label: 'Name', fieldName: 'LinkName', type: "url", typeAttributes: {label: { fieldName: 'MilestoneType_Name' }, target: '_top'} },
            { label: 'Start Date', fieldName: 'StartDate', type: "dateTime" },
            { label: 'Target Date', fieldName: 'TargetDate', type: "dateTime" },
            { label: 'Completion Date', fieldName: 'CompletionDate', type: "dateTime" },
            { label: 'Time Remaining(Min:Sec)', fieldName: 'TimeRemainingInMins', type: "text" },
            { label: 'Completed', fieldName: 'IsCompleted', type: "boolean" },
            { label: 'Violation', fieldName: 'IsViolated', type: "boolean" }
        ]) ;   
        
        component.set('v.caseSurvey', [            
            { label: 'Name', fieldName: 'LinkName', type: "url", typeAttributes: {label: { fieldName: 'Name' }, target: '_top'} },
            { label: 'Response Status', fieldName: 'ResponseStatus', type: "text" }
        ]) ;   
        
        
        
        var action = component.get("c.setViewStat"); 
        //var actionLayout = component.get("c.casePageLayout"); 
        var caseId = component.get("v.recordId");
        action.setParams({
            "caseId":caseId
        });
        
        action.setCallback(this, function(response) {
            component.set('v.caseData', response.getReturnValue()); 
        });
        // Queue this action to send to the server
        $A.enqueueAction(action); 
    },
    
})