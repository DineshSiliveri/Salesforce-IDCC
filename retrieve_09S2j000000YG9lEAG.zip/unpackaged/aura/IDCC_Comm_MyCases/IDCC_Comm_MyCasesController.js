({
    doInit : function(component, event, helper) { 
        var page = component.get("v.page") || 1;
        var action = component.get("c.getUserDetails");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                component.set('v.loggedInUser',response.getReturnValue());
                helper.getCasesDetails(component, event, page);
            }
            else{
                console.log('Error in IDCC_Comm_MyCases : doInit');
            }
        });
        $A.enqueueAction(action); 	
    },
    handleCreateCaseModal : function(component, event, helper) {
        component.set("v.isOpenModal", true);
    },
    closeModel : function(component, event, helper) {
        component.set("v.isOpenModal", false);
    },
    createCase : function(component, event, helper) {
		helper.handleCreateCase(component, event, helper);
    } ,
    navigate: function(component, event, helper) {
        // this function call on click on the previous page button  
        var page = component.get("v.page") || 1;
        // get the previous button label  
        var direction = event.getSource().get("v.label");
        // set the current page,(using ternary operator.)  
        page = direction === "Previous Page" ? (page - 1) : (page + 1);
        console.log('page****'+page);
        component.set('v.pageNum', page - 1);
        console.log('pageNum'+component.get("v.pageNum"));
       
        helper.getCasesDetails(component, event, page);
        console.log('abc**');
    }
  
})