({
    getCasesDetails : function(component, event, page) {
        console.log('page**'+page);
        var loogedInUser = component.get('v.loggedInUser');
        var action = component.get("c.getCaseDetails");
        action.setParams({"accountId": loogedInUser.Contact.AccountId,
                          "pageNumber": page,
                          "status" : component.find('select').get('v.value')}); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS" ){
                if(!$A.util.isEmpty(result)){
                    component.set('v.cases',result.cseList);
                    component.set('v.totalCases',result.caseTotalList);
                    // component.set('v.cases',result.total);
                    component.set("v.page", result.page);
                    console.log('page$$$$'+  component.get("v.page"));
                    component.set("v.pageSize",result.pageSize);
                    component.set("v.total", result.total);
                    console.log('Total***'+result.total);
                    if(result.total == 0 ){  
                        component.set("v.pages", 1);
                    }
                    else if(result.total != 0){
                        component.set("v.pages", Math.ceil(result.total/10 ));
                    }
                    //alert(component.get("v.cases"));
                    console.log('Total***'+ component.get("v.total"));
                    console.log('Page Size***'+ result.pageSize);  
                    this.getCountOfStatus(component, event,result.total,result.page);
                }else{
                    component.set("v.total", 0);
                    component.set("v.totalCases", 0);
                    component.set("v.cases", null);  
                    component.set('v.csStCount',0);
                }
            }
            else{ 
                console.log('Error in IDCC_Comm_MyCases : getCasesDetails');
            }
        });
        $A.enqueueAction(action); 	
    },
    getCountOfStatus :function(component, event,total,page) {
        var cases = component.get('v.totalCases');       
        console.log('total length'+cases.length);
        var newCaseCnt = 0;
        var inProgressCnt = 0;
        var closedCnt = 0;
        var caseCount = cases.length;
        var status = component.find('select').get('v.value');
        console.log('total status'+total);
        for(var i = 0; i < caseCount; i++){
            if(cases[i].Status == 'New' || cases[i].Status == 'Open'){                
                newCaseCnt = newCaseCnt + 1;    
            }
            else if(cases[i].Status == 'In Progress' || cases[i].Status == 'Process'){
                console.log('process status');
                inProgressCnt = inProgressCnt + 1;        
            }
                else if(cases[i].Status == 'Closed' ||  cases[i].Status == 'Cancel'){
                    console.log('closed status');
                    closedCnt = closedCnt +1;        
                }
        } 
        if(component.find('select').get('v.value') =='Open'){
            component.set('v.csStCount',newCaseCnt);
        }else if(component.find('select').get('v.value') =='In Progress'){
            component.set('v.csStCount',inProgressCnt);
        }else if(component.find('select').get('v.value') =='Closed'){
            component.set('v.csStCount',closedCnt);
        }else if(component.find('select').get('v.value') =='All'){
            component.set('v.csStCount',caseCount);
        }
        component.set('v.caseCount',caseCount);
        component.set('v.newCnt',newCaseCnt);
        component.set('v.inProgressCnt',inProgressCnt);
        component.set('v.closedCnt',closedCnt);
    },
    handleCreateCase : function(component, event, helper) {
        var allValid = component.find('fieldId').reduce(function (validSoFar, inputCmp) {
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && !inputCmp.get('v.validity').valueMissing;
        }, true);
        if(allValid) {
            var loogedInUser = component.get('v.loggedInUser');
            var action = component.get("c.createNewCase");
            action.setParams({
                "accountId" : loogedInUser.Contact.AccountId,
                "newCase": component.get("v.newCase")
            }); 
            action.setCallback(this, function(response) {
                var state = response.getState();
                var result = response.getReturnValue();
                if (state === "SUCCESS" && !$A.util.isEmpty(result)){
                    component.set("v.isOpenModal", false);
                    $A.get('e.force:refreshView').fire();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "type": "success",
                        "message": "Case Created Successfully"
                    });
                    toastEvent.fire();
                }
                else{
                    console.log('Error in IDCC_Comm_MyCases : handleCreateCase');
                }
            });
            $A.enqueueAction(action); 	    
        }
    }
    
})