({
    
    getBroadcastList: function(component) {
        var action = component.get('c.getBroadcasts');
        component.get("v.resetList",false);
        
        if(action!=undefined){
            action.setCallback(this, function(actionResult) {
                
                var state = actionResult.getState();    
                
                if (state == "SUCCESS")  
                {
                    var statusCheck = actionResult.getReturnValue();
                    if(statusCheck!=null || statusCheck!=undefined){
                        //console.log("statusCheck"+statusCheck);
                        var broadcast=[];
                        var item = {};	           
                        for(var i = 0; i<statusCheck.length;i++){
                            item = {};
                            item["message"] = statusCheck[i].message;
                            item["logo"] = statusCheck[i].messageStatus;
                            item["id"] = statusCheck[i].messageId;
                            item["bURL"] = statusCheck[i].bURL;
                            
                            if(statusCheck[i].activityCode !=null){
                             item["actCode"] = statusCheck[i].activityCode;
                            }
                            else {
                                item["actCode"] = '';
                            }
                            if(statusCheck[i].timeDuration!=null){
                                item["duration"] = statusCheck[i].timeDuration;
                            }else{
                                item["duration"] = 10000;
                            }
                            /*
                            if(statusCheck[i].messageStatus==true){
                                item["duration"] = 5000;
                            }
                            else{
                                item["duration"] = 10000;
                            }
                            */
                            broadcast.push(item);
                        }
                        
                        //  console.log(broadcast);
                        component.set('v.broadcasts', broadcast);
                        var j=0;
                        console.log("broadcast message"+JSON.stringify(broadcast[j]));
                        var timeoutids = [];
                        function myloop(j) {
                            var reset = component.get("v.resetList");
                            j++;
                            if(!reset){
                                if(broadcast[j-1]!=undefined){
                                    var timeoutid = window.setTimeout(function () {
                                        $('#ticker_01 li:first').fadeOut( 
                                            function () { $(this).appendTo($('#ticker_01')).fadeIn();}
                                        );  
                                        if(j<10 && j<broadcast.length){
                                            myloop(j);
                                        }else {
                                            j=0;
                                            myloop(j);
                                        }
                                    }, broadcast[j-1].duration);
                                }
                                //console.log("timeoutid"+timeoutid);
                                timeoutids.push(timeoutid);
                               // console.log("helper timeoutids"+timeoutids);
                                component.set("v.timeoutids",timeoutids);
                                //console.log("attribute value"+component.get("v.timeoutids"));
                            }
                            return 0;
                        }
                        component.set("v.resetList",false);
                        myloop(0);
                        
                        /*
                            var handle = setInterval(function(){ $('#ticker_01 li:first').fadeOut( 
                                function () { $(this).appendTo($('#ticker_01')).fadeIn();}
                            );  }, 10000);
                            var timeDur = broadcast[i].duration;
                            if(timeDur==5000){
                                setTimeout(function(){ 
                                    clearInterval(handle);
                                },  5000);
                            }
                            */
                        
                    }
                    
                }                                         
                
                
                
            });
            
            $A.enqueueAction(action);
        }
    },
  
    
})