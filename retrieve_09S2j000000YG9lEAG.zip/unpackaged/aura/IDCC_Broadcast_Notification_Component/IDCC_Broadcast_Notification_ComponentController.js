({
    doInit: function(component, event, helper) {
        var i = 0;
        var lWidth = window.innerWidth ;
        
        helper.getBroadcastList(component);  
        window.setInterval(
            $A.getCallback(function() {
                var id = setTimeout(function() {}, 0);
                var timeoutIds = component.get("v.timeoutids");
                //console.log(timeoutIds);
                if(timeoutIds!=null && timeoutIds!=undefined){
                    for (var timeoutid = 0;timeoutid<timeoutIds.length;timeoutid++) {
                        console.log("id"+timeoutIds[timeoutid]);
                        window.clearTimeout(timeoutIds[timeoutid]); // will do nothing if no timeout with id is present
                    }
                }
                component.set("v.resetList",true);
                helper.getBroadcastList(component);
            } ),100000);
        
        var broadcasts = component.get("v.broadcasts");
        /* 
          jQuery(document).ready(function(){
              
	      
            //  objectRecords[i][skey]['NameOrAlias']
              var timeinseconds = 5000;
              var timeinseconds1 = 15000;
        function tick(){
            
		$('#ticker_01 li:first').fadeOut( function () { $(this).appendTo($('#ticker_01')).fadeIn(); 
                                                      setTimeout(tick, 10000); 
                                                      //Thread.sleep(4000);                                         
                                                      });         
	}                                         
                  setInterval(function(){ tick ();  }, timeinseconds);
              //setInterval(function(){ tick1 ();  }, timeinseconds1);
          
        });
          */
    },
    
})