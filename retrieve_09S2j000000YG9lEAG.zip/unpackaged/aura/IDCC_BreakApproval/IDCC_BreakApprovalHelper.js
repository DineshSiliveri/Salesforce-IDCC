({
    getTableData :function(component, event, helper) {
        // $A.get('e.force:refreshView').fire();
        var action = component.get("c.getBreakApporvalRecordsForTable");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result =response.getReturnValue();
            if (state == "SUCCESS" && !$A.util.isEmpty(result)){
                component.set("v.breakApporvalRecLst",result);  
                helper.getMessageData(component, event, helper);
            }
            else{
                component.set("v.breakApporvalRecLst",null); 
                console.log('Error in IDCC_BreakApproval : getTableData');    
            }
        });
        $A.enqueueAction(action); 
    },
    getMessageData : function(component, event, helper) { 
        var action = component.get("c.getInitData");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result =response.getReturnValue();
            if (state == "SUCCESS" && !$A.util.isEmpty(result)){
                if(!$A.util.isEmpty(result)){
                    var totalAwayTime = (result.Away_hours__c*60) + result.Away_Min__c;
                    var totalTime = $A.get("$Label.c.IDCC_limitForAwayHours")*60;
                    var timeRemaining;
                    if(totalAwayTime >= totalTime){
                    	timeRemaining = 0;    
                    }
                    else{
                    	timeRemaining = totalTime - totalAwayTime;    
                    }
                    console.log('totalTime***'+totalTime+' totalAwayTime***'+totalAwayTime+' timeRemaining**'+timeRemaining)
                    component.set("v.message","You have "+ timeRemaining + " min remaining from "+ totalTime +" min break time.");
                } 
                else{
                 	console.log('result empty  : getMessageData');     
                }
            }
            else{
                component.set("v.breakApporvalRecLst",null); 
                console.log('Error in IDCC_BreakApproval : getMessageData');    
            }
        });
        $A.enqueueAction(action);
    },
    getInitData : function(component, event, helper) {
        var action = component.get("c.getInitData");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result =response.getReturnValue();
            if (state == "SUCCESS"){
                if(!$A.util.isEmpty(result)){
                    //var timeRemaining = ($A.get("$Label.c.IDCC_limitForAwayHours")*60)- result.Away_Min__c;
                    //var totalTime = $A.get("$Label.c.IDCC_limitForAwayHours")*60;
                    var totalAwayTime = (result.Away_hours__c*60) + result.Away_Min__c;
                    var totalTime = $A.get("$Label.c.IDCC_limitForAwayHours")*60;
                    var timeRemaining;
                    if(totalAwayTime >= totalTime){
                    	timeRemaining = 0;    
                    }
                    else{
                    	timeRemaining = totalTime - totalAwayTime;    
                    }
                    component.set("v.AgentProductivityRec",result);
                    component.set("v.message","You have "+timeRemaining +" min remaining from "+ totalTime +" min break time.");
                }
                else{
                    component.set("v.showButtons",false);
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "type": "error",  
                        "message": "Please change status to online and then apply for request"
                    });
                    toastEvent.fire(); 	
                    var utilityAPI = component.find("utilitybar");
                    utilityAPI.minimizeUtility();
                }
                
            }
            else{
                console.log('Error in IDCC_BreakApproval : getInitData');    
            }
        });
        $A.enqueueAction(action); 	
    },
    checkEligibiityForBreak : function(component, event, helper) {
        component.set("v.spinner",true);
        //1st checking whether agent is online
        var initAction = component.get("c.getInitData");
        initAction.setCallback(this, function(response) {           
            var state = response.getState();
            var result =response.getReturnValue();
            if (state == "SUCCESS"){
                //not null if agent is online and further validation will work
                if(!$A.util.isEmpty(result)){
                    var totalAwayTime = (result.Away_hours__c*60) + result.Away_Min__c;
                    var totalTime = $A.get("$Label.c.IDCC_limitForAwayHours")*60;
                    var timeRemaining;
                    if(totalAwayTime >= totalTime){
                    	timeRemaining = 0;    
                    }
                    else{
                    	timeRemaining = totalTime - totalAwayTime;    
                    }
                    //var timeRemaining = ($A.get("$Label.c.IDCC_limitForAwayHours")*60)- result.Away_Min__c;
                    //var totalTime = ($A.get("$Label.c.IDCC_limitForAwayHours")*60);
                    component.set("v.message","You have "+timeRemaining +" min remaining from "+ totalTime +" min of total break time.");
                    var allValid = component.find('fieldId').reduce(function (validSoFar, inputCmp) {
                        inputCmp.showHelpMessageIfInvalid();
                        return validSoFar && !inputCmp.get('v.validity').valueMissing;
                    }, true);            
                    if(allValid){
                        var action = component.get("c.checkEligibilityForBreak");
                        action.setParams({"agentBreakApprovalRecord": component.get("v.newAgentBreakApproval")}); 
                        action.setCallback(this, function(response) {
                            var state = response.getState();
                            var result = response.getReturnValue();
                            if (state == "SUCCESS"){
                                if(!$A.util.isEmpty(result)){
                                    component.set("v.isElligible", true);
                                    for(var key in result){
                                        if(key == 'Present'){
                                            component.set("v.showButtons",true);
                                            component.set("v.openNewBreak",false);
                                            var toastEvent = $A.get("e.force:showToast");
                                            toastEvent.setParams({
                                                "title": "Success!",
                                                "type": "success",
                                                "message": "Request Sent for Approval"
                                            });
                                            toastEvent.fire();
                                            component.set("v.newAgentBreakApproval",null); 
                                        }
                                        else if(key == 'PresentButTimeOver'){
                                            var toastEvent = $A.get("e.force:showToast");
                                            toastEvent.setParams({
                                                "title": "Error!",
                                                "type": "error",  
                                                //"message":  $A.get("$Label.c.IDCC_limitForAwayHours") +" hours have been used - Please contact supervisor"
                                                "message":  "Requested time is more than allowed limit time per day"
                                            });
                                            toastEvent.fire();        
                                        }
                                            else if(key == 'lessThananHourTime'){
                                                // alert($A.get("$Label.c.IDCC_ApplyRequestBefore"));
                                                var toastEvent = $A.get("e.force:showToast");
                                                toastEvent.setParams({
                                                    "title": "Error!",
                                                    "type": "error",  
                                                    //"message":  $A.get("$Label.c.IDCC_limitForAwayHours") +" hours have been used - Please contact supervisor"
                                                    "message":  "There should be "+$A.get("$Label.c.IDCC_ApplyRequestBefore") + " mins difference before applying for break."
                                                });
                                                toastEvent.fire();        
                                            }
                                        component.set("v.isSubmitButtonActive",false);
                                    }
                                    component.set("v.spinner",false);
                                    var utilityAPI = component.find("utilitybar");
                                    utilityAPI.minimizeUtility();
                                }
                                else{
                                    component.set("v.showButtons",true);
                                    component.set("v.openNewBreak",false);
                                    var toastEvent = $A.get("e.force:showToast");
                                    toastEvent.setParams({
                                        "title": "Error!",
                                        "type": "error",  
                                        "message": "Please change status to online and then apply for request"
                                    });
                                    toastEvent.fire(); 
                                    component.set("v.spinner",false);
                                }
                                component.set("v.isSubmitButtonActive",false);                        
                            }
                            else{
                                console.log('Error in IDCC_BreakApproval : checkEligibiityForBreak');
                                component.set("v.spinner",false);
                            }
                        });
                        $A.enqueueAction(action);     
                    }
                    component.set("v.showButtons",true);
                }else{
                    component.set("v.isElligible" , false);
                    component.set("v.showButtons",false);
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "type": "error",  
                        "message": "Please change status to online and then apply for request"
                    });
                    toastEvent.fire(); 	
                    var utilityAPI = component.find("utilitybar");
                    utilityAPI.minimizeUtility();
                    component.set("v.spinner",false);
                } }
        });  
        
        $A.enqueueAction(initAction);
    },
    
    
})