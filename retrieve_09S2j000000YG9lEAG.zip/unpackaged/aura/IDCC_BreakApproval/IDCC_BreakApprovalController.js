({
    doInit : function(component, event, helper) { 
       // $A.get('e.force:refreshView').fire();
        component.set("v.minTime", ($A.localizationService.formatDate(new Date(), "HH:MM:SS") + ".000Z"));
        helper.getTableData(component, event, helper);
        helper.getInitData(component, event, helper);
    },
 
    
    //Method is used to refresh table data on raising 1 request and then resetting newAgentBreakApproval attribute
    refreshUtility : function(component, event, helper){
        // {"sobjectType":"IDCC_Agent_Break_Approval__c","IDCC_Break_Time_Required_Minutes__c":"","IDCC_Break_Start_Time__c":"","IDCC_Break_Reason__c":""}
        component.set("v.newAgentBreakApproval", {"sobjectType":"IDCC_Agent_Break_Approval__c","IDCC_Break_Time_Required_Minutes__c":"","IDCC_Break_Start_Time__c":"","IDCC_Break_Reason__c":""}
                     );
       // component.set("v.isSubmitButtonActive", true);
        helper.getTableData(component, event, helper);
    },
    
    handleNewBreak : function(component, event, helper) {
        component.set("v.showButtons",false);
        component.set("v.openNewBreak",true);       
    },
    handleResumeBreak : function(component, event, helper) {
        component.set("v.showButtons",false);
        component.set("v.resumeBreak",true);
    },
    goBackFromNewRequest : function(component, event, helper) {
        //component.set("v.openNewBreak",false);
        //component.set("v.showButtons",true);
        component.set("v.newAgentBreakApproval",null); 
        var utilityAPI = component.find("utilitybar");
        utilityAPI.minimizeUtility();
    },
    goBackFromResumeRequest : function(component, event, helper) {
        component.set("v.resumeBreak",false);
        component.set("v.showButtons",true);
    },
    createAgentBreakApproval : function(component, event, helper) {
        component.set("v.isSubmitButtonActive",true);
        helper.checkEligibiityForBreak(component, event, helper);
    },
    refreshFocusedTab : function(component, event, helper) {
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.refreshTab({
                tabId: focusedTabId,
                includeAllSubtabs: true
            });
        })
        .catch(function(error) {
            console.log(error);
        });
    }
    
    
})