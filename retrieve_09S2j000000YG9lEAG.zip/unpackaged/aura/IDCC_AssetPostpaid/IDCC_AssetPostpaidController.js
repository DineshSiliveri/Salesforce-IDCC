({
    assetPostpaid : function(cmp, event, helper) {
        cmp.set("v.URL","");
        var recordId = cmp.get("v.recordId"); 
        var action = cmp.get("c.getAssetDetails");
        var PostPre;
        var iCareCat,tmp;
        action.setParams({ caseId: recordId});
        action.setCallback(this,
                           function(response)
                           {
                               var state = response.getState(); 
                               var resValue = response.getReturnValue();
                               if (state == "SUCCESS" && (resValue != null && resValue.length > 0) ) 
                               {
                                   var statusCheck = response.getReturnValue();
                                   console.log(statusCheck);
                                  
                                   PostPre = statusCheck[0].IDCC_CustSegment__c;
                                   iCareCat = statusCheck[0].IDCC_siebelDataLocation__c;
                                   tmp =  $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleAssetDetails?recordId='+recordId;
                                   /*if(PostPre=='Postpaid' && iCareCat=='ICARE'){
                                       tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleAssetForm?apiName=Query_Asset_Info_iCare_Post&resObjName=Query_Asset_iCare_Post_Res&recordId='+recordId;
                                   }else if(PostPre=='Prepaid' && iCareCat=='ICARE'){
                                       tmp =  $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleAssetForm?apiName=Query_Asset_Info_iCare_Post&resObjName=Query_Asset_iCare_Pre_Res&recordId='+recordId;
                                   }else if(iCareCat=='CATALIST'){
                                       tmp =  $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsoleAssetForm?apiName=Query_Asset_Info_Catalyst&resObjName=Query_Asset_Catalyst_Res&recordId='+recordId;
                                   }*/
                                    
        							cmp.set("v.URL",tmp);
        							helper.scrolltoTop();
                               }
                               
                           });
        
        
       
       $A.enqueueAction(action);  
    }, 
     
    familyNFriends : function(cmp, event, helper) {
    	var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleForm");
		var recordId = cmp.get("v.recordId");         
        var tmp = staticLabel+'resObjName=Query_Family_and_Friends_Res&apiName=Query_Family_and_Friends&recordId='+recordId;
        cmp.set("v.URL",tmp);          
	},
    serviceProfile : function(cmp, event, helper) {
    	var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleForm");
		var recordId = cmp.get("v.recordId");         
        var tmp = staticLabel+'resObjName=Query_Service_Profile_Res&apiName=Query_Service_Profile&recordId='+recordId;
        cmp.set("v.URL",tmp);          
	},
    packageInfo : function(cmp, event, helper) {
    	var staticLabel = $A.get("$Label.c.URL_IDCC_ConsolePackageInfoTable");
		var recordId = cmp.get("v.recordId");         
        var tmp = staticLabel+'resObjName=Query_Package_Info_Res&apiName=Query_Package_Info&recordId='+recordId;
        cmp.set("v.URL",tmp);          
	},
    packageList : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var recordId = component.get("v.recordId");
        //var tmp = staticLabel+'apiName=Query_Package_List&resObjName=Query_Package_List_Res&recordId='+recordId;
        var tmp = $A.get("$Label.c.IDCC_SandboxURL")+'apex/IDCC_ConsolePackageInfoTable?apiName=Query_Package_List&resObjName=Query_Package_List_Res&recordId='+recordId; 
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},
    reloadVoucher : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ReloadVoucher");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Reload_Voucher&Form&resObjName=Query_Reload_Voucher_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},
    thresholdStatus : function(component, event, helper) {
		var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Threshold_Status&resObjName=Query_Threshold_status_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
	},
    customerDeviceInfoADM : function(component, event, helper) {
		var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleForm");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Customer_Device_Info_ADM&resObjName=Query_Customer_Device_Info_ADM_Res&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();
	},
    /*auditTrail : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Audit_Trail&resObjName=Query_Audit_Trail_Res&Type123=auditTrail&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	},
    
    auditTrailAva : function(component, event, helper) {
        var staticLabel = $A.get("$Label.c.URL_IDCC_ConsoleTable");
        var recordId = component.get("v.recordId");
        var tmp = staticLabel+'apiName=Query_Audit_Trail&resObjName=Query_Audit_Trail_Res&Type123=auditAvatar&recordId='+recordId;
        component.set("v.URL",tmp);
        helper.scrolltoTop();         
	} */  
   
})