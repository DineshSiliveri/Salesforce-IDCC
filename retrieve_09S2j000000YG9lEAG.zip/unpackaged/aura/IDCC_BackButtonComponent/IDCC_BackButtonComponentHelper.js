({
    //Method to navigate to Home page
    callHomeLink : function(component, event, helper) {
        component.find("navService").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "home"
            }
        }, true);  
    },
    //Method to navigate to discussion Page
    callDiscussionLink :function(component, event, helper) {
        component.find("navService").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "discussionforumspage"
            }
        }, true);
    },
    //Method to navigate to device simulator level1 Component
    callLevel1 : function(component, event, helper) {
        if(component.get("v.calledFrom") =='search'){
            window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/', '_self');    
        }
        else if(component.get("v.calledFrom") =='deviceSimulator'){
            var level2ToLevel1Event = component.getEvent("Level2ToLevel1Event");
            level2ToLevel1Event.setParams({
                "recordId" : component.get("v.recId")
            });
            level2ToLevel1Event.fire();
        }
    },
    //Method to navigate to device simulator level2 Component
    callLevel2 : function(component, event, helper) {
        if(component.get("v.calledFrom") =='search'){
            window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/', '_self');    
        }
        else if(component.get("v.calledFrom") =='deviceSimulator'){
            this.getLevel1NameFromLevel3(component, event, helper,component.get("v.recId"));
        }
    },
    //Method to navigate to device simulator level3 Component
    callLevel3 : function(component, event, helper) {
        if(component.get("v.calledFrom") =='search'){
            window.open($A.get("$Label.c.IDCC_CommunityURL")+'s/', '_self');    
        }
        else if(component.get("v.calledFrom") =='deviceSimulator'){
        	this.getLevel2NameFromLevel4(component, event, helper,component.get("v.recId"));    
        }
    },
    //Navigate to Privious page based on history.
    goBackOnPriPage : function(component, event, helper) {
        window.history.go(-1);
    },
    getLevel1NameFromLevel3 :function(component, event, helper,level2Id){
        var action = component.get("c.getLevel1Id");
        action.setParams({level2Id : level2Id});
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS"){
                var level3ToLevel2Event = component.getEvent("Level3ToLevel2Event");
                level3ToLevel2Event.setParams({
                    "recordId" : result
                });
                level3ToLevel2Event.fire();  
            }
            else{
                console.log('Error in IDCC_BackButtonComponent : getLevel1NameFromLevel3');
            }
        });
        $A.enqueueAction(action);  
    },
    getLevel2NameFromLevel4 :function(component, event, helper,level3Id){
        var action = component.get("c.getLevel2Id");
        action.setParams({level3Id : level3Id});
        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            if (state === "SUCCESS"){
                var level4ToLevel3Event = component.getEvent("Level4ToLevel3Event");
                level4ToLevel3Event.setParams({
                    "recordId" : result
                });
                level4ToLevel3Event.fire(); 
            }
            else{
                console.log('Error in IDCC_BackButtonComponent : getLevel1NameFromLevel3');
            }
        });
        $A.enqueueAction(action);  
    }
    
})