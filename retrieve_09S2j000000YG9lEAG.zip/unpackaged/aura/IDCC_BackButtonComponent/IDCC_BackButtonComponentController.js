({
    //Handler for back button
	backLinkHandler : function(component, event, helper) {
		if(component.get("v.targetCmp")== 'Home'){
            helper.callHomeLink(component, event, helper);   
        }
        else if(component.get("v.targetCmp")== 'Level1'){
            helper.callLevel1(component, event, helper);    
        }
        else if(component.get("v.targetCmp")== 'Level2'){
            helper.callLevel2(component, event, helper);    
        }
        else if(component.get("v.targetCmp")== 'Level3'){
            helper.callLevel3(component, event, helper);    
        }	
        else if(component.get("v.targetCmp")== 'Discussion'){
            helper.callDiscussionLink(component, event, helper);    
        }
        else if(component.get("v.targetCmp")== 'GoBack'){
            helper.goBackOnPriPage(component, event, helper);    
        }
	}
})